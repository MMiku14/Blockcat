import { useState } from "react";
import { CRATES, INVARIANTS } from "../data";
import Section from "./Section";

export default function Architecture() {
  const [active, setActive] = useState(CRATES[0].id);
  const current = CRATES.find((c) => c.id === active)!;

  return (
    <Section
      id="architecture"
      eyebrow="Workspace"
      title="架构与 crate 边界"
      desc="七个 crate 的单向无环依赖。禁止的是 dsp → host 的反向依赖，而非应用层同时消费两者。"
    >
      <div className="grid gap-6 lg:grid-cols-[300px,1fr]">
        {/* crate 列表 */}
        <div className="space-y-1.5">
          {CRATES.map((c) => {
            const isActive = c.id === active;
            return (
              <button
                key={c.id}
                onClick={() => setActive(c.id)}
                className={`flex w-full items-center justify-between rounded-lg border px-4 py-3 text-left transition ${
                  isActive
                    ? "border-accent/40 bg-accent/10"
                    : "border-white/5 bg-ink-900/50 hover:border-white/10 hover:bg-ink-850"
                }`}
              >
                <div>
                  <div
                    className={`font-mono text-sm font-semibold ${
                      isActive ? "text-accent" : "text-white"
                    }`}
                  >
                    {c.name}
                  </div>
                  <div className="text-xs text-slate-500">{c.role}</div>
                </div>
                {c.nostd && (
                  <span className="rounded bg-white/5 px-1.5 py-0.5 font-mono text-[10px] text-slate-400">
                    no_std
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* 详情面板 */}
        <div className="rounded-xl border border-white/5 bg-ink-900/60 p-6 sm:p-8">
          <div className="flex flex-wrap items-center gap-3">
            <h3 className="font-mono text-xl font-bold text-white">{current.name}</h3>
            <span className="rounded-full bg-accent/10 px-2.5 py-0.5 text-xs text-accent ring-1 ring-accent/20">
              {current.role}
            </span>
          </div>

          <p className="mt-3 text-sm leading-relaxed text-slate-300">
            {current.summary}
          </p>

          <div className="mt-5">
            <span className="text-xs text-slate-500">依赖：</span>
            {current.deps.length === 0 ? (
              <span className="ml-1 font-mono text-xs text-accent">无（纯核心）</span>
            ) : (
              <span className="ml-1 space-x-1.5">
                {current.deps.map((d) => (
                  <span
                    key={d}
                    className="inline-block rounded bg-white/5 px-1.5 py-0.5 font-mono text-xs text-slate-300"
                  >
                    {d}
                  </span>
                ))}
              </span>
            )}
          </div>

          <ul className="mt-6 space-y-3 border-t border-white/5 pt-6">
            {current.highlights.map((h) => (
              <li key={h} className="flex gap-3 text-sm text-slate-300">
                <span className="mt-0.5 font-mono text-accent">→</span>
                <span className="leading-relaxed">{h}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* 依赖流向图 */}
      <div className="mt-8 overflow-x-auto rounded-xl border border-white/5 bg-ink-950 p-6">
        <pre className="font-mono text-xs leading-relaxed text-slate-400 sm:text-sm">
{`audio-core     no_std + alloc    SPSC · RCU · deferred drop
    ▲
audio-sys                        FPU guard · monotonic probe · provisioner
    ▲
    ├── audio-host               定容块适配 · 后端骨架
    ├── audio-dsp                DAG 运行时 · RCU 图发布 · 事件总线
    ├── audio-clock              设备时钟 · 延迟模型 · 漂移补偿
    └── audio-api                流生命周期 · 格式协商 · 控制面
            ▲
        audio-kernel             集成层 + 可运行示例`}
        </pre>
      </div>

      {/* 核心不变式 */}
      <div className="mt-8">
        <h3 className="mb-4 font-mono text-sm uppercase tracking-widest text-slate-500">
          核心不变式（节选）
        </h3>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {INVARIANTS.map((inv) => (
            <div
              key={inv.n}
              className="rounded-lg border border-white/5 bg-ink-900/50 p-4"
            >
              <div className="font-mono text-xs font-semibold text-accent">
                {inv.n}
              </div>
              <div className="mt-1 text-sm text-slate-400">{inv.text}</div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}
