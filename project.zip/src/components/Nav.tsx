import { useEffect, useState } from "react";
import { PROJECT } from "../data";

const LINKS = [
  { href: "#overview", label: "概览" },
  { href: "#features", label: "功能" },
  { href: "#architecture", label: "架构" },
  { href: "#changelog", label: "日志" },
  { href: "#budgets", label: "性能" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-300 ${
        scrolled
          ? "border-b border-white/5 bg-ink-950/80 backdrop-blur-xl"
          : "border-b border-transparent"
      }`}
    >
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <a href="#top" className="flex items-center gap-2.5">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-accent/15 text-lg ring-1 ring-accent/30">
            🐈
          </span>
          <span className="font-mono text-sm font-semibold tracking-tight text-white">
            {PROJECT.name}
            <span className="ml-2 rounded bg-white/5 px-1.5 py-0.5 text-[10px] font-normal text-accent">
              v{PROJECT.version}
            </span>
          </span>
        </a>

        <nav className="hidden items-center gap-1 md:flex">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="rounded-md px-3 py-2 text-sm text-slate-400 transition hover:bg-white/5 hover:text-white"
            >
              {l.label}
            </a>
          ))}
          <a
            href={PROJECT.repo}
            target="_blank"
            rel="noreferrer"
            className="ml-2 rounded-md border border-white/10 px-3 py-2 text-sm text-slate-200 transition hover:border-accent/40 hover:text-accent"
          >
            GitHub ↗
          </a>
        </nav>

        <button
          className="grid h-9 w-9 place-items-center rounded-md border border-white/10 text-slate-300 md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="menu"
        >
          <span className="text-lg">{open ? "✕" : "☰"}</span>
        </button>
      </div>

      {open && (
        <nav className="border-t border-white/5 bg-ink-950/95 px-5 py-3 md:hidden">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="block rounded-md px-3 py-2.5 text-sm text-slate-300 hover:bg-white/5"
            >
              {l.label}
            </a>
          ))}
          <a
            href={PROJECT.repo}
            target="_blank"
            rel="noreferrer"
            className="block rounded-md px-3 py-2.5 text-sm text-accent"
          >
            GitHub ↗
          </a>
        </nav>
      )}
    </header>
  );
}
