import { FEATURES } from "../data";
import Section from "./Section";

export default function Features() {
  return (
    <Section
      id="features"
      eyebrow="Current Features"
      title="目前项目功能"
      desc="六大能力构成 Audio Runtime 的对外契约 —— 从流生命周期到时钟延迟模型，全部围绕“音频线程零分配”这条主线设计。"
    >
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {FEATURES.map((f) => (
          <article
            key={f.title}
            className="group relative overflow-hidden rounded-xl border border-white/5 bg-ink-900/60 p-6 transition hover:border-accent/30 hover:bg-ink-850"
          >
            <div className="absolute right-4 top-4 text-4xl text-white/5 transition group-hover:text-accent/20">
              {f.icon}
            </div>
            <div className="mb-4 grid h-10 w-10 place-items-center rounded-lg bg-accent/10 text-xl text-accent ring-1 ring-accent/20">
              {f.icon}
            </div>
            <h3 className="text-lg font-semibold text-white">{f.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-400">{f.desc}</p>
            <ul className="mt-4 space-y-2">
              {f.points.map((p) => (
                <li key={p} className="flex gap-2 text-sm text-slate-400">
                  <span className="mt-1 text-accent">▸</span>
                  <span>{p}</span>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </Section>
  );
}
