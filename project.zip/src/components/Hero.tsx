import { PROJECT, METRICS } from "../data";

export default function Hero() {
  return (
    <section
      id="top"
      className="relative overflow-hidden border-b border-white/5 pt-16"
    >
      <div className="absolute inset-0 grid-noise opacity-40" />
      <div className="absolute -left-40 top-10 h-72 w-72 rounded-full bg-accent/10 blur-3xl" />

      <div className="relative mx-auto max-w-6xl px-5 py-20 sm:py-28">
        <div className="animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full border border-accent/20 bg-accent/5 px-3 py-1 font-mono text-xs text-accent">
            <span className="h-1.5 w-1.5 animate-pulse-line rounded-full bg-accent" />
            {PROJECT.msrv} · {PROJECT.license}
          </span>
        </div>

        <h1
          className="mt-6 max-w-3xl text-4xl font-bold leading-[1.1] tracking-tight text-white animate-fade-up sm:text-6xl"
          style={{ animationDelay: "60ms" }}
        >
          {PROJECT.name}
          <span className="text-accent"> · </span>
          <span className="bg-gradient-to-r from-accent via-teal-300 to-sky-300 bg-clip-text text-transparent">
            {PROJECT.subtitle}
          </span>
        </h1>

        <p
          className="mt-6 max-w-2xl text-lg leading-relaxed text-slate-400 animate-fade-up"
          style={{ animationDelay: "120ms" }}
        >
          {PROJECT.tagline}
        </p>

        <div
          className="mt-9 flex flex-wrap items-center gap-3 animate-fade-up"
          style={{ animationDelay: "180ms" }}
        >
          <a
            href="#features"
            className="rounded-lg bg-accent px-5 py-2.5 text-sm font-semibold text-ink-950 transition hover:bg-teal-300"
          >
            浏览项目功能
          </a>
          <a
            href="#changelog"
            className="rounded-lg border border-white/10 px-5 py-2.5 text-sm font-medium text-slate-200 transition hover:border-accent/40 hover:text-accent"
          >
            查看开发日志
          </a>
        </div>

        <dl
          className="mt-16 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-white/5 bg-white/5 sm:grid-cols-4 animate-fade-up"
          style={{ animationDelay: "240ms" }}
        >
          {METRICS.map((m) => (
            <div key={m.label} className="bg-ink-900 p-5">
              <dt className="text-xs text-slate-500">{m.label}</dt>
              <dd className="mt-1 font-mono text-2xl font-bold text-white">
                {m.value}
              </dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
