import { BUDGETS } from "../data";
import Section from "./Section";

export default function Budgets() {
  return (
    <Section
      id="budgets"
      eyebrow="Performance"
      title="性能目标预算"
      desc="参考预算仅供参照，不作为普通 CI 的硬性门槛 —— 共享 runner、频率缩放与 CPU 迁移会让硬性性能门槛充满噪声。仅在固定频率的专用性能主机上启用。"
    >
      <div className="overflow-hidden rounded-xl border border-white/5">
        <table className="w-full text-left text-sm">
          <thead className="bg-white/5 text-xs uppercase tracking-wider text-slate-400">
            <tr>
              <th className="px-5 py-3 font-medium">操作</th>
              <th className="px-5 py-3 font-medium">目标时延</th>
              <th className="px-5 py-3 font-medium">crate</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {BUDGETS.map((b) => (
              <tr
                key={b.op}
                className="bg-ink-900/40 transition hover:bg-ink-850"
              >
                <td className="px-5 py-3.5 font-mono text-slate-200">{b.op}</td>
                <td className="px-5 py-3.5">
                  <span className="rounded bg-accent/10 px-2 py-0.5 font-mono text-accent">
                    {b.target}
                  </span>
                </td>
                <td className="px-5 py-3.5 font-mono text-xs text-slate-500">
                  {b.crate}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="mt-5 rounded-lg border border-amber-500/15 bg-amber-500/5 px-4 py-3 text-sm text-amber-200/80">
        <span className="font-semibold">说明：</span>
        基准运行器无第三方依赖，按批量测量后除以逻辑操作数，避免计时开销主导纳秒级原语。
        结果报告均值 / 中位数 / p99 / 最小 / 最大值。
      </p>
    </Section>
  );
}
