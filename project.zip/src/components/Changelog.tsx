import { useMemo, useState } from "react";
import { CHANGELOG, LogTag } from "../data";
import Section from "./Section";

const TAG_STYLE: Record<LogTag, string> = {
  架构: "bg-violet-500/15 text-violet-300 ring-violet-500/20",
  新增: "bg-teal-500/15 text-teal-300 ring-teal-500/20",
  修复: "bg-rose-500/15 text-rose-300 ring-rose-500/20",
  优化: "bg-sky-500/15 text-sky-300 ring-sky-500/20",
  工具: "bg-amber-500/15 text-amber-300 ring-amber-500/20",
};

const ALL_TAGS: LogTag[] = ["架构", "新增", "修复", "优化", "工具"];

export default function Changelog() {
  const [filter, setFilter] = useState<LogTag | "全部">("全部");

  const entries = useMemo(() => {
    if (filter === "全部") return CHANGELOG;
    return CHANGELOG.map((e) => ({
      ...e,
      changes: e.changes.filter((c) => c.tag === filter),
    })).filter((e) => e.changes.length > 0);
  }, [filter]);

  return (
    <Section
      id="changelog"
      eyebrow="Changelog"
      title="开发日志"
      desc="按迭代记录的版本变更。从上游基线到集成层，每一步都可追溯。"
    >
      {/* 过滤器 */}
      <div className="mb-10 flex flex-wrap gap-2">
        {(["全部", ...ALL_TAGS] as const).map((t) => {
          const active = filter === t;
          return (
            <button
              key={t}
              onClick={() => setFilter(t)}
              className={`rounded-full border px-3.5 py-1.5 text-sm transition ${
                active
                  ? "border-accent/40 bg-accent/10 text-accent"
                  : "border-white/10 text-slate-400 hover:border-white/20 hover:text-white"
              }`}
            >
              {t}
            </button>
          );
        })}
      </div>

      {/* 时间线 */}
      <div className="relative">
        <div className="absolute bottom-2 left-[7px] top-2 w-px bg-gradient-to-b from-accent/40 via-white/10 to-transparent" />

        <div className="space-y-10">
          {entries.map((entry) => (
            <div key={entry.version} className="relative pl-8">
              <span className="absolute left-0 top-1.5 grid h-3.5 w-3.5 place-items-center rounded-full border-2 border-accent bg-ink-950">
                <span className="h-1 w-1 rounded-full bg-accent" />
              </span>

              <div className="rounded-xl border border-white/5 bg-ink-900/60 p-6">
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <h3 className="font-mono text-base font-semibold text-white">
                    {entry.version}
                  </h3>
                  <span className="font-mono text-xs text-slate-500">
                    {entry.date}
                  </span>
                </div>
                <p className="mt-1 text-sm font-medium text-accent">{entry.title}</p>
                <p className="mt-3 text-sm leading-relaxed text-slate-400">
                  {entry.summary}
                </p>

                <ul className="mt-5 space-y-2.5 border-t border-white/5 pt-5">
                  {entry.changes.map((c, i) => (
                    <li key={i} className="flex flex-wrap items-start gap-2.5">
                      <span
                        className={`mt-0.5 shrink-0 rounded px-1.5 py-0.5 text-[11px] font-medium ring-1 ${TAG_STYLE[c.tag]}`}
                      >
                        {c.tag}
                      </span>
                      <span className="text-sm leading-relaxed text-slate-300">
                        {c.text}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}
