import Section from "./Section";

const PIPELINE = [
  { step: "1", label: "FPU 守卫", detail: "装载 FTZ/DAZ，抑制 subnormal 尾部延迟" },
  { step: "2", label: "排空控制队列", detail: "应用参数，零分配（§5.3）" },
  { step: "3", label: "Pin 图跑适配", detail: "hazard 指针 + 定容块适配" },
  { step: "4", label: "推进时钟", detail: "更新播放位置与延迟模型" },
  { step: "5", label: "上报事件", detail: "欠载 / 过载 / 延迟变化" },
];

export default function Overview() {
  return (
    <Section
      id="overview"
      eyebrow="Overview"
      title="它是什么"
      desc="Audio Runtime 是一个 Rust 实时音频微内核。核心主张只有一句：音频线程绝不分配、绝不加锁、绝不阻塞。围绕这条主线，从无锁原语一路搭到可运行的音频内核。"
    >
      <div className="grid gap-6 lg:grid-cols-2">
        {/* 左：一次音频回调做的事 */}
        <div className="rounded-xl border border-white/5 bg-ink-900/60 p-6 sm:p-8">
          <h3 className="text-lg font-semibold text-white">
            一次音频回调 <span className="font-mono text-sm text-accent">AudioKernel::process</span>
          </h3>
          <p className="mt-2 text-sm text-slate-400">
            唯一的音频线程入口，全程零分配 / 零锁 / 零阻塞系统调用。
          </p>
          <ol className="mt-6 space-y-4">
            {PIPELINE.map((p) => (
              <li key={p.step} className="flex gap-4">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-accent/10 font-mono text-sm font-bold text-accent ring-1 ring-accent/20">
                  {p.step}
                </span>
                <div>
                  <div className="text-sm font-medium text-white">{p.label}</div>
                  <div className="text-sm text-slate-500">{p.detail}</div>
                </div>
              </li>
            ))}
          </ol>
        </div>

        {/* 右：设计取舍 */}
        <div className="space-y-4">
          <div className="rounded-xl border border-white/5 bg-ink-900/60 p-6">
            <h4 className="font-semibold text-white">为什么是微内核</h4>
            <p className="mt-2 text-sm leading-relaxed text-slate-400">
              七个 crate 各守一条物理边界，依赖单向无环。核心
              <span className="font-mono text-accent"> audio-core </span>
              是 no_std 的纯逻辑，不碰任何 OS API；平台脏活全部下沉到
              <span className="font-mono text-accent"> audio-sys</span>。
            </p>
          </div>
          <div className="rounded-xl border border-white/5 bg-ink-900/60 p-6">
            <h4 className="font-semibold text-white">刻意的边界</h4>
            <ul className="mt-2 space-y-1.5 text-sm text-slate-400">
              <li>· ALSA / CoreAudio 为编译期骨架，尚未链接系统库</li>
              <li>· 格式协商报告“需要重采样”，重采样器留给上层</li>
              <li>· 漂移补偿产出比率，ASRC 本身不内置</li>
              <li>· flush 不渲染效果器尾音 —— 那是节点策略</li>
            </ul>
          </div>
          <div className="rounded-xl border border-accent/15 bg-accent/5 p-6">
            <h4 className="font-semibold text-accent">验证</h4>
            <p className="mt-2 text-sm leading-relaxed text-slate-300">
              CI 覆盖 Linux / macOS / Windows 三平台，并对
              <span className="font-mono"> audio-core / audio-dsp </span>
              运行 <span className="font-mono">cargo miri</span>（strict-provenance），
              因为工作区所有 unsafe 都集中在这两个 crate。
            </p>
          </div>
        </div>
      </div>
    </Section>
  );
}
