import { PROJECT } from "../data";

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-ink-950">
      <div className="mx-auto max-w-6xl px-5 py-12">
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="text-lg">🐈</span>
              <span className="font-mono text-sm font-semibold text-white">
                {PROJECT.name}
              </span>
              <span className="rounded bg-white/5 px-1.5 py-0.5 font-mono text-[10px] text-accent">
                v{PROJECT.version}
              </span>
            </div>
            <p className="mt-3 max-w-md text-sm leading-relaxed text-slate-500">
              {PROJECT.subtitle} · {PROJECT.msrv} · {PROJECT.license}
            </p>
          </div>

          <div className="flex flex-col gap-2 text-sm">
            <a
              href={PROJECT.repo}
              target="_blank"
              rel="noreferrer"
              className="text-slate-400 transition hover:text-accent"
            >
              GitHub 仓库 ↗
            </a>
            <a href="#features" className="text-slate-400 transition hover:text-accent">
              项目功能
            </a>
            <a href="#changelog" className="text-slate-400 transition hover:text-accent">
              开发日志
            </a>
          </div>
        </div>

        <div className="mt-10 border-t border-white/5 pt-6 text-xs text-slate-600">
          该站点内容依据工作区实际实现整理，用于介绍项目功能与开发日志。
          代码为 Rust 工作区，需 {PROJECT.msrv} 或更高版本构建。
        </div>
      </div>
    </footer>
  );
}
