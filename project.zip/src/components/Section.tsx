import { ReactNode } from "react";

type Props = {
  id: string;
  eyebrow: string;
  title: string;
  desc?: string;
  children: ReactNode;
};

export default function Section({ id, eyebrow, title, desc, children }: Props) {
  return (
    <section id={id} className="mx-auto max-w-6xl scroll-mt-20 px-5 py-20">
      <div className="mb-12 max-w-2xl">
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-accent">
          {eyebrow}
        </p>
        <h2 className="mt-3 text-3xl font-bold tracking-tight text-white sm:text-4xl">
          {title}
        </h2>
        {desc && <p className="mt-4 text-base leading-relaxed text-slate-400">{desc}</p>}
      </div>
      {children}
    </section>
  );
}
