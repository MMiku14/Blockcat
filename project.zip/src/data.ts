// 站点内容数据 —— 全部来自当前 Audio Runtime 工作区的实际实现。

export const PROJECT = {
  name: "Audio Runtime",
  subtitle: "实时音频微内核",
  version: "4.8.1",
  msrv: "Rust 1.82",
  license: "MIT OR Apache-2.0",
  repo: "https://github.com/MMiku14/Blockcat",
  tagline:
    "以物理 crate 边界与无锁核心不变式为骨架的实时音频微内核 —— 从无锁原语到可运行的音频内核。",
};

export type Crate = {
  id: string;
  name: string;
  role: string;
  nostd: boolean;
  deps: string[];
  summary: string;
  highlights: string[];
};

export const CRATES: Crate[] = [
  {
    id: "audio-core",
    name: "audio-core",
    role: "无锁核心原语",
    nostd: true,
    deps: [],
    summary: "no_std + alloc 的纯核心，不触碰任何 OS API：SPSC 环、RCU 指针交换、延迟回收。",
    highlights: [
      "SpscRing<T, N>：缓存行对齐、wait-free 的 push / pop，单调无界索引避免满/空歧义",
      "pop_slice_copy 为“全有或全无”，数据不足时不消费任何元素",
      "RcuHandle<T>：音频线程 Acquire 读，控制线程带版本号的 AcqRel 交换",
      "DropVTable 在单态化时冻结 Layout，GC 线程绝不会用错布局释放",
      "EmergencySlot：GC 队列满时的兜底回收路径，严格的发布顺序协议",
    ],
  },
  {
    id: "audio-sys",
    name: "audio-sys",
    role: "平台交互抽象",
    nostd: false,
    deps: ["audio-core"],
    summary: "封装需要 OS 特权或硬件寄存器的“平台脏活”：FPU 守卫、单调时钟、线程特权管理。",
    highlights: [
      "FpuGuard：RAII 式 FTZ/DAZ，两端 compiler_fence(SeqCst) 防止浮点重排",
      "read_monotonic_tick：invariant TSC / CNTVCT_EL0 / Instant 回退",
      "PerformanceProbe：无锁探针，带嵌套防御与溢出计数",
      "ThreadProvisioner：Strict 模式拒绝静默降级，拒绝时不改动线程状态",
    ],
  },
  {
    id: "audio-host",
    name: "audio-host",
    role: "宿主适配矩阵",
    nostd: false,
    deps: ["audio-core", "audio-sys"],
    summary: "定容块适配器 + 后端骨架。回调路径永不分配、永不扩容。",
    highlights: [
      "AdapterBuffer 使用固定容量 Box<[f32]> 环，热路径零分配",
      "非整除块比预留最小定量 D − gcd(H, D)，对齐时零附加延迟",
      "运行时块大小变化回退到保守的 D − 1 预留，并上报新增延迟",
      "flush() 只对内部处理块补零，只返回真实输入对应的样本",
    ],
  },
  {
    id: "audio-dsp",
    name: "audio-dsp",
    role: "图运行时",
    nostd: false,
    deps: ["audio-core", "audio-sys"],
    summary: "动态图构建、拓扑校验、RCU 热替换、跨模块事件总线。",
    highlights: [
      "compile() 用 Kahn 拓扑排序拒绝环 / 自环 / 重复边 / 空图，然后一次性分配",
      "process 执行编译后的 DAG：多前驱按样本求和，多 sink 混合输出",
      "图级延迟 = 所有路径的最大累计延迟，而非求和",
      "try_pin 发布 hazard 指针，重入返回 None 而非阻塞",
      "EventBus 保留末尾 8 个槽位给关键事件，致命溢出单独计数",
    ],
  },
  {
    id: "audio-clock",
    name: "audio-clock",
    role: "时钟 · 位置 · 延迟 · 漂移",
    nostd: false,
    deps: ["audio-sys"],
    summary: "设备时钟、三态播放位置、分阶段延迟模型、最小二乘漂移补偿。",
    highlights: [
      "区分 total_frames_processed / write_frame / play_frame 三种位置",
      "TickRate::measure 校准 tick 频率，correct_position 半步收敛不跳变",
      "LatencyReport 定容 + Copy，音频线程可零分配入队",
      "阶段分类 Hardware / Buffering / Adaptation / Algorithmic，可算硬件下限",
      "ClockDriftEstimator 用 64 点窗口两轮 MAD 截尾最小二乘，真正抑制端点离群",
      "DriftCompensation 仅在高置信度且 ±1000ppm 内启用",
    ],
  },
  {
    id: "audio-api",
    name: "audio-api",
    role: "稳定公共 API",
    nostd: false,
    deps: ["audio-core"],
    summary: "Stream 生命周期状态机、统一格式协商与转换、控制与事件面、图事务。",
    highlights: [
      "Stream 状态机使用 compare_exchange 原子迁移，并发调用保证仅有一个迁移胜出",
      "ControlRequest / EventPlane 全为 Copy；Sender 只有 send，Receiver 只有 poll，契约由类型系统严格强制",
      "EventHub 双 SPSC 聚合：audio 与 control 各占单独通道，彻底杜绝单环双向争用的 UB 隐患",
      "格式协商按“重采样 ≫ 通道重映射 ≫ 位深”代价顺序优选；零分配转换完整处理 24-bit 符号扩展与饱和转换",
      "GraphTransaction.commit 实行整体事务性校验，遇到异常立即回滚，维持 GraphSpec 原状",
    ],
  },
  {
    id: "audio-kernel",
    name: "audio-kernel",
    role: "集成层",
    nostd: false,
    deps: ["audio-api", "audio-clock", "audio-dsp", "audio-host", "audio-sys"],
    summary:
      "把六个 crate 组装成可运行的音频内核，拆为音频句柄与可克隆控制句柄，附端到端离线渲染示例。",
    highlights: [
      "AudioKernel::process 唯一音频线程入口，全程零分配 / 零锁 / 零阻塞；&mut 保证单回调",
      "ControlHandle Clone+Send+Sync，共享 Arc<SharedState>，统计原子化，格式/延迟用 RwLock/Mutex",
      "一次回调：FPU 守卫 → 排空控制队列 → pin 图跑适配 → 推进时钟 → 上报事件",
      "SharedGainNode 用 Arc 共享参数队列，跨块斜坡精确抵达目标，消除参数跳变的咔哒",
      "KernelConfig builder + validate()，半构造非法配置提前拦截",
      "EventHub 双 SPSC 聚合，单消费者由 Mutex 保护，避免多生产者竞争 UB",
    ],
  },
];

export type Feature = {
  title: string;
  icon: string;
  desc: string;
  points: string[];
};

export const FEATURES: Feature[] = [
  {
    title: "通用 API",
    icon: "◇",
    desc: "对后端与图实现中立的稳定编程接口。",
    points: [
      "ControlRequest / EventPlane 全为 Copy，只含标量与 &'static str",
      "可直接放进无锁 SPSC 环，跨线程不分配内存",
      "动态字符串诊断走非实时 EventSink 旁路",
    ],
  },
  {
    title: "Stream 生命周期",
    icon: "◷",
    desc: "Idle → Preparing → Running → Draining → Idle 的原子状态机。",
    points: [
      "compare_exchange 迁移，并发下无丢失更新",
      "准备失败回到可重试的 Idle，而非卡死",
      "Error 状态永远可达，故障总能上报",
    ],
  },
  {
    title: "DSP 节点描述与图事务",
    icon: "❖",
    desc: "节点自描述 + 原子化的图增删改。",
    points: [
      "DspNodeDescriptor 暴露端口、参数、延迟、CPU 预算",
      "commit 整体校验：越界 / 重复边 / 自环 / 环路 / 参数范围",
      "失败即整体回滚，dry_run 支持 UI 实时置灰",
    ],
  },
  {
    title: "稳定的控制面与事件面",
    icon: "⇄",
    desc: "内核 ↔ 应用的双向零分配通信。",
    points: [
      "控制面：应用 → 内核（ControlRequest）",
      "事件面：内核 → 应用（EventPlane）",
      "查询在控制线程同步应答，不占用实时队列",
    ],
  },
  {
    title: "设备时钟、播放位置与真实延迟",
    icon: "◐",
    desc: "区分处理 / 写入 / 发声三种位置，分阶段延迟建模。",
    points: [
      "TickRate 挂钟校准，位置半步收敛不抖动",
      "延迟拆成硬件 / 缓冲 / 适配 / 算法四类",
      "hardware_floor_us 给出配置无法突破的下限",
    ],
  },
  {
    title: "统一格式协商与转换",
    icon: "⇉",
    desc: "在宿主能力集中挑选代价最小的格式并零分配转换。",
    points: [
      "代价排序：重采样 ≫ 通道重映射 ≫ 位深",
      "饱和 f32↔i16、符号扩展 24-bit、交织/去交织",
      "报告是否需要重采样，但重采样器本身留给上层",
    ],
  },
];

export type LogTag = "架构" | "修复" | "新增" | "优化" | "工具";

export type LogEntry = {
  version: string;
  date: string;
  title: string;
  summary: string;
  changes: { tag: LogTag; text: string }[];
};

export const CHANGELOG: LogEntry[] = [
  {
    version: "v4.8.1 · 收缩",
    date: "第五次迭代",
    title: "删掉没有调用者的抽象",
    summary:
      "上一轮大重构加进来的四项抽象，全部零调用者，其中一项是坏的。本轮删除，并在原处留下墓碑注释说明重新引入的条件。另修复 Idle 期间控制队列堆积。",
    changes: [
      { tag: "优化", text: "删除 TypedStream + typestate + State（约 155 行）：零使用者，doctest 从未编译过；运行时 CAS 已覆盖并发正确性" },
      { tag: "优化", text: "删除 NodeRegistry（约 58 行）：零使用者，内建节点是 pub const，枚举用 const 切片即可" },
      { tag: "修复", text: "删除 ControlPlane trait + QueuedControlPlane：它是坏的 —— pump_events 摸不到接收端恒返回 0，events_sender() 每次 split 新 hub 发出的事件无人可收" },
      { tag: "优化", text: "删除 ControlRequest::Extension：无类型 u64 载荷把编译期问题推迟成运行时魔数约定，#[non_exhaustive] 已提供向前兼容" },
      { tag: "优化", text: "删除 HostBackendRegistry：零生产使用者，后端选择由 #[cfg] 在编译期完成，运行时表不承载决策" },
      { tag: "修复", text: "Idle 期间控制队列堆积：排空移到活动检查之前。旧行为下容量 64 满后新请求全丢，启动瞬间陈旧请求一次性涌入" },
      { tag: "新增", text: "idle_process_still_drains_the_control_queue / stop_request_at_idle_is_ignored_without_side_effects 钉住新语义" },
      { tag: "工具", text: "ARCHITECTURE.md 增加「Deliberately removed」表：逐项记录删因与重新引入的具体条件，防止被好心加回" },
      { tag: "修复", text: "锁中毒不再被吞成默认值：format() 曾用 unwrap_or_default 返回 96kHz，调用方分不清真实配置与故障；改为 into_inner 取真实值并计入 poison_events" },
      { tag: "新增", text: "KernelStats::poison_events + is_healthy()：中毒是进程健康问题，与音频损伤 is_clean() 分开判定，避免两类故障互相掩盖" },
      { tag: "优化", text: "删除 ControlChannel / EventChannel 上绕过类型拆分的直通方法：它们复制 Sender/Receiver 实现且两端可调，把 split() 的保证还了回去" },
      { tag: "新增", text: "poisoned_locks_are_counted_not_swallowed：线程持锁 panic 后断言仍返回真实采样率且计数非零" },
    ],
  },
  {
    version: "v4.8.1 · 长期架构硬化",
    date: "第四次迭代",
    title: "可扩展与并发安全",
    summary:
      "针对长期加代码导致的架构腐化，做类型级契约与并发拆分：控制通道 Sender/Receiver 类型分离、事件面双 SPSC 聚合、内核拆为音频句柄与可克隆控制句柄。",
    changes: [
      { tag: "架构", text: "ControlChannel::split() → (Sender, Receiver)，生产端只有 send，消费端只有 poll；编译器拦住单生产者违规" },
      { tag: "架构", text: "EventHub 双 SPSC：audio 与 control 各一条环，应用线程聚合排空；修复旧 EventChannel 被两线程同时 publish 的 UB 隐患" },
      { tag: "架构", text: "AudioKernel 拆为 AudioKernel(&mut) + ControlHandle(Clone+Send+Sync)，共享 Arc<SharedState>，统计原子化" },
      { tag: "修复", text: "自查发现拆分时把参数表与延迟模型放进了 SharedState，等于给音频回调加了 RwLock/Mutex —— 违反项目最核心的不变式 #1/#2" },
      { tag: "架构", text: "权威副本回归 AudioState 独占：process() 只碰原子；镜像同步改 try_lock，竞争即跳过，绝不阻塞音频线程" },
      { tag: "新增", text: "process_never_blocks_on_a_held_shared_lock：另一线程持锁时跑 process，把「热路径不得阻塞」从注释变成可执行断言" },
      { tag: "新增", text: "KernelConfig builder 风格 + validate()，半构造非法配置提前拦截" },
      { tag: "优化", text: "StatsAtomic 原子化，音频线程无锁递增；LatencyReport / PlaybackPosition 保持 Copy 零分配" },
      { tag: "工具", text: "新增 ARCHITECTURE.md，记录依赖边、单生产者契约、内核并发模型与长期加代码指南" },
    ],
  },
  {
    version: "v4.8.1 · 集成层",
    date: "第三次迭代",
    title: "端到端可运行内核",
    summary:
      "新增 audio-kernel 集成层，把六个 crate 组装成真正能跑的音频内核，并配套离线渲染示例、跨平台 CI 与 Miri 检查。",
    changes: [
      { tag: "新增", text: "audio-kernel：AudioKernel::process 单一音频线程入口，全程零分配 / 零锁 / 零阻塞" },
      { tag: "新增", text: "SharedGainNode：用 Arc 共享参数队列，控制线程可寻址却不触碰图内存" },
      { tag: "新增", text: "offline_render 示例：1 秒 440Hz 正弦穿过热替换的图，打印分阶段延迟与播放位置" },
      { tag: "优化", text: "增益变化在块内做线性斜坡，消除参数跳变产生的咔哒声" },
      { tag: "工具", text: "GitHub Actions 三平台 CI + cargo miri（strict-provenance）检查无锁原语" },
      { tag: "工具", text: "rust-toolchain.toml 锁定 1.82，避免 rustfmt 版本漂移导致的假阳性" },
      { tag: "架构", text: "crate 统一为 audio-* 前缀；避开与 Rust 内建 core 冲突，同步更新依赖、导入、脚本与 CI" },
      { tag: "修复", text: "GraphTransaction::commit 改为 &self，链式构建器不再因 move 而无法编译" },
      { tag: "修复", text: "补齐 AdapterBuffer / DspGraphHandle / RetiredDspGraph / 通道与 AudioKernel 的 Debug 实现" },
      { tag: "修复", text: "内核测试不再丢弃 #[must_use] 的 AdapterProcessReport，改为断言 is_clean / 块计数" },
      { tag: "优化", text: "convert 的交织与去交织改为迭代器写法，规避 needless_range_loop 并去掉边界检查" },
      { tag: "修复", text: "漂移估计改为两轮 MAD 截尾最小二乘：普通 OLS 会被端点离群点从 20ppm 拉到 380ppm" },
      { tag: "架构", text: "依赖表按实际编译边收紧，移除 host/dsp/kernel 中三处声明但未使用的 crate 依赖" },
      { tag: "新增", text: "DriftEstimate 暴露 samples_used 与 rejected_outliers，离群计数可用于链路诊断" },
      { tag: "修复", text: "增益斜坡 off-by-one：块末差一步未抵达目标，跨块边界残留跳变，正是斜坡本该消除的咔哒" },
      { tag: "修复", text: "negotiate_format 只改了图上下文采样率，时钟与延迟模型仍按旧速率换算；现三者同步并禁止运行中切换" },
    ],
  },
  {
    version: "v4.8.1 · 修复与硬化",
    date: "第二次迭代",
    title: "编译错误与逻辑缺陷清零",
    summary:
      "修掉一批会导致无法编译的错误与静默逻辑缺陷，并把控制路径改造成真正的实时安全（零分配）。",
    changes: [
      { tag: "修复", text: "SpscRing 的 unsafe impl 缺少 const N 泛型参数（编译错误）" },
      { tag: "修复", text: "ThreadProvisioner 非法 match guard、graph.rs 非法 matches! 语法与重复 move" },
      { tag: "修复", text: "AdapterBuffer::flush 补零到了错误的切片区间，会吐出静音" },
      { tag: "修复", text: "格式协商中负数 i64 转 u64 回绕，导致排序反转" },
      { tag: "修复", text: "ClockDriftEstimator 按槽位而非插入顺序遍历环，绕回后斜率符号翻转" },
      { tag: "优化", text: "ControlRequest / EventPlane 去除 String，改为 Copy，控制路径零分配" },
      { tag: "优化", text: "LatencyReport 从 Vec 改为定容 Copy 结构，可在音频线程入队" },
      { tag: "优化", text: "StreamHandle 从 load-then-store 改为 compare_exchange 循环，消除竞态" },
      { tag: "优化", text: "漂移估计改用 64 点最小二乘回归，单点抖动不再主导斜率" },
    ],
  },
  {
    version: "v4.8.1 · 功能扩展",
    date: "第一次迭代",
    title: "拉取仓库并补齐六大能力",
    summary:
      "完整拉取原始四 crate 工作区，新增 audio-api 与 audio-clock，落地通用 API、Stream 生命周期、图事务、控制/事件面、时钟延迟模型与格式协商。",
    changes: [
      { tag: "架构", text: "保持 core → sys → {host, dsp} 单向无环依赖，新增 clock / api 保持独立" },
      { tag: "新增", text: "audio-api：stream / format / control / descriptor 四模块" },
      { tag: "新增", text: "audio-clock：clock / latency / drift 三模块" },
      { tag: "新增", text: "GraphTransaction 原子图事务，含拓扑校验与整体回滚" },
      { tag: "新增", text: "PipelineLatency 分阶段延迟模型 + LatencyStageKind 分类" },
      { tag: "新增", text: "DefaultFormatNegotiator + 零分配转换原语 convert::*" },
    ],
  },
  {
    version: "基线 · 4.8.1",
    date: "上游仓库",
    title: "无锁核心与图运行时",
    summary:
      "来自上游仓库的原始工作区：四个 crate 承载 SPSC / RCU / 延迟回收、FPU 守卫、块适配器与 DAG 运行时。",
    changes: [
      { tag: "架构", text: "audio-core / audio-sys / audio-host / audio-dsp 四 crate 物理边界" },
      { tag: "新增", text: "SPSC 环、RcuHandle、DropVTable、EmergencySlot 无锁原语" },
      { tag: "新增", text: "FpuGuard FTZ/DAZ 守卫、PerformanceProbe、ThreadProvisioner" },
      { tag: "新增", text: "AdapterBuffer 定容块适配、DspGraphHandle RCU 热替换、EventBus" },
    ],
  },
];

export const INVARIANTS: { n: string; text: string }[] = [
  { n: "#1 / #2", text: "音频线程零分配、零锁、零阻塞系统调用" },
  { n: "#3", text: "跨线程可见性仅通过 Acquire / Release" },
  { n: "#7", text: "队列满时丢弃并计数，绝不阻塞音频线程" },
  { n: "#9", text: "Provenance 保护：裸指针来自 into_raw，回收前禁止偏移" },
  { n: "#10", text: "DropVTable 在编译期固定 Layout，杜绝堆损坏" },
  { n: "#11", text: "音频线程 release 二进制强制 panic = abort" },
  { n: "#14", text: "MSRV = Rust 1.82" },
  { n: "#16", text: "动态图运行时拓扑验证" },
  { n: "#19", text: "平台资源句柄必须在 Drop 中恢复" },
];

export const METRICS = [
  { label: "工作区 crate", value: "7" },
  { label: "核心不变式", value: "20+" },
  { label: "MSRV", value: "1.82" },
  { label: "音频线程分配", value: "0" },
];

export const BUDGETS = [
  { op: "SPSC push / pop", target: "< 25 ns", crate: "audio-core" },
  { op: "pop_slice_copy(16)", target: "< 50 ns", crate: "audio-core" },
  { op: "RCU load", target: "~ 5 ns", crate: "audio-core" },
  { op: "EmergencySlot push", target: "< 15 ns", crate: "audio-core" },
  { op: "FpuGuard 切换", target: "~ 15 ns", crate: "audio-sys" },
  { op: "性能探针本体", target: "~ 10 ns", crate: "audio-sys" },
  { op: "EventBus emit", target: "< 30 ns", crate: "audio-dsp" },
  { op: "图 RCU swap", target: "~ 5 ns", crate: "audio-dsp" },
];
