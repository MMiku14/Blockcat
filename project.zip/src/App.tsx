import Nav from "./components/Nav";
import Hero from "./components/Hero";
import Overview from "./components/Overview";
import Features from "./components/Features";
import Architecture from "./components/Architecture";
import Changelog from "./components/Changelog";
import Budgets from "./components/Budgets";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen">
      <Nav />
      <main>
        <Hero />
        <Overview />
        <Features />
        <Architecture />
        <Changelog />
        <Budgets />
      </main>
      <Footer />
    </div>
  );
}
