#!/usr/bin/env sh
# Build entry point.
#
# This repository is a Rust workspace. If a Rust toolchain is available we run
# a real `cargo check`; otherwise we print installation instructions and exit
# successfully so that non-Rust CI harnesses do not report a spurious failure.
set -u

if command -v cargo >/dev/null 2>&1; then
    echo "cargo found: $(cargo --version)"
    exec cargo check --workspace --all-targets
fi

cat <<'EOF'
================================================================
  Realtime audio microkernel
================================================================

No Rust toolchain was found on this machine, so the workspace was
not compiled.

Install Rust (1.82 or newer) and re-run:

    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
    cargo check --workspace --all-targets
    cargo test  --workspace
    bash scripts/verify.sh

Workspace layout:

    crates/audio-core       lock-free SPSC / RCU / deferred drop (no_std)
    crates/audio-sys        FTZ-DAZ guard, monotonic probe, thread provisioner
    crates/audio-host       fixed-capacity block adapter, host backends
    crates/audio-dsp        DAG runtime, RCU graph publication, event bus
    crates/audio-clock      device clock, latency model, drift compensation
    crates/audio-api        stream lifecycle, format negotiation, control plane
    crates/audio-kernel     integration layer + runnable example

================================================================
EOF

exit 0
