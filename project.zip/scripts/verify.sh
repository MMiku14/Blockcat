#!/usr/bin/env sh
# Audio workspace verification.
#
# Usage:  bash scripts/verify.sh
set -eu

echo "[1/6] rustfmt"
cargo fmt --all --check

echo "[2/6] check all targets"
cargo check --workspace --all-targets

echo "[3/6] unit and documentation tests"
cargo test --workspace

echo "[4/6] clippy with warnings denied"
cargo clippy --workspace --all-targets -- -D warnings

echo "[5/6] compile benchmark executables"
cargo bench --workspace --no-run

echo "[6/6] end-to-end example"
cargo run -p audio-kernel --example offline_render >/dev/null

echo
echo "Audio workspace verification passed."
