# Architecture — Long-term Extensibility

This document captures the invariants and patterns that keep the workspace healthy when new code is added month after month.

## Core principles

### 1. Physical crate boundaries are real compilation edges

- `audio-core` — zero deps, `no_std + alloc`. Lock-free primitives only.
- `audio-sys` — allowed: `audio-core`. Platform dirty work.
- `audio-host` — allowed: `audio-core`, `audio-sys`. Forbidden: `audio-dsp`.
- `audio-dsp` — allowed: `audio-core`. Forbidden: `audio-host`.
- `audio-clock` — allowed: `audio-sys`. Clock/latency/drift.
- `audio-api` — allowed: `audio-core`. Stable surface, no host/dsp.
- `audio-kernel` — integration only. Allowed to consume everything.

**Why not declare all allowed deps?** Declaring a dep you don't use slows the build and lies about the real graph. The table in `Cargo.toml` header lists *actual* edges; the table in README lists *permitted* edges. CI does not enforce this via `cargo-deny` yet, but `scripts/verify.sh` could be extended to parse `Cargo.toml` and compare against the allow-list.

### 2. Single-producer contract is enforced by types, not docs

Old code:

```rust
// SAFETY: only control thread calls this
fn send(&self, req: ControlRequest) -> bool
```

New code:

```rust
pub struct ControlSender { inner: Arc<ChannelInner> }
impl ControlSender { pub fn send(&self, ...) }

pub struct ControlReceiver { inner: Arc<ChannelInner> }
impl ControlReceiver { pub fn poll(&self) -> Option<...> }
```

`ControlChannel::split()` yields `(Sender, Receiver)`. There is literally no `send` method on the receiver. Same for `EventSender`/`EventReceiver` and `EventHub` (sharded SPSC: one ring for audio thread, one for control thread, aggregated by a single consumer).

### 3. Audio thread never allocates, locks, or blocks

- `ControlRequest` / `EventPlane` are `Copy` + `&'static str`.
- `LatencyReport` is fixed-capacity `Copy`.
- `AdapterProcessReport` is `#[must_use]` — ignoring it is a bug, so `deny(warnings)` makes it a compile error.
- `StatsAtomic` uses `AtomicU64` for lock-free increment from audio thread.

**This is the invariant most easily broken by well-intentioned refactoring.**
Introducing `Arc<SharedState>` for concurrency is correct; putting a `Mutex`
or `RwLock` field in it that `process()` then touches is not. It happened once
already: parameters and the latency model were moved into `SharedState`, which
silently put `RwLock::read()` and `Mutex::lock()` on the audio callback.

The rule, stated so it can be checked mechanically:

> `process()` may touch **only** atomics in `SharedState` (`stream`, `stats`).
> Everything the audio thread mutates lives in `AudioState`, which it owns
> exclusively. Cross-thread publication is `try_lock` (skip on contention) or
> an SPSC event.

Ownership split:

| Data | Owner | Audio-thread access |
|---|---|---|
| `adapter`, `graph`, `clock`, `context` | `AudioState` | direct, no lock |
| `parameters` | `AudioState` | direct, no lock |
| `latency` (authoritative) | `AudioState` | direct, no lock |
| `latency_mirror` | `SharedState` | `try_lock`, skip on contention |
| `stream`, `stats` | `SharedState` | atomics only |
| `format`, `event_receiver` | `SharedState` | **never** from audio thread |

Guarded by `process_never_blocks_on_a_held_shared_lock`, which holds the mirror
lock on another thread and asserts `process()` still returns.

Also note: `process()` drains the control queue **before** the activity check.
Returning early on `Idle` used to let the queue accumulate — once the 64-slot
capacity filled, new requests were dropped, and the backlog then flooded in at
the moment of `start()`. Draining while idle is safe because `ParameterQueue`
keeps only the newest value, and `Idle → Draining` is an illegal transition
whose `Err` the `is_ok()` guard already discards. Pinned by
`idle_process_still_drains_the_control_queue`.

### 3b. Lock poisoning is counted, never swallowed

The locks in `SharedState` protect diagnostics and configuration, never audio
samples. A thread panicking while holding one poisons it. Two obvious responses
are both wrong:

- **Propagate the panic** — one control-thread panic would take the audio
  thread down with it, escalating a local fault into global silence.
- **Swallow it** — `format().unwrap_or_default()` returned 96 kHz/f32/stereo
  regardless of the real configuration, so a caller could not distinguish
  "genuinely 96 kHz" from "the lock is broken". This was the previous
  behaviour: a fault hidden inside a plausible return value.

The policy is to recover the data (`PoisonError::into_inner` — the value is
still readable, merely possibly half-updated) and increment
`KernelStats::poison_events`. A non-zero count means some thread panicked and
should raise a monitoring alert.

`is_clean()` and `is_healthy()` are deliberately separate: audio damage
(underruns, drops) and process health (poisoning) are different failure
classes, and folding them into one predicate lets each mask the other.

Helpers: `lock_counting_poison`, `read_counting_poison`,
`write_counting_poison`. `Debug` is the one exception — it takes `&self` and
diagnostic output should not mutate counters, so it renders `format` as
`Option<AudioFormat>`, where `None` means poisoned. Pinned by
`poisoned_locks_are_counted_not_swallowed`.

### 4. Kernel is split into handles

- `AudioKernel` (`&mut self` for `process`) — owns `AdapterBuffer` + `DspGraphHandle` + `ControlReceiver` + audio event sender.
- `ControlHandle` (`Clone + Send + Sync`) — owns `ControlSender` + control event sender + shared state.

Both share `Arc<SharedState>` containing:

- `StreamHandle` (atomic state machine via CAS)
- `RwLock<AudioFormat>` (cold path only; audio thread never reads it)
- `Mutex<PipelineLatencySnapshot>` (`latency_mirror`; `try_lock` from the
  realtime thread, plain `lock` from control paths where blocking is fine)
- `StatsAtomic` (lock-free increments, including `poison_events`)
- `Mutex<Option<EventHubReceiver>>` — single consumer, protected by `Mutex` to allow draining from either handle, but only one thread at a time.

This fixes the old design where `AudioKernel::process` needed `&mut` and `control().send()` needed `&`, making real multithreaded use impossible without `Arc<Mutex<Kernel>>`, which would put a lock on the audio callback.

### 5. Builder pattern with explicit runtime verification

- `KernelConfig` uses builder pattern (`with_dsp_block_size`, `with_adapter_capacity`, etc.) with explicit `validate()` so half-built or illegal configurations are rejected before allocation.

### 6. Drift estimation must be outlier-robust

Plain OLS minimizes squared residuals, so a single scheduling outlier at the edge of the window carries maximum leverage. Measured: 5000-frame outlier drags 20 ppm truth to 380 ppm — audible. Fixed via **Theil-Sen median slope estimation**, computing pairwise slopes on fixed stack arrays (at most 2016 pairwise slopes for a 64-point window). A single USB micro-frame outlier cannot dominate the median slope.

### 7. `#[must_use]` everywhere diagnostics matter

- `AdapterProcessReport`
- `RetiredDspGraph`
- `FormatConversion`

If you ignore them, `deny(warnings)` fails the build. In tests and production callbacks, inspect and handle drops, underruns, or retired memory tokens explicitly.

## What to do when adding new code

1. **New node type?** Add descriptive definitions in `audio-api`, implementation in `audio-dsp`, and test with real graph topologies.
2. **New backend?** Implement `HostAdapter` with clean OS boundaries without mutating audio core invariants.
3. **New control request?** Add variant to `ControlRequest` and handle it in `AudioKernel::handle_request`. Consider whether it belongs to audio thread (poll) or can be answered synchronously in `ControlHandle`.
4. **New event?** Add to `EventPlane`, mark `produced_by_audio_thread()` correctly, publish via the appropriate sender.
5. **New format?** Extend `SampleFormat` or `ChannelLayout`, add conversion in `convert` module, update cost model in `DefaultFormatNegotiator`.

## Deliberately removed (and when to bring them back)

Four abstractions were added in one large refactor and removed in the next
audit. All four had **zero call sites**; one was actively broken. They are
listed here so nobody — including the author — helpfully adds them back
without a concrete need.

| Removed | Why | Reintroduce when |
|---|---|---|
| `TypedStream<S>` + `typestate` + `State` (~155 lines) | Zero users. Its doctest would run under `cargo test --doc` but was never compiled. Runtime CAS already covers concurrent correctness; typestate only covers single-threaded sequencing, and stream state is shared across threads by construction. | A real call site exists whose correctness depends on "illegal transition fails to compile" rather than "illegal transition returns `Err`". |
| `NodeRegistry` (~58 lines) | Zero users. Built-in nodes are `pub const *_DESCRIPTOR`; a `const ALL: &[..]` slice covers enumeration without a `Vec`-backed table. | Node names become known only at runtime (plugin directory scanning). The table must then carry a factory `fn() -> Box<dyn DspNode>` — descriptors alone cannot construct nodes. |
| `ControlPlane` trait + `QueuedControlPlane` | **Broken, not merely unused.** `pump_events` had no access to a real receiver and returned a hardcoded `0`; `events_sender()` split a fresh hub each call, so published events had no possible consumer. Superseded by `AudioKernel` + `ControlHandle`. | A second control-plane implementation appears (e.g. out-of-process IPC) *and* both must be used generically. The trait must then hold a real `EventHubReceiver`. |
| `ControlRequest::Extension { id, payload }` | An untyped `u64` payload defers a compile-time problem into a runtime convention; receivers decode by magic number. `#[non_exhaustive]` already gives forward compatibility. | Payloads must cross a process or version boundary that the kernel itself cannot interpret (plugin-private parameters). Carry an explicit schema version and length, not a bare `u64`. |
| `HostBackendRegistry` + `BackendDescriptor` | Zero production users (only its own test). Backend selection happens at compile time via `#[cfg]`; a runtime table carried no decision. | Runtime selection among several backends inside one binary (ALSA / PipeWire / JACK with availability fallback). The table must carry probe and construct functions. |
| Pass-through `send`/`poll`/`drain`/`publish`/`drain_to` on `ControlChannel` and `EventChannel` | Back doors around the type split. The whole point of `split()` is "producers only send, consumers only poll"; offering both on the factory hands that guarantee back. They also duplicated the `Sender`/`Receiver` bodies, so the two copies would drift. | Never as pass-throughs. If a single-threaded convenience wrapper is genuinely wanted, it should be a distinct type that owns both halves, not extra methods on the factory. |

The general rule this encodes: **an abstraction earns its place by having a
caller, not by looking principled.** Speculative extensibility costs a
maintenance tax on every subsequent change and hides real defects — the
broken `pump_events` above sat behind a plausible-looking trait.

## Known intentional boundaries (not TODOs)

- ALSA / CoreAudio skeletons don't link system libs yet.
- `FormatConversion` reports that resampling is needed; resampler itself is out of scope.
- `DriftCompensation` produces ratio for ASRC, not ASRC itself.
- `AdapterBuffer::flush` doesn't render tails — node policy.
- 32-bit atomics need `portable-atomic` before enabling those targets.
