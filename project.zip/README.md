# Audio Realtime Microkernel

Rust workspace implementing the physical crate boundaries and core invariants of
the 4.8.1 architecture, extended with a stable public API layer, a device
clock / latency model, and a runnable integration layer. MSRV is Rust 1.82.

## Workspace

```
audio-core     no_std + alloc    SPSC, RCU, deferred destruction
    ▲
audio-sys                        FTZ/DAZ guard, monotonic probe, thread provisioning
    ▲
    ├── audio-host               fixed-capacity block adapter, host backends
    ├── audio-dsp                DAG runtime, RCU graph publication, event bus
    ├── audio-clock              device clock, latency model, drift compensation
    └── audio-api                stream lifecycle, format negotiation, control plane
            ▲
        audio-kernel             integration layer + runnable example
```

The arrows above show *permitted* edges. The manifests declare only the edges
that are **actually compiled**, which is a strictly smaller set:

| crate | declared deps | permitted but unused |
|---|---|---|
| `audio-core` | — | — |
| `audio-sys` | `core` | — |
| `audio-host` | — | `core`, `sys` |
| `audio-dsp` | `core` | `sys` |
| `audio-clock` | `sys` | — |
| `audio-api` | `core` | — |
| `audio-kernel` | `api`, `clock`, `dsp`, `host`, `sys` | `core` |

The two are deliberately kept apart. A Cargo dependency is a real compilation
edge, not a permission grant — declaring one you never use slows the build
without preventing a single illegal reference. `audio-host` currently needs
nothing because `AdapterBuffer`'s ring is single-threaded and has different
requirements from the cross-thread SPSC; `audio-sys` comes back when the ALSA
poll thread starts using `ThreadProvisioner`.

`audio-kernel` is the single integration point allowed to consume everything —
the architecture forbids the *reverse* edge (`dsp → host`), not
application-level composition.

## Quick start

```bash
# Full verification suite (fmt, check, test, clippy, benches, example)
bash scripts/verify.sh

# Individual steps
cargo check   --workspace --all-targets
cargo test    --workspace
cargo clippy  --workspace --all-targets -- -D warnings
cargo bench   --workspace --no-run

# End-to-end demo: 1 second of 440 Hz through a hot-swapped graph
cargo run -p audio-kernel --example offline_render
```

Workspace lints use `warnings = "deny"`; every crate explicitly inherits the
policy, including libraries, tests, benches, and examples.

---

## What each crate guarantees

### `audio-core` — lock-free primitives (`no_std` + `alloc`)

* `SpscRing<T, N>` — cache-line-padded, wait-free `push`/`pop`. Monotonic
  unbounded indices avoid the "one slot wasted" full/empty ambiguity.
* `pop_slice_copy::<M>()` is **all-or-nothing**: on `InsufficientData` it
  consumes nothing, so a partial batch can never desynchronise the reader.
* `Drop` releases the elements still in `[head, tail)` instead of leaking them.
* `RcuHandle<T>` — `Acquire` reads for the audio thread, versioned `AcqRel` swap
  for the control thread.
* `DropVTable` freezes the `Layout` at monomorphisation time, so the GC thread
  can never deallocate with a mismatched layout.
* `EmergencySlot` — the last-resort reclamation path when the GC queue is full.
  Publishing order is `vtable → Release fence → ready flag → pointer`.

### `audio-sys` — platform interaction

* `FpuGuard` — RAII FTZ/DAZ (x86_64 `stmxcsr`/`ldmxcsr`, AArch64 `FPCR.FZ`),
  with `compiler_fence(SeqCst)` on both edges so float work cannot be reordered
  past the restore.
* `read_monotonic_tick()` — invariant TSC / `CNTVCT_EL0` / `Instant` fallback.
* `PerformanceProbe` — lock-free, with nesting defence and overflow counting.
* `ThreadProvisioner` — `Strict` mode **refuses to silently downgrade** and
  leaves thread state untouched on refusal, which is what a live FOH desk needs.
  The provisioner is `!Send` and restores the original policy in `Drop`.

### `audio-host` — host adapter matrix

* `AdapterBuffer` uses fixed-capacity `Box<[f32]>` rings. The callback path
  cannot grow a collection or allocate.
* Non-integer host/DSP block ratios receive the **minimum** fixed-quantum
  reserve `D - gcd(H, D)`. Aligned block sizes therefore add exactly zero
  latency, while `384 → 512` adds 384 samples and never underruns.
* Runtime quantum changes fall back to a conservative `D - 1` reserve and report
  the added silence via `latency_added_samples`.
* `flush()` zero-pads only the *internal* processing block and returns only the
  samples corresponding to real input. Rendering an IIR/reverb tail is a DSP node
  policy and is deliberately not inferred by the host adapter.

### `audio-dsp` — graph runtime

* `DynamicGraphBuilder::compile()` runs Kahn topological sort, rejects cycles,
  self-loops, duplicate edges, and empty graphs, then allocates **once**.
* `DspGraphInner::process` executes the compiled DAG: predecessors are summed
  per-sample and multiple sinks are mixed into the graph output.
* Graph latency is the maximum accumulated latency over all input→output paths,
  not the sum.
* `DspGraphHandle::try_pin` publishes a hazard pointer for one audio callback and
  returns `None` on reentry instead of blocking. `RetiredDspGraph::try_reclaim`
  refuses reclamation while that graph is pinned — dropping the token leaks
  deliberately rather than risking a realtime use-after-free.
* `EventBus` reserves its final eight slots for critical events, counts fatal
  overflow separately, and never lets the producer cross into the consumer side.

### `audio-clock` — clock, position, latency, drift

* Three distinct positions, because conflating them is the classic source of
  "my playhead drifts" bugs:
  | field | meaning | accuracy |
  |---|---|---|
  | `total_frames_processed` | frames the DSP has finished | exact |
  | `write_frame` | frames handed to the driver | estimated |
  | `play_frame` | frames the speaker is emitting | estimated |
* `TickRate::measure()` calibrates ticks-per-second against the wall clock;
  `correct_position()` converges with a half-step filter rather than jumping, so
  driver jitter is not amplified into the UI.
* `LatencyReport` is fixed-capacity and `Copy` — the audio thread can put it on
  an event queue with zero allocation. Stages are tagged `Hardware` /
  `Buffering` / `Adaptation` / `Algorithmic`, so `hardware_floor_us()` tells you
  what no amount of configuration will ever remove.
* `ClockDriftEstimator` uses **two-pass MAD-trimmed least squares** over a
  64-sample window, iterated in insertion order after the ring wraps.
  Plain OLS is *not* outlier-robust: it minimises squared residuals, so a bad
  sample at the edge of the window carries maximum leverage. Measured on this
  workspace's own test data, one 5000-frame endpoint outlier drags a true
  20 ppm drift to 380 ppm — an audible pitch error. The estimator therefore
  fits once, derives a robust scale from the residual median
  (σ̂ = 1.4826·MAD), drops points beyond 3σ̂, and refits. A frame-level floor
  on the threshold keeps ±1-frame quantisation noise from being trimmed, and a
  majority-outlier burst falls back to the coarse fit rather than overfitting
  the survivors. `DriftEstimate::rejected_outliers` exposes the count for
  monitoring.
* `DriftCompensation` only engages above a confidence threshold **and** within
  ±1000 ppm, so one bad measurement cannot become an audible pitch shift.

### `audio-api` — the stable surface

* **Stream lifecycle** — `Idle → Preparing → Running → Draining → Idle` with
  explicit abort and error-recovery edges. Transitions use `compare_exchange`,
  so concurrent callers cannot lose an update; exactly one wins.
  A failed `prepare` returns to `Idle` (retryable) instead of stranding the
  stream in `Preparing`.
* **Format negotiation** — cost-ordered selection (`resample ≫ channel remap ≫
  bit depth`) plus allocation-free conversion primitives: saturating `f32↔i16`,
  sign-extending packed 24-bit, channel up/down-mix, interleave/deinterleave.
* **Control plane / event plane** — `ControlRequest` and `EventPlane` are `Copy`
  and contain only scalars and `&'static str`, so they ride an `audio-core` SPSC
  ring with **no allocation on the audio thread**. Dynamic strings are confined
  to the non-realtime `EventSink` side.
* **Graph transactions** — `GraphTransaction` accumulates operations and
  validates them as a unit at `commit()`: bounds, ports, duplicate edges, self
  loops, parameter ranges, and post-state cycles. On any failure the `GraphSpec`
  is left byte-for-byte unchanged. `dry_run()` lets a UI grey out illegal edits.
  Removing a node re-indexes surviving edges so references stay consistent.

### `audio-kernel` — integration

`AudioKernel::process()` is the single audio-thread entry point:

1. install the FTZ/DAZ guard,
2. drain the control queue and apply parameters,
3. pin the DSP graph and run block adaptation,
4. advance the device clock and latency model,
5. publish underrun / latency events.

`SharedGainNode` shows how a node stays addressable from the control thread:
its parameter queue lives in an `Arc`, so the kernel can push values without
ever touching graph memory. Gain changes ramp across the block instead of
stepping, which removes the click a naive implementation produces.

---

## Benchmarks

```bash
cargo bench -p audio-core
cargo bench -p audio-sys
cargo bench -p audio-host
cargo bench -p audio-dsp
cargo bench -p audio-clock
cargo bench -p audio-api
```

The runner has no third-party dependency. It measures batches and divides by the
number of logical operations, so timer overhead does not dominate nanosecond
primitives. Queue setup, refill, draining, and correctness assertions are
outside the timed regions. Results report mean, median, p99, min, and max.

Reference budgets are printed but **do not fail ordinary CI**: shared runners,
frequency scaling, and CPU migration make hard performance gates noisy. Enforce
budgets only on a pinned, fixed-frequency performance host.

| Crate | Bench coverage |
|---|---|
| `audio-core` | SPSC push/pop, batch pop, `EmergencySlot`, RCU load/swap |
| `audio-sys` | FPU guard, platform tick read, enabled/disabled probe |
| `audio-host` | aligned, mismatched, small/large host blocks, shutdown flush |
| `audio-dsp` | event emit, graph publication, 4-node graph, parameter queue |
| `audio-clock` | position estimation, frame counter, latency report, drift regression |
| `audio-api` | control/event channels, stream CAS, negotiation, conversion, transactions |

---

## Intentional boundaries

These are deliberate scope limits, not oversights:

* ALSA and CoreAudio modules are compile-time backend skeletons; they do not link
  system audio libraries yet.
* Linux rtkit/portal and Windows MMCSS integration remain platform work. The
  current provisioner implements direct Linux scheduling, macOS QoS, strict
  refusal, and explicit fallback state.
* `FormatConversion` reports *that* resampling is required; the resampler itself
  is not included. `DriftCompensation` likewise produces the ratio an ASRC should
  consume.
* `AdapterBuffer::flush` does not render effect tails — that is node policy.
* Cross-platform 32-bit atomics still require the documented `portable-atomic`
  integration before enabling those targets.

## Verification notes

CI runs on Linux, macOS, and Windows, and additionally runs
`cargo miri test -p audio-core -p audio-dsp` with `-Zmiri-strict-provenance`,
since every `unsafe` block in the workspace lives in those two crates.
