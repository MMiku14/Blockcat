//! Benchmarks for clock, latency, and drift primitives.
//!
//! Run with: `cargo bench -p audio-clock`

#[path = "../../audio-core/benches/support/mod.rs"]
mod support;

use std::time::Instant;

use audio_clock::{
    ClockDriftEstimator, DefaultDeviceClock, DeviceClock, DriftCompensation, DriftSample,
    LatencyModel, PipelineLatency, PipelineLatencySnapshot, SampleClock, TickRate,
};
use support::{benchmark, benchmark_samples, print_header, report};

const SAMPLES: usize = 100;

fn main() {
    print_header("audio-clock position, latency, and drift");

    let tick_rate = TickRate::measure_default();
    println!(
        "calibrated tick rate: {:.3} MHz",
        tick_rate.ticks_per_second / 1e6
    );

    bench_sample_clock(tick_rate);
    bench_playback_position(tick_rate);
    bench_frame_counter(tick_rate);
    bench_latency_report();
    bench_drift_estimator();
}

fn bench_sample_clock(tick_rate: TickRate) {
    let clock = SampleClock::new(96_000, tick_rate);
    let result = benchmark("sample_clock_estimated_frame", SAMPLES, 8_192, || {
        std::hint::black_box(clock.estimated_frame());
    });
    report(&result, Some(40.0));
}

fn bench_playback_position(tick_rate: TickRate) {
    let clock = DefaultDeviceClock::new(96_000, tick_rate, 512);
    clock.on_block_processed(1_048_576);
    let result = benchmark("device_clock_playback_position", SAMPLES, 8_192, || {
        std::hint::black_box(clock.playback_position());
    });
    report(&result, Some(60.0));
}

fn bench_frame_counter(tick_rate: TickRate) {
    let clock = DefaultDeviceClock::new(96_000, tick_rate, 512);
    let result = benchmark("device_clock_on_block_processed", SAMPLES, 8_192, || {
        clock.on_block_processed(512);
    });
    report(&result, Some(15.0));
}

fn bench_latency_report() {
    let snapshot = PipelineLatencySnapshot::new(PipelineLatency::new(96_000, 500, 500), 384, 128, 512);
    let result = benchmark("latency_report_5_stages", SAMPLES, 4_096, || {
        std::hint::black_box(snapshot.current_latency());
    });
    // Allocation-free fixed-capacity report; should stay well under a microsecond.
    report(&result, Some(500.0));
}

fn bench_drift_estimator() {
    const OPS: u64 = 256;
    let result = benchmark_samples("drift_add_sample_regression", SAMPLES, OPS, || {
        let mut estimator = ClockDriftEstimator::new();
        let started = Instant::now();
        for index in 0..OPS {
            let master = index * 4_800;
            estimator.add_sample(DriftSample {
                master_frames: master,
                slave_frames: master + index,
                timestamp_tick: index,
            });
        }
        let elapsed = started.elapsed();

        let mut compensation = DriftCompensation::default();
        compensation.update(&estimator, 48_000);
        std::hint::black_box(compensation);
        elapsed
    });
    // Least-squares over a 64-sample window runs on the monitoring thread.
    report(&result, None);
}
