//! # 时钟漂移估计与补偿
//!
//! 两块彼此独立的晶振（例如输入用 USB 声卡、输出用板载 DAC）永远不会
//! 精确同频。本模块估计 slave/master 的采样率比，并给出异步采样率转换
//! （ASRC）所需的补偿比。
//!
//! ## 为什么不是普通最小二乘
//!
//! 观测噪声不是高斯的：绝大多数样本精确落在直线上（量化误差 ±1 帧），
//! 偶尔混入一个被调度延迟或 USB 微帧重传打偏几千帧的离群点。
//!
//! 普通最小二乘最小化**残差平方**，因此离群点的影响被放大；更糟的是，
//! 位于观测窗口端点的离群点具有最大杠杆，对斜率的拉动为
//!
//! ```text
//! Δslope = d · (x_out − x̄) / Σ(xᵢ − x̄)²
//! ```
//!
//! 在 64 点窗口下，一个 5000 帧的端点离群足以把 20 ppm 的真实漂移拉到
//! 380 ppm —— 换算成音高就是可闻的偏移。
//!
//! 因此这里采用**两轮 MAD 截尾最小二乘**：
//!
//! 1. 先做一次粗拟合，得到残差；
//! 2. 用残差中位数（MAD）估计稳健尺度 σ̂ = 1.4826 · MAD；
//! 3. 剔除 |残差| > 3σ̂ 的点；
//! 4. 在存活点上重新拟合。
//!
//! 阈值另设帧级下限，避免把 ±1 帧的量化噪声误判为离群。
//!
//! ## 线程契约
//!
//! [`ClockDriftEstimator::add_sample`] 会触发一次排序（O(n log n)，n ≤ 64）。
//! 这属于监控/控制平面工作，**禁止在音频回调内调用**。

/// 漂移采样点：同一时刻观测到的主/从设备帧位置。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct DriftSample {
    pub master_frames: u64,
    pub slave_frames: u64,
    pub timestamp_tick: u64,
}

/// 回归窗口容量。
const WINDOW: usize = 64;
/// 低于该样本数时不产生有意义的估计。
const MIN_SAMPLES: usize = 4;
/// 正态分布下 MAD → σ 的一致性系数。
const MAD_TO_SIGMA: f64 = 1.4826;
/// 残差超过多少倍 σ̂ 视为离群点。
const OUTLIER_SIGMAS: f64 = 3.0;
/// 残差阈值下限（帧）。量化噪声约 ±1 帧，低于此值不做剔除，
/// 否则在"所有点都精确落在直线上"时 MAD=0 会把整个窗口清空。
const MIN_RESIDUAL_FRAMES: f64 = 2.0;
/// 置信度饱和所需的观测跨度（帧）。
const FULL_CONFIDENCE_SPAN: u64 = 48_000;

/// 一次线性拟合的结果：slave = slope · master + intercept。
#[derive(Debug, Clone, Copy, PartialEq)]
struct LineFit {
    slope: f64,
    intercept: f64,
}

impl LineFit {
    #[inline]
    fn predict(&self, master: f64) -> f64 {
        self.intercept + self.slope * master
    }
}

/// 一次漂移估计的完整结果，包含诊断信息。
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DriftEstimate {
    /// slave_rate / master_rate。
    pub ratio: f64,
    /// 估计置信度 [0.0, 1.0]。
    pub confidence: f64,
    /// 参与最终拟合的样本数。
    pub samples_used: usize,
    /// 被判定为离群而剔除的样本数。持续非零说明链路存在系统性抖动。
    pub rejected_outliers: usize,
}

impl DriftEstimate {
    /// 无有效估计时的中性结果。
    const fn neutral() -> Self {
        Self {
            ratio: 1.0,
            confidence: 0.0,
            samples_used: 0,
            rejected_outliers: 0,
        }
    }
}

impl Default for DriftEstimate {
    fn default() -> Self {
        Self::neutral()
    }
}

/// 时钟漂移估计器（固定容量环形窗口 + MAD 截尾最小二乘）。
#[derive(Debug)]
pub struct ClockDriftEstimator {
    window: [DriftSample; WINDOW],
    len: usize,
    /// 下一个写入位置。
    cursor: usize,
    estimate: DriftEstimate,
}

impl ClockDriftEstimator {
    pub fn new() -> Self {
        Self {
            window: [DriftSample::default(); WINDOW],
            len: 0,
            cursor: 0,
            estimate: DriftEstimate::neutral(),
        }
    }

    /// 窗口内的样本数。
    pub fn sample_count(&self) -> usize {
        self.len
    }

    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    /// 清空窗口（设备重连、流重启时调用）。
    pub fn reset(&mut self) {
        self.len = 0;
        self.cursor = 0;
        self.estimate = DriftEstimate::neutral();
    }

    /// 追加一个观测点并重新拟合。
    ///
    /// 监控线程专用；会排序，禁止在音频回调内调用。
    pub fn add_sample(&mut self, sample: DriftSample) {
        self.window[self.cursor] = sample;
        self.cursor = (self.cursor + 1) % WINDOW;
        if self.len < WINDOW {
            self.len += 1;
        }
        self.estimate = self.fit();
    }

    /// 最近一次估计的完整结果。
    pub fn estimate(&self) -> DriftEstimate {
        self.estimate
    }

    /// slave_rate / master_rate。
    pub fn ratio(&self) -> f64 {
        self.estimate.ratio
    }

    /// 估计置信度 [0.0, 1.0]。
    pub fn confidence(&self) -> f64 {
        self.estimate.confidence
    }

    /// 最近一次拟合剔除的离群点数。
    pub fn rejected_outliers(&self) -> usize {
        self.estimate.rejected_outliers
    }

    /// 漂移量（ppm）。正值表示从设备比主设备快。
    pub fn drift_ppm(&self) -> f64 {
        (self.estimate.ratio - 1.0) * 1_000_000.0
    }

    /// 在给定帧数后累计的漂移帧数。
    pub fn projected_drift_frames(&self, over_frames: u64) -> f64 {
        (self.estimate.ratio - 1.0) * over_frames as f64
    }

    /// **按插入顺序**（最旧 → 最新）遍历窗口。
    ///
    /// 环形缓冲绕回后，槽位顺序不等于插入顺序；直接按槽位遍历会算出错误的斜率。
    fn iter_in_order(&self) -> impl Iterator<Item = DriftSample> + Clone + '_ {
        let oldest = if self.len < WINDOW { 0 } else { self.cursor };
        (0..self.len).map(move |offset| self.window[(oldest + offset) % WINDOW])
    }

    /// 在满足 `keep` 的子集上做最小二乘。x 方差为零时返回 `None`。
    fn fit_subset<F>(&self, keep: F) -> Option<LineFit>
    where
        F: Fn(DriftSample) -> bool,
    {
        let mut count = 0usize;
        let mut sum_master = 0.0;
        let mut sum_slave = 0.0;
        for sample in self.iter_in_order().filter(|s| keep(*s)) {
            count += 1;
            sum_master += sample.master_frames as f64;
            sum_slave += sample.slave_frames as f64;
        }

        if count < 2 {
            return None;
        }

        let mean_master = sum_master / count as f64;
        let mean_slave = sum_slave / count as f64;

        let mut covariance = 0.0;
        let mut variance = 0.0;
        for sample in self.iter_in_order().filter(|s| keep(*s)) {
            let dx = sample.master_frames as f64 - mean_master;
            covariance += dx * (sample.slave_frames as f64 - mean_slave);
            variance += dx * dx;
        }
        // 主设备位置没有推进 ⟹ 斜率无定义。
        if variance <= f64::EPSILON {
            return None;
        }

        let slope = covariance / variance;
        Some(LineFit {
            slope,
            intercept: mean_slave - slope * mean_master,
        })
    }

    /// 两轮 MAD 截尾最小二乘。
    fn fit(&self) -> DriftEstimate {
        if self.len < MIN_SAMPLES {
            return DriftEstimate {
                ratio: 1.0,
                // 样本不足时给出线性爬升的低置信度，便于上层观察进度。
                confidence: (self.len as f64 / (MIN_SAMPLES * 2) as f64).clamp(0.0, 1.0),
                samples_used: self.len,
                rejected_outliers: 0,
            };
        }

        // 第一轮：粗拟合，仅用于识别离群点。
        let Some(coarse) = self.fit_subset(|_| true) else {
            return DriftEstimate::neutral();
        };

        // 稳健尺度：残差绝对值的中位数。
        let mut residuals = [0.0f64; WINDOW];
        for (slot, sample) in residuals.iter_mut().zip(self.iter_in_order()) {
            *slot = (sample.slave_frames as f64
                - coarse.predict(sample.master_frames as f64))
            .abs();
        }
        let mad = median_in_place(&mut residuals[..self.len]);
        let threshold = (MAD_TO_SIGMA * mad * OUTLIER_SIGMAS).max(MIN_RESIDUAL_FRAMES);

        let keep = |sample: DriftSample| {
            (sample.slave_frames as f64 - coarse.predict(sample.master_frames as f64)).abs()
                <= threshold
        };

        let kept = self.iter_in_order().filter(|s| keep(*s)).count();
        let rejected = self.len - kept;

        // 第二轮：在存活点上重新拟合。剔除过多时退回粗拟合，
        // 避免少数残余点给出一个更离谱的斜率。
        let refined = if kept >= MIN_SAMPLES {
            self.fit_subset(keep).unwrap_or(coarse)
        } else {
            coarse
        };
        let samples_used = if kept >= MIN_SAMPLES { kept } else { self.len };

        let span = self.observation_span();
        let sample_factor = samples_used as f64 / WINDOW as f64;
        let span_factor = (span as f64 / FULL_CONFIDENCE_SPAN as f64).min(1.0);

        DriftEstimate {
            ratio: refined.slope,
            confidence: (sample_factor * span_factor).clamp(0.0, 1.0),
            samples_used,
            rejected_outliers: rejected,
        }
    }

    /// 窗口首尾之间的主设备帧跨度。跨度越长，斜率越可信。
    fn observation_span(&self) -> u64 {
        let mut points = self.iter_in_order();
        let Some(first) = points.next().map(|s| s.master_frames) else {
            return 0;
        };
        let last = points
            .last()
            .map(|s| s.master_frames)
            .unwrap_or(first);
        last.saturating_sub(first)
    }
}

impl Default for ClockDriftEstimator {
    fn default() -> Self {
        Self::new()
    }
}

/// 原地求中位数。空切片返回 0.0。
fn median_in_place(values: &mut [f64]) -> f64 {
    if values.is_empty() {
        return 0.0;
    }
    values.sort_by(f64::total_cmp);
    let middle = values.len() / 2;
    if values.len() % 2 == 0 {
        (values[middle - 1] + values[middle]) / 2.0
    } else {
        values[middle]
    }
}

/// 漂移补偿参数。
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DriftCompensation {
    /// ASRC 重采样比（1.0 = 不重采样）。
    pub resample_ratio: f64,
    /// 自上次复位以来的累计漂移帧数。
    pub accumulated_drift_frames: f64,
    /// 置信度足够时才启用补偿。
    pub enabled: bool,
}

impl DriftCompensation {
    /// 启用补偿所需的最低置信度。
    pub const CONFIDENCE_THRESHOLD: f64 = 0.5;
    /// 允许的最大重采样比偏离（±1000 ppm）。超出则认为测量异常，拒绝补偿。
    pub const MAX_RATIO_DEVIATION: f64 = 0.001;

    pub const fn inactive() -> Self {
        Self {
            resample_ratio: 1.0,
            accumulated_drift_frames: 0.0,
            enabled: false,
        }
    }

    /// 依据估计器更新补偿参数。
    ///
    /// 只有在置信度达标**且**比率落在合理范围内时才启用补偿，
    /// 避免把一次坏测量放大成可听的音高偏移。
    pub fn update(&mut self, estimator: &ClockDriftEstimator, frames_processed: u64) {
        let ratio = estimator.ratio();
        let plausible = (ratio - 1.0).abs() <= Self::MAX_RATIO_DEVIATION;
        let confident = estimator.confidence() >= Self::CONFIDENCE_THRESHOLD;

        self.enabled = plausible && confident;
        self.resample_ratio = if self.enabled { ratio } else { 1.0 };
        self.accumulated_drift_frames = estimator.projected_drift_frames(frames_processed);
    }
}

impl Default for DriftCompensation {
    fn default() -> Self {
        Self::inactive()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// 生成 slave 相对 master 快 `ppm` 的采样序列。
    fn feed(estimator: &mut ClockDriftEstimator, count: usize, ppm: f64, step: u64) {
        let ratio = 1.0 + ppm / 1_000_000.0;
        for i in 0..count as u64 {
            let master = i * step;
            estimator.add_sample(DriftSample {
                master_frames: master,
                slave_frames: (master as f64 * ratio).round() as u64,
                timestamp_tick: i * 1_000,
            });
        }
    }

    #[test]
    fn perfect_sync_yields_zero_drift() {
        let mut estimator = ClockDriftEstimator::new();
        feed(&mut estimator, 32, 0.0, 4_800);
        assert!((estimator.ratio() - 1.0).abs() < 1e-9);
        assert!(estimator.drift_ppm().abs() < 0.001);
        assert_eq!(
            estimator.rejected_outliers(),
            0,
            "完全同步的数据不得触发离群剔除"
        );
    }

    #[test]
    fn positive_drift_is_detected_with_the_right_magnitude() {
        let mut estimator = ClockDriftEstimator::new();
        feed(&mut estimator, 40, 100.0, 48_000);
        assert!(estimator.ratio() > 1.0);
        assert!(
            (estimator.drift_ppm() - 100.0).abs() < 5.0,
            "got {} ppm",
            estimator.drift_ppm()
        );
        assert!(estimator.confidence() > 0.5);
    }

    #[test]
    fn negative_drift_is_detected() {
        let mut estimator = ClockDriftEstimator::new();
        feed(&mut estimator, 40, -80.0, 48_000);
        assert!(estimator.ratio() < 1.0);
        assert!((estimator.drift_ppm() + 80.0).abs() < 5.0);
    }

    #[test]
    fn quantisation_noise_is_not_mistaken_for_outliers() {
        // ±0.5 帧的舍入误差必须被 MIN_RESIDUAL_FRAMES 吸收，
        // 否则每轮都会误剔除大量正常样本。
        let mut estimator = ClockDriftEstimator::new();
        feed(&mut estimator, 40, 37.0, 48_000);
        assert_eq!(estimator.rejected_outliers(), 0);
        assert_eq!(estimator.estimate().samples_used, 40);
    }

    #[test]
    fn wrapped_window_keeps_insertion_order() {
        // 写入远超窗口容量的样本，强制环形绕回。
        let mut estimator = ClockDriftEstimator::new();
        feed(&mut estimator, WINDOW * 3, 50.0, 48_000);
        assert_eq!(estimator.sample_count(), WINDOW);
        // 若按槽位（而非插入顺序）遍历，斜率会被算错甚至变负。
        assert!(
            (estimator.drift_ppm() - 50.0).abs() < 5.0,
            "绕回后斜率错误: {} ppm",
            estimator.drift_ppm()
        );
    }

    #[test]
    fn a_single_outlier_does_not_dominate() {
        let mut estimator = ClockDriftEstimator::new();
        feed(&mut estimator, 40, 20.0, 48_000);
        let clean = estimator.drift_ppm();

        // 注入一个位于窗口右端点的坏点 —— 这是杠杆最大、对 OLS 最致命的位置。
        // 普通最小二乘会被拉到约 380 ppm；截尾拟合必须把它剔除。
        estimator.add_sample(DriftSample {
            master_frames: 40 * 48_000,
            slave_frames: 40 * 48_000 + 5_000,
            timestamp_tick: 40_000,
        });
        let perturbed = estimator.drift_ppm();

        assert_eq!(
            estimator.rejected_outliers(),
            1,
            "端点离群点必须被识别，实际漂移 {perturbed} ppm"
        );
        assert!(
            (perturbed - clean).abs() < 1.0,
            "截尾回归应抑制单点异常: {clean} -> {perturbed}"
        );
    }

    #[test]
    fn a_burst_of_outliers_falls_back_instead_of_overfitting() {
        // 超过半数样本异常时，稳健尺度本身已不可信。
        // 此时应退回粗拟合，而不是在少数残余点上给出更离谱的斜率。
        let mut estimator = ClockDriftEstimator::new();
        for i in 0..12u64 {
            let master = i * 48_000;
            let slave = if i % 2 == 0 {
                master + i * 4_000
            } else {
                master
            };
            estimator.add_sample(DriftSample {
                master_frames: master,
                slave_frames: slave,
                timestamp_tick: i,
            });
        }
        assert!(estimator.ratio().is_finite());
        assert!(estimator.estimate().samples_used >= MIN_SAMPLES);
    }

    #[test]
    fn insufficient_samples_have_low_confidence() {
        let mut estimator = ClockDriftEstimator::new();
        assert!(estimator.is_empty());
        estimator.add_sample(DriftSample {
            master_frames: 0,
            slave_frames: 0,
            timestamp_tick: 0,
        });
        assert!(estimator.confidence() < 0.5);
        assert_eq!(estimator.ratio(), 1.0);
    }

    #[test]
    fn stalled_master_does_not_divide_by_zero() {
        let mut estimator = ClockDriftEstimator::new();
        for i in 0..16 {
            estimator.add_sample(DriftSample {
                master_frames: 1_000,
                slave_frames: 1_000 + i,
                timestamp_tick: i,
            });
        }
        assert!(estimator.ratio().is_finite());
        assert_eq!(estimator.confidence(), 0.0);
    }

    #[test]
    fn compensation_requires_confidence_and_plausibility() {
        let mut estimator = ClockDriftEstimator::new();
        let mut compensation = DriftCompensation::default();
        assert!(!compensation.enabled);

        // 样本太少 → 不启用
        feed(&mut estimator, 3, 50.0, 48_000);
        compensation.update(&estimator, 48_000);
        assert!(!compensation.enabled);
        assert_eq!(compensation.resample_ratio, 1.0);

        // 充分样本 + 合理漂移 → 启用
        estimator.reset();
        feed(&mut estimator, 40, 50.0, 48_000);
        compensation.update(&estimator, 48_000);
        assert!(compensation.enabled);
        assert!((compensation.resample_ratio - estimator.ratio()).abs() < 1e-12);
        assert!((compensation.accumulated_drift_frames - 2.4).abs() < 0.5);
    }

    #[test]
    fn implausible_drift_is_refused() {
        let mut estimator = ClockDriftEstimator::new();
        // 5% 的"漂移"显然是测量故障，不是晶振误差。
        feed(&mut estimator, 40, 50_000.0, 48_000);
        let mut compensation = DriftCompensation::default();
        compensation.update(&estimator, 48_000);
        assert!(
            !compensation.enabled,
            "超出 ±1000ppm 的测量必须被拒绝，避免可听的音高偏移"
        );
        assert_eq!(compensation.resample_ratio, 1.0);
    }

    #[test]
    fn reset_clears_the_window() {
        let mut estimator = ClockDriftEstimator::new();
        feed(&mut estimator, 20, 30.0, 48_000);
        assert!(estimator.sample_count() > 0);
        estimator.reset();
        assert!(estimator.is_empty());
        assert_eq!(estimator.ratio(), 1.0);
        assert_eq!(estimator.confidence(), 0.0);
        assert_eq!(estimator.rejected_outliers(), 0);
    }
}
