//! # 设备时钟与播放位置
//!
//! 把平台无关的单调 tick（`audio-sys::read_monotonic_tick`）映射为音频
//! 采样位置，并区分三个互不相同的"当前位置"：
//!
//! | 概念 | 含义 |
//! |------|------|
//! | `total_frames_processed` | DSP 已经**算完**的帧数（精确计数） |
//! | `write_frame`            | 已经**递交给驱动**的帧位置 |
//! | `play_frame`             | 扬声器**正在发声**的帧位置（= write - 硬件提前量） |
//!
//! 只有 `total_frames_processed` 是精确的；另外两个是基于时钟的估计，
//! 因此提供 [`SampleClock::correct_position`] 供驱动回报真实位置时收敛。

use core::sync::atomic::{AtomicU64, Ordering};

use audio_sys::read_monotonic_tick;

/// 播放位置快照。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PlaybackPosition {
    /// 自流启动以来 DSP 已处理的帧总数（精确）。
    pub total_frames_processed: u64,
    /// 已递交给驱动的帧位置（估计）。
    pub write_frame: u64,
    /// 扬声器正在发声的帧位置（估计）。
    pub play_frame: u64,
    /// 采样此快照时的平台 tick。
    pub current_tick: u64,
}

impl PlaybackPosition {
    /// 播放位置对应的时间（秒）。
    pub fn play_time_seconds(&self, sample_rate: u32) -> f64 {
        if sample_rate == 0 {
            return 0.0;
        }
        self.play_frame as f64 / sample_rate as f64
    }

    /// DSP 领先扬声器的帧数（即在途缓冲量）。
    pub fn frames_in_flight(&self) -> u64 {
        self.total_frames_processed.saturating_sub(self.play_frame)
    }
}

/// tick 频率校准结果。
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TickRate {
    pub ticks_per_second: f64,
}

impl TickRate {
    /// 保守默认值：非 x86/ARM 平台上 `read_monotonic_tick` 直接返回纳秒。
    pub const NANOSECONDS: Self = Self {
        ticks_per_second: 1e9,
    };

    /// 用挂钟时间实测 tick 频率。
    ///
    /// 这是**非实时**的一次性标定动作（默认 10ms），绝不可在音频回调内调用。
    pub fn measure(duration: core::time::Duration) -> Self {
        let start_instant = std::time::Instant::now();
        let start_tick = read_monotonic_tick();
        while start_instant.elapsed() < duration {
            core::hint::spin_loop();
        }
        let elapsed_ticks = read_monotonic_tick().wrapping_sub(start_tick) as f64;
        let elapsed_seconds = start_instant.elapsed().as_secs_f64();
        if elapsed_seconds <= 0.0 || elapsed_ticks <= 0.0 {
            return Self::NANOSECONDS;
        }
        Self {
            ticks_per_second: elapsed_ticks / elapsed_seconds,
        }
    }

    /// 默认标定时长下的实测频率。
    pub fn measure_default() -> Self {
        Self::measure(core::time::Duration::from_millis(10))
    }
}

impl Default for TickRate {
    fn default() -> Self {
        Self::NANOSECONDS
    }
}

/// 采样时钟：tick → 采样位置。
#[derive(Debug)]
pub struct SampleClock {
    start_tick: u64,
    sample_rate: u32,
    ticks_per_second: f64,
    /// 由驱动回报校正的帧偏移（可正可负）。
    frame_offset: i64,
}

impl SampleClock {
    pub fn new(sample_rate: u32, tick_rate: TickRate) -> Self {
        Self {
            start_tick: read_monotonic_tick(),
            sample_rate,
            ticks_per_second: if tick_rate.ticks_per_second > 0.0 {
                tick_rate.ticks_per_second
            } else {
                1e9
            },
            frame_offset: 0,
        }
    }

    /// 重新标定并把原点归零（流重启时调用）。
    pub fn restart(&mut self, tick_rate: TickRate) {
        self.start_tick = read_monotonic_tick();
        if tick_rate.ticks_per_second > 0.0 {
            self.ticks_per_second = tick_rate.ticks_per_second;
        }
        self.frame_offset = 0;
    }

    pub fn sample_rate(&self) -> u32 {
        self.sample_rate
    }

    pub fn set_sample_rate(&mut self, rate: u32) {
        self.sample_rate = rate;
    }

    pub fn ticks_per_second(&self) -> f64 {
        self.ticks_per_second
    }

    pub fn frame_offset(&self) -> i64 {
        self.frame_offset
    }

    /// 自起始以来的 tick 增量。
    #[inline(always)]
    pub fn elapsed_ticks(&self) -> u64 {
        read_monotonic_tick().wrapping_sub(self.start_tick)
    }

    /// 自起始以来的秒数。
    #[inline(always)]
    pub fn elapsed_seconds(&self) -> f64 {
        self.elapsed_ticks() as f64 / self.ticks_per_second
    }

    /// 根据时钟估算当前帧位置（永不为负）。
    #[inline]
    pub fn estimated_frame(&self) -> u64 {
        let raw = self.elapsed_seconds() * self.sample_rate as f64;
        let estimated = raw as i64 + self.frame_offset;
        estimated.max(0) as u64
    }

    /// 驱动回报真实位置时收敛偏移。
    ///
    /// 使用半步收敛（一阶低通）而不是直接跳变，避免位置抖动被放大到 UI 上。
    pub fn correct_position(&mut self, actual_frame: u64) {
        let raw = (self.elapsed_seconds() * self.sample_rate as f64) as i64;
        let target_offset = actual_frame as i64 - raw;
        self.frame_offset = (self.frame_offset + target_offset) / 2;
    }
}

/// 设备时钟抽象。
pub trait DeviceClock: Send + 'static {
    fn playback_position(&self) -> PlaybackPosition;
    fn sample_rate(&self) -> u32;
    fn total_frames(&self) -> u64;
}

/// 默认实现：精确帧计数 + 时钟估计位置。
///
/// `total_frames` 使用原子计数，允许控制线程在音频线程推进的同时读取位置。
#[derive(Debug)]
pub struct DefaultDeviceClock {
    sample_clock: SampleClock,
    total_frames: AtomicU64,
    /// 硬件提前量：已递交但尚未发声的帧数。
    play_ahead_frames: u64,
}

impl DefaultDeviceClock {
    pub fn new(sample_rate: u32, tick_rate: TickRate, play_ahead_frames: u64) -> Self {
        Self {
            sample_clock: SampleClock::new(sample_rate, tick_rate),
            total_frames: AtomicU64::new(0),
            play_ahead_frames,
        }
    }

    /// 音频线程：处理完一个块后推进精确计数（无锁）。
    #[inline(always)]
    pub fn on_block_processed(&self, frames: usize) {
        self.total_frames
            .fetch_add(frames as u64, Ordering::Relaxed);
    }

    /// 更新硬件提前量（缓冲配置变化时）。
    pub fn set_play_ahead_frames(&mut self, frames: u64) {
        self.play_ahead_frames = frames;
    }

    /// 格式重协商后更新采样率。
    ///
    /// 采样率变化会让既有的帧计数失去意义，因此同时重置计时原点与计数。
    pub fn set_sample_rate(&mut self, rate: u32, tick_rate: TickRate) {
        self.sample_clock.set_sample_rate(rate);
        self.sample_clock.restart(tick_rate);
        self.total_frames.store(0, Ordering::Relaxed);
    }

    pub fn play_ahead_frames(&self) -> u64 {
        self.play_ahead_frames
    }

    /// 驱动回报真实播放位置。
    pub fn correct_position(&mut self, actual_play_frame: u64) {
        self.sample_clock
            .correct_position(actual_play_frame + self.play_ahead_frames);
    }

    /// 重启计时与计数。
    pub fn restart(&mut self, tick_rate: TickRate) {
        self.sample_clock.restart(tick_rate);
        self.total_frames.store(0, Ordering::Relaxed);
    }

    /// 时钟估计与精确计数之间的偏差（帧）。持续增长说明 tick 频率标定失准。
    pub fn estimation_error_frames(&self) -> i64 {
        self.sample_clock.estimated_frame() as i64
            - self.total_frames.load(Ordering::Relaxed) as i64
    }
}

impl DeviceClock for DefaultDeviceClock {
    fn playback_position(&self) -> PlaybackPosition {
        let processed = self.total_frames.load(Ordering::Relaxed);
        // write_frame 不得超过已经算完的帧数。
        let write_frame = self.sample_clock.estimated_frame().min(processed);
        PlaybackPosition {
            total_frames_processed: processed,
            write_frame,
            play_frame: write_frame.saturating_sub(self.play_ahead_frames),
            current_tick: read_monotonic_tick(),
        }
    }

    fn sample_rate(&self) -> u32 {
        self.sample_clock.sample_rate()
    }

    fn total_frames(&self) -> u64 {
        self.total_frames.load(Ordering::Relaxed)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tick_rate_measurement_is_positive() {
        let rate = TickRate::measure(core::time::Duration::from_millis(2));
        assert!(rate.ticks_per_second > 0.0);
        assert!(rate.ticks_per_second.is_finite());
    }

    #[test]
    fn sample_clock_is_monotonic() {
        let clock = SampleClock::new(48_000, TickRate::measure_default());
        let a = clock.estimated_frame();
        let b = clock.estimated_frame();
        assert!(b >= a, "clock must be monotonic: {a} -> {b}");
    }

    #[test]
    fn zero_tick_rate_falls_back_to_nanoseconds() {
        let clock = SampleClock::new(48_000, TickRate {
            ticks_per_second: 0.0,
        });
        assert_eq!(clock.ticks_per_second(), 1e9);
    }

    #[test]
    fn position_correction_converges_without_jumping() {
        let mut clock = SampleClock::new(48_000, TickRate::measure_default());
        let before = clock.frame_offset();
        assert_eq!(before, 0);

        // 驱动报告我们领先了一大截
        clock.correct_position(1_000_000);
        let first = clock.frame_offset();
        assert!(first > 0, "偏移必须朝目标移动");

        clock.correct_position(1_000_000);
        let second = clock.frame_offset();
        assert!(second >= first, "重复校正应继续收敛而不是震荡");
    }

    #[test]
    fn negative_estimates_are_clamped_to_zero() {
        let mut clock = SampleClock::new(48_000, TickRate::NANOSECONDS);
        // 人为制造一个巨大的负偏移。
        // estimated_frame() 返回 u64，内部已 max(0)，因此外部 .max(0) 无操作。
        // 此处只验证方法能正常返回、不会 panic。
        clock.correct_position(0);
        clock.correct_position(0);
        let frame = clock.estimated_frame();
        // u64 天生非负，只验证调用成功。
        std::hint::black_box(frame);
    }

    #[test]
    fn device_clock_tracks_exact_frame_count() {
        let clock = DefaultDeviceClock::new(48_000, TickRate::measure_default(), 512);
        assert_eq!(clock.total_frames(), 0);

        for _ in 0..10 {
            clock.on_block_processed(256);
        }
        assert_eq!(clock.total_frames(), 2_560);

        let position = clock.playback_position();
        assert_eq!(position.total_frames_processed, 2_560);
        assert!(
            position.write_frame <= position.total_frames_processed,
            "write 不得超过已处理帧数"
        );
        assert!(position.play_frame <= position.write_frame);
        assert!(position.current_tick > 0);
    }

    #[test]
    fn play_frame_lags_write_frame_by_the_hardware_lead() {
        let clock = DefaultDeviceClock::new(48_000, TickRate::NANOSECONDS, 512);
        for _ in 0..100 {
            clock.on_block_processed(512);
        }
        let position = clock.playback_position();
        assert_eq!(
            position.write_frame.saturating_sub(position.play_frame),
            512.min(position.write_frame)
        );
        assert!(position.frames_in_flight() >= 512);
    }

    #[test]
    fn restart_resets_counters() {
        let mut clock = DefaultDeviceClock::new(48_000, TickRate::NANOSECONDS, 0);
        clock.on_block_processed(4_096);
        assert_eq!(clock.total_frames(), 4_096);
        clock.restart(TickRate::NANOSECONDS);
        assert_eq!(clock.total_frames(), 0);
    }

    #[test]
    fn play_time_conversion() {
        let position = PlaybackPosition {
            total_frames_processed: 96_000,
            write_frame: 96_000,
            play_frame: 48_000,
            current_tick: 1,
        };
        assert!((position.play_time_seconds(48_000) - 1.0).abs() < 1e-9);
        assert_eq!(position.play_time_seconds(0), 0.0);
        assert_eq!(position.frames_in_flight(), 48_000);
    }
}
