//! # audio-clock — 设备时钟、播放位置与真实延迟模型
//!
//! | 模块 | 职责 |
//! |------|------|
//! | [`clock`]   | tick → 采样位置映射、播放位置三元组、驱动位置收敛 |
//! | [`latency`] | 分阶段的端到端延迟模型（零分配报告） |
//! | [`drift`]   | 多设备时钟漂移的最小二乘估计与 ASRC 补偿 |
//!
//! ## 依赖规则
//!
//! 仅依赖 `audio-sys`（获取平台单调 tick）。不依赖 `audio-host` / `audio-dsp`，
//! 因此可以同时服务于宿主适配层与图运行时。

#![deny(unsafe_op_in_unsafe_fn)]

pub mod clock;
pub mod drift;
pub mod latency;

pub use clock::{DefaultDeviceClock, DeviceClock, PlaybackPosition, SampleClock, TickRate};
pub use drift::{ClockDriftEstimator, DriftCompensation, DriftEstimate, DriftSample};
pub use latency::{
    LatencyModel, LatencyReport, LatencyStage, LatencyStageKind, PipelineLatency,
    PipelineLatencySnapshot, MAX_STAGES,
};
