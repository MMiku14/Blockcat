//! # 真实的端到端延迟模型
//!
//! 把"延迟"拆成可独立测量、可独立优化的阶段，而不是给出一个笼统数字：
//!
//! | 阶段 | 来源 | 能否消除 |
//! |------|------|----------|
//! | ADC / 硬件输入 | 转换器 + USB/PCIe 传输 | 否（硬件固有） |
//! | 宿主块缓冲     | 回调粒度                | 减小块大小 |
//! | 适配器预留     | 宿主/DSP 块不整除       | 对齐块大小可归零 |
//! | DSP 算法延迟   | 线性相位 FIR / 前瞻压限 | 换算法 |
//! | DAC / 硬件输出 | 转换器 + 传输           | 否（硬件固有） |
//!
//! [`LatencyReport`] 是 `Copy` 且固定容量的，音频线程可以直接把它塞进
//! 事件队列而不触发任何分配。

use core::fmt;

/// 一份报告最多容纳的阶段数。
pub const MAX_STAGES: usize = 8;

/// 延迟来源分类。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum LatencyStageKind {
    /// 硬件固有，软件无法消除
    Hardware,
    /// 缓冲导致，可通过调小块大小降低
    Buffering,
    /// 块大小不整除导致，可通过对齐消除
    Adaptation,
    /// 算法固有，需更换算法
    Algorithmic,
}

impl LatencyStageKind {
    /// 该阶段是否可以通过配置调整来降低。
    #[inline(always)]
    pub const fn is_reducible(self) -> bool {
        !matches!(self, LatencyStageKind::Hardware)
    }
}

/// 单个延迟阶段。
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct LatencyStage {
    pub name: &'static str,
    pub kind: LatencyStageKind,
    pub samples: usize,
    pub us: f64,
}

impl LatencyStage {
    const EMPTY: Self = Self {
        name: "",
        kind: LatencyStageKind::Hardware,
        samples: 0,
        us: 0.0,
    };

    pub fn new(
        name: &'static str,
        kind: LatencyStageKind,
        samples: usize,
        sample_rate: u32,
    ) -> Self {
        let us = if sample_rate == 0 {
            0.0
        } else {
            samples as f64 / sample_rate as f64 * 1_000_000.0
        };
        Self {
            name,
            kind,
            samples,
            us,
        }
    }
}

/// 端到端延迟报告（固定容量，`Copy`，零分配）。
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct LatencyReport {
    stages: [LatencyStage; MAX_STAGES],
    count: usize,
    pub total_samples: usize,
    pub total_us: f64,
    pub sample_rate: u32,
}

impl LatencyReport {
    fn empty(sample_rate: u32) -> Self {
        Self {
            stages: [LatencyStage::EMPTY; MAX_STAGES],
            count: 0,
            total_samples: 0,
            total_us: 0.0,
            sample_rate,
        }
    }

    /// 追加一个阶段。零延迟阶段与超出容量的阶段会被忽略。
    fn push(&mut self, stage: LatencyStage) {
        if stage.samples == 0 || self.count == MAX_STAGES {
            return;
        }
        self.stages[self.count] = stage;
        self.count += 1;
        self.total_samples += stage.samples;
        self.total_us += stage.us;
    }

    /// 已记录的阶段。
    pub fn stages(&self) -> &[LatencyStage] {
        &self.stages[..self.count]
    }

    /// 毫秒表示。
    pub fn total_ms(&self) -> f64 {
        self.total_us / 1_000.0
    }

    /// 其中可通过配置降低的部分（采样数）。
    pub fn reducible_samples(&self) -> usize {
        self.stages()
            .iter()
            .filter(|stage| stage.kind.is_reducible())
            .map(|stage| stage.samples)
            .sum()
    }

    /// 硬件下限：无论怎么调配置都无法低于这个值。
    pub fn hardware_floor_us(&self) -> f64 {
        self.stages()
            .iter()
            .filter(|stage| !stage.kind.is_reducible())
            .map(|stage| stage.us)
            .sum()
    }

    /// 贡献最大的阶段（优化时优先攻击的目标）。
    pub fn dominant_stage(&self) -> Option<&LatencyStage> {
        self.stages()
            .iter()
            .max_by(|a, b| a.samples.cmp(&b.samples))
    }
}

impl fmt::Display for LatencyReport {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        writeln!(
            f,
            "total {:.2} ms ({} samples @ {} Hz)",
            self.total_ms(),
            self.total_samples,
            self.sample_rate
        )?;
        for stage in self.stages() {
            writeln!(
                f,
                "  {:<24} {:>7} samples  {:>9.2} us  [{:?}]",
                stage.name, stage.samples, stage.us, stage.kind
            )?;
        }
        Ok(())
    }
}

/// 流水线延迟计算器。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PipelineLatency {
    sample_rate: u32,
    hw_input_us: u32,
    hw_output_us: u32,
}

impl PipelineLatency {
    pub const fn new(sample_rate: u32, hw_input_us: u32, hw_output_us: u32) -> Self {
        Self {
            sample_rate,
            hw_input_us,
            hw_output_us,
        }
    }

    pub const fn sample_rate(&self) -> u32 {
        self.sample_rate
    }

    pub fn set_sample_rate(&mut self, sample_rate: u32) {
        self.sample_rate = sample_rate;
    }

    fn us_to_samples(&self, us: u32) -> usize {
        (us as f64 * self.sample_rate as f64 / 1_000_000.0).round() as usize
    }

    /// 计算完整的延迟报告。
    ///
    /// - `host_block_size`：宿主回调粒度，平均引入半块延迟
    /// - `adapter_latency_samples`：`AdapterBuffer` 因块不整除而预留的静音
    /// - `dsp_algo_latency_samples`：图级算法延迟（`DspGraphInner::total_latency_samples`）
    pub fn calculate(
        &self,
        adapter_latency_samples: usize,
        dsp_algo_latency_samples: usize,
        host_block_size: usize,
    ) -> LatencyReport {
        let mut report = LatencyReport::empty(self.sample_rate);

        report.push(LatencyStage::new(
            "ADC / hardware input",
            LatencyStageKind::Hardware,
            self.us_to_samples(self.hw_input_us),
            self.sample_rate,
        ));
        report.push(LatencyStage::new(
            "host block buffering",
            LatencyStageKind::Buffering,
            host_block_size / 2,
            self.sample_rate,
        ));
        report.push(LatencyStage::new(
            "adapter reserve",
            LatencyStageKind::Adaptation,
            adapter_latency_samples,
            self.sample_rate,
        ));
        report.push(LatencyStage::new(
            "DSP algorithmic",
            LatencyStageKind::Algorithmic,
            dsp_algo_latency_samples,
            self.sample_rate,
        ));
        report.push(LatencyStage::new(
            "DAC / hardware output",
            LatencyStageKind::Hardware,
            self.us_to_samples(self.hw_output_us),
            self.sample_rate,
        ));

        report
    }

    /// 输入→输出的单程硬件延迟（微秒）。
    pub const fn hardware_roundtrip_us(&self) -> u32 {
        self.hw_input_us + self.hw_output_us
    }
}

/// 延迟模型抽象。
pub trait LatencyModel: Send + Sync + 'static {
    /// 当前配置下的完整报告。
    fn current_latency(&self) -> LatencyReport;
    /// 端到端往返延迟（微秒）。
    fn estimated_roundtrip_us(&self) -> f64;
}

/// 带有当前运行参数的延迟模型快照。
#[derive(Debug, Clone, Copy)]
pub struct PipelineLatencySnapshot {
    pipeline: PipelineLatency,
    adapter_latency_samples: usize,
    dsp_algo_latency_samples: usize,
    host_block_size: usize,
}

impl PipelineLatencySnapshot {
    pub const fn new(
        pipeline: PipelineLatency,
        adapter_latency_samples: usize,
        dsp_algo_latency_samples: usize,
        host_block_size: usize,
    ) -> Self {
        Self {
            pipeline,
            adapter_latency_samples,
            dsp_algo_latency_samples,
            host_block_size,
        }
    }

    pub fn set_adapter_latency(&mut self, samples: usize) {
        self.adapter_latency_samples = samples;
    }

    pub fn set_dsp_latency(&mut self, samples: usize) {
        self.dsp_algo_latency_samples = samples;
    }

    pub fn set_host_block_size(&mut self, block_size: usize) {
        self.host_block_size = block_size;
    }

    /// 格式重协商后更新采样率。
    ///
    /// 不同步这一项，延迟报告会把新的帧数按旧采样率换算成微秒。
    pub fn set_sample_rate(&mut self, sample_rate: u32) {
        self.pipeline.set_sample_rate(sample_rate);
    }
}

impl LatencyModel for PipelineLatencySnapshot {
    fn current_latency(&self) -> LatencyReport {
        self.pipeline.calculate(
            self.adapter_latency_samples,
            self.dsp_algo_latency_samples,
            self.host_block_size,
        )
    }

    fn estimated_roundtrip_us(&self) -> f64 {
        // 采集链与回放链各走一遍完整流水线。
        self.current_latency().total_us * 2.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pipeline() -> PipelineLatency {
        PipelineLatency::new(96_000, 500, 500)
    }

    #[test]
    fn latency_breakdown_is_complete_and_ordered() {
        let report = pipeline().calculate(256, 128, 512);
        assert_eq!(report.stages().len(), 5);
        assert_eq!(report.stages()[0].name, "ADC / hardware input");
        assert_eq!(report.stages()[4].name, "DAC / hardware output");

        let stage_sum: usize = report.stages().iter().map(|s| s.samples).sum();
        assert_eq!(stage_sum, report.total_samples);
        assert!(report.total_us > 0.0);
        // 现实的端到端延迟应在 1-50 ms 之间
        assert!((1_000.0..50_000.0).contains(&report.total_us));
    }

    #[test]
    fn zero_length_stages_are_omitted() {
        // 完全对齐 + 无算法延迟 ⟹ 只剩两个硬件阶段 + 块缓冲
        let report = pipeline().calculate(0, 0, 512);
        assert_eq!(report.stages().len(), 3);
        assert!(report
            .stages()
            .iter()
            .all(|stage| stage.samples > 0));
    }

    #[test]
    fn hardware_floor_excludes_reducible_stages() {
        let report = pipeline().calculate(384, 128, 1_024);
        let floor = report.hardware_floor_us();
        assert!(floor > 0.0);
        assert!(floor < report.total_us, "可降低部分必须存在");

        let reducible = report.reducible_samples();
        assert_eq!(reducible, 512 + 384 + 128, "半块 + 适配 + 算法");
    }

    #[test]
    fn dominant_stage_identifies_the_optimisation_target() {
        // 巨大的宿主块应当成为主导项
        let report = pipeline().calculate(8, 0, 4_096);
        let dominant = report.dominant_stage().expect("report has stages");
        assert_eq!(dominant.name, "host block buffering");
        assert_eq!(dominant.kind, LatencyStageKind::Buffering);
        assert!(dominant.kind.is_reducible());
    }

    #[test]
    fn aligned_blocks_remove_the_adaptation_stage() {
        let aligned = pipeline().calculate(0, 0, 512);
        let mismatched = pipeline().calculate(384, 0, 512);
        assert!(mismatched.total_samples > aligned.total_samples);
        assert!(aligned
            .stages()
            .iter()
            .all(|stage| stage.kind != LatencyStageKind::Adaptation));
    }

    #[test]
    fn report_never_overflows_its_fixed_capacity() {
        let report = pipeline().calculate(1, 1, 2);
        assert!(report.stages().len() <= MAX_STAGES);
    }

    #[test]
    fn snapshot_tracks_runtime_changes() {
        let mut snapshot = PipelineLatencySnapshot::new(pipeline(), 0, 0, 512);
        let baseline = snapshot.current_latency().total_samples;

        snapshot.set_adapter_latency(384);
        snapshot.set_dsp_latency(128);
        let updated = snapshot.current_latency().total_samples;

        assert_eq!(updated, baseline + 384 + 128);
        assert!((snapshot.estimated_roundtrip_us()
            - snapshot.current_latency().total_us * 2.0)
            .abs()
            < 1e-9);
    }

    #[test]
    fn hardware_roundtrip_sums_both_directions() {
        assert_eq!(PipelineLatency::new(48_000, 1_000, 2_000).hardware_roundtrip_us(), 3_000);
    }

    #[test]
    fn zero_sample_rate_does_not_divide_by_zero() {
        let report = PipelineLatency::new(0, 500, 500).calculate(128, 0, 512);
        assert!(report.total_us.is_finite());
    }

    #[test]
    fn report_renders_a_human_readable_breakdown() {
        let text = pipeline().calculate(384, 128, 512).to_string();
        assert!(text.contains("total"));
        assert!(text.contains("adapter reserve"));
    }
}
