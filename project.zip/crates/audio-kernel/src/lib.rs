//! # audio-kernel — 集成层
//!
//! 把六个 crate 组装成一个可运行的实时音频内核：
//!
//! ```text
//!   audio-api ──┐                 ┌── audio-host  (AdapterBuffer)
//!   audio-clock ┼── audio-kernel ─┼── audio-dsp   (DspGraphHandle)
//!   audio-core ─┘                 └── audio-sys   (FpuGuard)
//! ```
//!
//! [`AudioKernel::process`] 是唯一的音频线程入口，它在一次回调内完成：
//!
//! 1. 装载 FTZ/DAZ 守卫（§3.1）
//! 2. 排空控制队列并应用参数（零分配，§5.3）
//! 3. Pin 当前 DSP 图并跑块适配（§2.3 / §3.2）
//! 4. 推进设备时钟、更新延迟模型（audio-clock）
//! 5. 通过事件面上报欠载/过载（§4.1）
//!
//! 全程无分配、无锁、无阻塞系统调用。

#![deny(unsafe_op_in_unsafe_fn)]

pub mod kernel;
pub mod nodes;

pub use kernel::{AudioKernel, KernelConfig, KernelError, KernelStats};
pub use nodes::{SharedGainNode, SharedParameter};
