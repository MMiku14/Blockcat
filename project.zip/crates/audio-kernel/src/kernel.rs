//! 音频内核：把宿主适配、图运行时、时钟模型与控制面组装为一个整体。
//!
//! ## 长期架构目标
//!
//! * **契约由类型保证** — `ControlSender` 只有 `send`，`ControlReceiver` 只有
//!   `poll`。编译器拦住误用。
//! * **多生产者不靠单 SPSC** — 控制面与音频面各用一条事件 SPSC，
//!   应用线程通过 `EventHub` 聚合排空。
//! * **内核可并发** — `AudioKernel`（音频侧，`&mut`）与 `ControlHandle`
//!   （控制侧，`Clone + Send + Sync`）共享 `Arc<SharedState>`。
//! * **统计原子化** — 音频线程无锁递增，原子快照。

use std::sync::{
    atomic::{AtomicU64, Ordering},
    Arc, Mutex, RwLock,
};

use audio_api::{
    AudioFormat, ChannelLayout, ControlChannel, ControlReceiver, ControlRequest, ControlSender,
    DefaultFormatNegotiator, EventHub, EventHubReceiver, EventHubSender, EventPlane, EventSink,
    FormatConversion, FormatError, FormatNegotiator, SampleFormat, StreamConfig, StreamError,
    StreamHandle, StreamState,
};
use audio_clock::{
    DefaultDeviceClock, DeviceClock, LatencyModel, LatencyReport, PipelineLatency,
    PipelineLatencySnapshot, PlaybackPosition, TickRate,
};
use audio_dsp::{DspGraphHandle, DspGraphInner, ProcessContext, RetiredDspGraph};
use audio_host::{AdapterBuffer, AdapterProcessReport};
use audio_sys::FpuGuard;

use crate::nodes::SharedParameter;

// ---------------------------------------------------------------------------
// 配置与错误
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct KernelConfig {
    pub stream: StreamConfig,
    pub dsp_block_size: usize,
    pub adapter_capacity: usize,
    pub hw_input_us: u32,
    pub hw_output_us: u32,
}

impl KernelConfig {
    pub fn new(stream: StreamConfig) -> Self {
        Self {
            stream,
            dsp_block_size: 512,
            adapter_capacity: 4_096,
            hw_input_us: 500,
            hw_output_us: 500,
        }
    }

    pub fn with_dsp_block_size(mut self, size: usize) -> Self {
        self.dsp_block_size = size;
        self
    }

    pub fn with_adapter_capacity(mut self, cap: usize) -> Self {
        self.adapter_capacity = cap;
        self
    }

    pub fn with_hw_latency(mut self, input_us: u32, output_us: u32) -> Self {
        self.hw_input_us = input_us;
        self.hw_output_us = output_us;
        self
    }

    pub fn validate(&self) -> Result<(), KernelError> {
        self.stream.validate()?;
        if self.adapter_capacity < self.dsp_block_size.saturating_mul(2) {
            return Err(KernelError::AdapterCapacityTooSmall);
        }
        if self.dsp_block_size == 0 || self.dsp_block_size > 8_192 {
            return Err(KernelError::InvalidDspBlockSize);
        }
        Ok(())
    }
}

impl Default for KernelConfig {
    fn default() -> Self {
        Self::new(StreamConfig::default())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum KernelError {
    Stream(StreamError),
    Format(FormatError),
    AdapterCapacityTooSmall,
    InvalidDspBlockSize,
    NotIdleForFormatChange,
}

impl core::fmt::Display for KernelError {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            KernelError::Stream(e) => write!(f, "stream error: {e}"),
            KernelError::Format(e) => write!(f, "format error: {e}"),
            KernelError::AdapterCapacityTooSmall => {
                f.write_str("adapter capacity must hold at least two DSP blocks")
            }
            KernelError::InvalidDspBlockSize => f.write_str("invalid DSP block size"),
            KernelError::NotIdleForFormatChange => {
                f.write_str("format negotiation requires idle state")
            }
        }
    }
}

impl std::error::Error for KernelError {}

impl From<StreamError> for KernelError {
    fn from(e: StreamError) -> Self {
        KernelError::Stream(e)
    }
}
impl From<FormatError> for KernelError {
    fn from(e: FormatError) -> Self {
        KernelError::Format(e)
    }
}

// ---------------------------------------------------------------------------
// 统计
// ---------------------------------------------------------------------------

#[derive(Debug, Default)]
struct StatsAtomic {
    callbacks: AtomicU64,
    processed_blocks: AtomicU64,
    underrun_samples: AtomicU64,
    dropped_input: AtomicU64,
    dropped_output: AtomicU64,
    control_requests_applied: AtomicU64,
    graph_pin_failures: AtomicU64,
    graph_versions_published: AtomicU64,
    /// 遇到中毒锁的次数。非零表示某处线程在持锁时 panic 过。
    poison_events: AtomicU64,
}

impl StatsAtomic {
    fn snapshot(&self) -> KernelStats {
        KernelStats {
            callbacks: self.callbacks.load(Ordering::Relaxed),
            processed_blocks: self.processed_blocks.load(Ordering::Relaxed),
            underrun_samples: self.underrun_samples.load(Ordering::Relaxed),
            dropped_input_samples: self.dropped_input.load(Ordering::Relaxed),
            dropped_output_samples: self.dropped_output.load(Ordering::Relaxed),
            control_requests_applied: self.control_requests_applied.load(Ordering::Relaxed),
            graph_pin_failures: self.graph_pin_failures.load(Ordering::Relaxed),
            graph_versions_published: self.graph_versions_published.load(Ordering::Relaxed),
            poison_events: self.poison_events.load(Ordering::Relaxed),
        }
    }
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct KernelStats {
    pub callbacks: u64,
    pub processed_blocks: u64,
    pub underrun_samples: u64,
    pub dropped_input_samples: u64,
    pub dropped_output_samples: u64,
    pub control_requests_applied: u64,
    pub graph_pin_failures: u64,
    pub graph_versions_published: u64,
    /// 遇到中毒锁的次数。非零表示某处线程在持锁时 panic 过，
    /// 此后读到的配置/延迟可能是半更新状态。应当触发监控告警。
    pub poison_events: u64,
}

impl KernelStats {
    /// 是否出现过任何形式的音频损伤。
    ///
    /// 不含 `poison_events` —— 中毒是**进程健康**问题而非音频损伤，
    /// 单独由 [`Self::is_healthy`] 判定，以免两类故障互相掩盖。
    pub const fn is_clean(&self) -> bool {
        self.underrun_samples == 0
            && self.dropped_input_samples == 0
            && self.dropped_output_samples == 0
            && self.graph_pin_failures == 0
    }

    /// 进程是否未发生过线程 panic 导致的锁中毒。
    pub const fn is_healthy(&self) -> bool {
        self.poison_events == 0
    }
}

// ---------------------------------------------------------------------------
// 共享状态
// ---------------------------------------------------------------------------

/// 跨线程共享状态。
///
/// **不变式：`process()` 绝不在这里获取任何会阻塞的锁。**
/// 音频线程只允许触碰 `stream`（原子）与 `stats`（原子）。
/// 其余字段仅供控制/应用线程使用，或由音频线程以 `try_lock` 尽力更新。
///
/// 参数表与延迟模型的**权威副本**在 [`AudioState`] 里，由音频线程独占，
/// 因此热路径完全无锁。这里的 `latency` 只是给控制面读取的镜像。
struct SharedState {
    stream: StreamHandle,
    format: RwLock<AudioFormat>,
    /// 控制面可读的延迟镜像。音频线程用 `try_lock` 更新，竞争时跳过 ——
    /// 这是诊断数据，漏一帧下次回调就补上，绝不值得阻塞音频线程。
    latency_mirror: Mutex<PipelineLatencySnapshot>,
    stats: StatsAtomic,
    /// 唯一的聚合接收器，`Mutex` 保证单消费者契约。
    event_receiver: Mutex<Option<EventHubReceiver<256>>>,
}

impl SharedState {
    fn new(format: AudioFormat, latency: PipelineLatencySnapshot, stream_cfg: StreamConfig) -> Self {
        Self {
            stream: StreamHandle::new(stream_cfg),
            format: RwLock::new(format),
            latency_mirror: Mutex::new(latency),
            stats: StatsAtomic::default(),
            event_receiver: Mutex::new(None),
        }
    }
}

// ---------------------------------------------------------------------------
// 锁中毒（poison）策略
// ---------------------------------------------------------------------------
//
// `SharedState` 里的锁只保护**诊断与配置**数据，从不保护音频样本。
// 一个线程在持锁期间 panic 会让锁中毒，此时被保护的数据可能处于半更新状态。
//
// 本项目的取舍：**中毒不传播 panic，但必须可观测。**
//
// - 传播 panic：控制线程的一次 panic 会连带打死音频线程，把局部故障
//   升级成全局静音。对实时音频而言这是最坏结果。
// - 静默吞掉：`unwrap_or_default()` 会返回一个与实际配置无关的格式，
//   调用方无从分辨「真的是 96kHz」还是「锁中毒了」。这是之前的做法，
//   等于把故障藏进正常返回值。
//
// 因此统一走 `PoisonPolicy`：读取中毒锁里的数据（`into_inner`，数据本身
// 仍然可读），同时递增 `poison_events` 计数。计数非零即表示某处 panic 过，
// 应当被监控告警捕获。

/// 从可能中毒的 `Mutex` 中取出守卫，并在中毒时计数。
///
/// 中毒不意味着数据不可用 —— `PoisonError` 仍持有守卫。这里取出它，
/// 让调用方拿到「可能陈旧但类型正确」的值，而不是一个凭空捏造的默认值。
#[inline]
fn lock_counting_poison<'a, T>(
    lock: &'a Mutex<T>,
    poison_counter: &AtomicU64,
) -> std::sync::MutexGuard<'a, T> {
    match lock.lock() {
        Ok(guard) => guard,
        Err(poisoned) => {
            poison_counter.fetch_add(1, Ordering::Relaxed);
            poisoned.into_inner()
        }
    }
}

/// `RwLock` 读侧的同等处理。
#[inline]
fn read_counting_poison<'a, T>(
    lock: &'a RwLock<T>,
    poison_counter: &AtomicU64,
) -> std::sync::RwLockReadGuard<'a, T> {
    match lock.read() {
        Ok(guard) => guard,
        Err(poisoned) => {
            poison_counter.fetch_add(1, Ordering::Relaxed);
            poisoned.into_inner()
        }
    }
}

/// `RwLock` 写侧的同等处理。
#[inline]
fn write_counting_poison<'a, T>(
    lock: &'a RwLock<T>,
    poison_counter: &AtomicU64,
) -> std::sync::RwLockWriteGuard<'a, T> {
    match lock.write() {
        Ok(guard) => guard,
        Err(poisoned) => {
            poison_counter.fetch_add(1, Ordering::Relaxed);
            poisoned.into_inner()
        }
    }
}

// ---------------------------------------------------------------------------
// 音频线程独占
// ---------------------------------------------------------------------------

/// 音频线程**独占**的状态。访问全部无锁 —— 这是实时安全的根基。
///
/// 参数表与延迟模型的权威副本放在这里而非 `SharedState`，
/// 就是为了让 `process()` 不需要任何锁。
struct AudioState {
    adapter: AdapterBuffer,
    graph: DspGraphHandle,
    context: ProcessContext,
    clock: DefaultDeviceClock,
    control_rx: ControlReceiver<64>,
    audio_event_tx: audio_api::EventSender<256>,
    /// 权威延迟模型。控制面读的是 `SharedState::latency_mirror`。
    latency: PipelineLatencySnapshot,
    /// node_id → 可寻址参数。表很小，线性查找，零分配零锁。
    parameters: Vec<(u32, SharedParameter)>,
    last_reported_latency: usize,
}

// ---------------------------------------------------------------------------
// 对外句柄
// ---------------------------------------------------------------------------

/// 音频侧句柄。`process` 取 `&mut self`，保证同一时刻只有一个回调在跑。
///
/// 事件接收端存放在 `shared` 中而非此处：这样 `AudioKernel` 与
/// `ControlHandle` 排空事件时走的是同一条路径，不存在"两个接收器"的歧义。
pub struct AudioKernel {
    shared: Arc<SharedState>,
    audio: AudioState,
    control_tx: ControlSender<64>,
    control_event_tx: audio_api::EventSender<256>,
    event_hub_sender: EventHubSender<256>,
}

impl core::fmt::Debug for AudioKernel {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        // Debug 不能计数 poison（`fmt` 取 `&self`，且诊断输出本身不该
        // 产生副作用），因此这里显式区分中毒与否，让排障时一眼看见。
        let format = match self.shared.format.read() {
            Ok(guard) => Some(*guard),
            Err(_) => None,
        };
        f.debug_struct("AudioKernel")
            .field("state", &self.shared.stream.state())
            .field("format", &format)
            .field("graph_version", &self.audio.graph.version())
            .field("adapter", &self.audio.adapter)
            .field("parameters", &self.audio.parameters.len())
            .field("stats", &self.shared.stats.snapshot())
            .finish()
    }
}

/// 控制侧句柄 —— `Clone + Send + Sync`，不持有任何音频缓冲。
///
/// 刻意**不**持有 `EventHub`：事件排空统一走 `shared.event_receiver`
/// （由 `Mutex` 保证单消费者），发布走 `control_event_tx`。
/// 多存一份 hub 只会给"从哪条路排空"制造第二个答案。
#[derive(Clone)]
pub struct ControlHandle {
    shared: Arc<SharedState>,
    control_tx: ControlSender<64>,
    control_event_tx: audio_api::EventSender<256>,
}

impl core::fmt::Debug for ControlHandle {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("ControlHandle")
            .field("state", &self.shared.stream.state())
            .field("control_len", &self.control_tx.len())
            .field("stats", &self.shared.stats.snapshot())
            .finish()
    }
}

impl ControlHandle {
    pub fn state(&self) -> StreamState {
        self.shared.stream.state()
    }

    pub fn stream(&self) -> &StreamHandle {
        &self.shared.stream
    }

    pub fn send_request(&self, request: ControlRequest) -> bool {
        self.control_tx.send(request)
    }

    pub fn send(&self, request: ControlRequest) -> bool {
        self.send_request(request)
    }

    pub fn publish_control_event(&self, event: EventPlane) -> bool {
        self.control_event_tx.publish(event)
    }

    /// 当前协商格式。
    ///
    /// 锁中毒时返回**最后写入的真实值**（`into_inner`）并计数，
    /// 而不是凭空捏造一个默认格式 —— 后者会让调用方分不清
    /// 「真的是 96kHz」和「锁坏了」。
    pub fn format(&self) -> AudioFormat {
        *read_counting_poison(&self.shared.format, &self.shared.stats.poison_events)
    }

    pub fn stats(&self) -> KernelStats {
        self.shared.stats.snapshot()
    }

    /// 控制面读取延迟镜像。
    ///
    /// 可能比音频线程的权威副本落后一个回调（更新用 `try_lock`，
    /// 竞争时跳过）。对诊断与 UI 展示而言这个精度足够。
    ///
    /// 锁中毒时仍返回镜像里的值并计数：数据可能陈旧，但类型与量纲正确。
    pub fn latency_report(&self) -> LatencyReport {
        lock_counting_poison(&self.shared.latency_mirror, &self.shared.stats.poison_events)
            .current_latency()
    }

    /// 应用线程：排空音频面与控制面事件。
    ///
    /// `Mutex` 保证同一时刻只有一个消费者，满足 SPSC 的单消费者契约。
    pub fn pump_events(&self, sink: &dyn EventSink) -> usize {
        let guard = lock_counting_poison(
            &self.shared.event_receiver,
            &self.shared.stats.poison_events,
        );
        guard.as_ref().map_or(0, |receiver| receiver.drain_to(sink))
    }
}

// ---------------------------------------------------------------------------
// 构造与 API
// ---------------------------------------------------------------------------

impl AudioKernel {
    pub fn new(config: KernelConfig, graph: Box<DspGraphInner>) -> Result<Self, KernelError> {
        config.validate()?;

        let format = AudioFormat::new(
            config.stream.sample_rate,
            SampleFormat::Float32,
            match config.stream.output_channels {
                1 => ChannelLayout::Mono,
                2 => ChannelLayout::Stereo,
                6 => ChannelLayout::Surround51,
                8 => ChannelLayout::Surround71,
                other => ChannelLayout::Custom(other),
            },
        );

        let dsp_latency = graph.total_latency_samples();
        let pipeline = PipelineLatency::new(
            config.stream.sample_rate,
            config.hw_input_us,
            config.hw_output_us,
        );
        let latency_snapshot = PipelineLatencySnapshot::new(
            pipeline,
            0,
            dsp_latency,
            config.stream.block_size,
        );

        let shared = Arc::new(SharedState::new(
            format,
            latency_snapshot,
            config.stream,
        ));

        let (control_tx, control_rx) = ControlChannel::<64>::new().split();

        // 事件面拆成双 SPSC：音频侧与控制侧各持一个发送端，
        // 唯一的接收端交给 shared，由 Mutex 保证单消费者。
        let (event_hub_sender, event_hub_receiver) = EventHub::<256>::new().split();

        // 构造期独占，不可能中毒；用 expect 而非静默忽略 —— 若真失败，
        // 后续所有事件排空都会静默返回 0，那才是最难查的故障。
        shared
            .event_receiver
            .lock()
            .expect("freshly constructed mutex cannot be poisoned")
            .replace(event_hub_receiver);

        let audio = AudioState {
            adapter: AdapterBuffer::new(config.dsp_block_size, config.adapter_capacity),
            graph: DspGraphHandle::new(graph),
            context: ProcessContext {
                sample_rate: config.stream.sample_rate,
                block_size: config.dsp_block_size,
            },
            clock: DefaultDeviceClock::new(
                config.stream.sample_rate,
                TickRate::NANOSECONDS,
                config.dsp_block_size as u64,
            ),
            control_rx,
            audio_event_tx: event_hub_sender.audio.clone(),
            latency: latency_snapshot,
            parameters: Vec::new(),
            last_reported_latency: 0,
        };

        Ok(Self {
            shared,
            audio,
            control_tx,
            control_event_tx: event_hub_sender.control.clone(),
            event_hub_sender,
        })
    }

    pub fn control(&self) -> &ControlSender<64> {
        &self.control_tx
    }

    pub fn events(&self) -> &EventHubSender<256> {
        &self.event_hub_sender
    }

    /// 应用线程：排空音频面与控制面事件。
    ///
    /// 与 [`ControlHandle::pump_events`] 走同一条路径 —— 共享状态里那唯一的
    /// 接收端。两处若各持一个接收器，就会变成双消费者，破坏 SPSC 不变式。
    pub fn pump_events(&self, sink: &dyn EventSink) -> usize {
        let guard = lock_counting_poison(
            &self.shared.event_receiver,
            &self.shared.stats.poison_events,
        );
        guard.as_ref().map_or(0, |receiver| receiver.drain_to(sink))
    }

    pub fn control_handle(&self) -> ControlHandle {
        ControlHandle {
            shared: Arc::clone(&self.shared),
            control_tx: self.control_tx.clone(),
            control_event_tx: self.control_event_tx.clone(),
        }
    }

    /// 注册一个可被 [`ControlRequest::SetGain`] 等寻址的参数。
    ///
    /// 取 `&mut self`，因此参数表可以放在音频线程独占的 [`AudioState`] 里，
    /// `process()` 查表时无需加锁。
    pub fn register_parameter(&mut self, node_id: u32, parameter: SharedParameter) {
        self.audio.parameters.push((node_id, parameter));
    }

    pub fn stream(&self) -> &StreamHandle {
        &self.shared.stream
    }

    pub fn state(&self) -> StreamState {
        self.shared.stream.state()
    }

    pub fn start(&mut self) -> Result<(), KernelError> {
        let from = self.shared.stream.transition(StreamState::Preparing)?;
        self.shared.stream.transition(StreamState::Running)?;

        let _ = self.pump_events(&NoopSink);

        let event = EventPlane::StreamStateChanged {
            from: from as u8,
            to: StreamState::Running as u8,
        };
        self.control_event_tx.publish(event);
        self.audio.audio_event_tx.publish(event);
        Ok(())
    }

    pub fn stop(&mut self) -> Result<Vec<f32>, KernelError> {
        self.shared.stream.transition(StreamState::Draining)?;

        let context = self.audio.context;
        let tail = match self.audio.graph.try_pin() {
            Some(mut guard) => self
                .audio
                .adapter
                .flush(|input, output| guard.process(input, output, &context)),
            None => self.audio.adapter.flush(|input, output| {
                output[..input.len()].copy_from_slice(input);
            }),
        };

        self.shared.stream.transition(StreamState::Idle)?;

        let event = EventPlane::StreamStateChanged {
            from: StreamState::Draining as u8,
            to: StreamState::Idle as u8,
        };
        self.control_event_tx.publish(event);
        self.audio.audio_event_tx.publish(event);

        Ok(tail)
    }

    /// 当前协商格式。中毒时返回最后写入的真实值并计数（见 `format()` 说明）。
    pub fn format(&self) -> AudioFormat {
        *read_counting_poison(&self.shared.format, &self.shared.stats.poison_events)
    }

    pub fn negotiate_format(
        &mut self,
        host_formats: &[AudioFormat],
    ) -> Result<FormatConversion, KernelError> {
        if self.shared.stream.state().is_active() {
            return Err(KernelError::NotIdleForFormatChange);
        }

        let current_format = self.format();
        let negotiator = DefaultFormatNegotiator;
        let conversion = negotiator.negotiate(host_formats, &current_format)?;
        let sample_rate = conversion.target_format.sample_rate;

        *write_counting_poison(&self.shared.format, &self.shared.stats.poison_events) =
            conversion.target_format;
        self.audio.context.sample_rate = sample_rate;

        // 控制路径（流已停止），可以安全地更新权威副本并同步镜像。
        self.audio
            .latency
            .set_host_block_size(self.shared.stream.config().block_size);
        if sample_rate != self.audio.clock.sample_rate() {
            self.audio.latency.set_sample_rate(sample_rate);
        }
        // 控制路径可以阻塞等锁；用 lock 而非 try_lock，确保镜像与权威副本一致。
        *lock_counting_poison(&self.shared.latency_mirror, &self.shared.stats.poison_events) =
            self.audio.latency;

        if sample_rate != self.audio.clock.sample_rate() {
            self.audio
                .clock
                .set_sample_rate(sample_rate, TickRate::NANOSECONDS);
            self.audio.adapter.reset();
            self.audio.last_reported_latency = 0;
        }

        let event = EventPlane::FormatNegotiated {
            sample_rate,
            channels: conversion.target_format.channels(),
            bit_depth: conversion.target_format.sample_format.bit_depth().bits(),
        };
        self.control_event_tx.publish(event);
        self.audio.audio_event_tx.publish(event);

        Ok(conversion)
    }

    #[must_use = "the retired graph must be reclaimed off the audio thread"]
    pub fn publish_graph(&mut self, graph: Box<DspGraphInner>) -> RetiredDspGraph {
        let dsp_latency = graph.total_latency_samples();
        let node_count = graph.node_count() as u32;
        let retired = self.audio.graph.swap(graph);

        self.audio.latency.set_dsp_latency(dsp_latency);
        // 控制路径，可阻塞等锁。
        *lock_counting_poison(&self.shared.latency_mirror, &self.shared.stats.poison_events) =
            self.audio.latency;
        self.shared
            .stats
            .graph_versions_published
            .fetch_add(1, Ordering::Relaxed);

        let event = EventPlane::GraphPublished {
            version: self.audio.graph.version(),
            node_count,
        };
        self.control_event_tx.publish(event);
        self.audio.audio_event_tx.publish(event);

        retired
    }

    pub fn graph_version(&self) -> u64 {
        self.audio.graph.version()
    }

    pub fn playback_position(&self) -> PlaybackPosition {
        self.audio.clock.playback_position()
    }

    /// 当前延迟报告。`AudioKernel` 持有权威副本，直接读，无锁。
    pub fn latency_report(&self) -> LatencyReport {
        self.audio.latency.current_latency()
    }

    pub fn roundtrip_latency_us(&self) -> f64 {
        self.audio.latency.estimated_roundtrip_us()
    }

    pub fn stats(&self) -> KernelStats {
        self.shared.stats.snapshot()
    }

    pub fn process(&mut self, input: &[f32], output: &mut [f32]) -> AdapterProcessReport {
        let _fpu = FpuGuard::new();

        // 排空控制队列**先于**活动检查。
        //
        // 旧行为是 Idle 时直接 return，队列原地堆积：容量 64 填满后新请求
        // 全部被丢弃，而启动瞬间这些陈旧请求又会一次性涌入，把中间态一股脑
        // 灌进图里。
        //
        // Idle 时应用请求是无害的：
        // - 参数：`ParameterQueue` 只保留最新值，多写几次等价于写最后一次；
        // - `StopStream`：`Idle → Draining` 是非法迁移，`transition` 返回
        //   `Err`，`handle_request` 的 `is_ok()` 守卫使其静默忽略。
        self.drain_control_queue();

        if !self.shared.stream.state().is_active() {
            output.fill(0.0);
            return AdapterProcessReport::default();
        }

        self.shared.stats.callbacks.fetch_add(1, Ordering::Relaxed);

        let context = self.audio.context;
        let report = match self.audio.graph.try_pin() {
            Some(mut guard) => self.audio.adapter.process_host_block(input, output, |src, dst| {
                guard.process(src, dst, &context);
            }),
            None => {
                self.shared
                    .stats
                    .graph_pin_failures
                    .fetch_add(1, Ordering::Relaxed);
                output.fill(0.0);
                self.audio.audio_event_tx.publish(EventPlane::HardwareError {
                    reason: "reentrant audio callback: graph is already pinned",
                });
                return AdapterProcessReport::default();
            }
        };

        let frames = report.processed_dsp_blocks * self.audio.adapter.target_block_size();
        if frames > 0 {
            self.audio.clock.on_block_processed(frames);
        }

        // 权威副本在音频线程独占的 AudioState 里，直接改，无锁。
        let adapter_latency = self.audio.adapter.latency_samples();
        self.audio.latency.set_adapter_latency(adapter_latency);

        if report.underrun_samples > 0 {
            self.audio.audio_event_tx.publish(EventPlane::Underrun {
                underrun_samples: report.underrun_samples as u32,
            });
        }

        if adapter_latency != self.audio.last_reported_latency {
            // 同样读本地权威副本，不碰共享锁。
            let total_us = self.audio.latency.current_latency().total_us;
            self.audio.audio_event_tx.publish(EventPlane::LatencyChanged {
                added_latency_samples: report.latency_added_samples as u32,
                total_latency_us: total_us as u32,
            });
            self.audio.last_reported_latency = adapter_latency;

            // 尽力同步给控制面。竞争时直接跳过：这是诊断数据，
            // 下次回调会再试，绝不为它阻塞音频线程。
            if let Ok(mut mirror) = self.shared.latency_mirror.try_lock() {
                *mirror = self.audio.latency;
            }
        }

        self.shared
            .stats
            .processed_blocks
            .fetch_add(report.processed_dsp_blocks as u64, Ordering::Relaxed);
        self.shared
            .stats
            .underrun_samples
            .fetch_add(report.underrun_samples as u64, Ordering::Relaxed);
        self.shared
            .stats
            .dropped_input
            .fetch_add(report.dropped_input_samples as u64, Ordering::Relaxed);
        self.shared
            .stats
            .dropped_output
            .fetch_add(report.dropped_output_samples as u64, Ordering::Relaxed);

        report
    }

    /// 排空控制队列并累计统计。
    ///
    /// 无论流是否活动都会调用（见 [`Self::process`] 的说明）。
    /// 应用条数记在 `stats.control_requests_applied`，此处不再返回 ——
    /// 没有调用方需要它。
    fn drain_control_queue(&mut self) {
        let mut applied = 0_u64;
        while let Some(request) = self.audio.control_rx.poll() {
            self.handle_request(request);
            applied += 1;
        }
        if applied > 0 {
            self.shared
                .stats
                .control_requests_applied
                .fetch_add(applied, Ordering::Relaxed);
        }
    }

    fn handle_request(&mut self, request: ControlRequest) {
        match request {
            ControlRequest::SetGain { node_id, gain_db } => {
                self.push_parameter(node_id, gain_db);
            }
            ControlRequest::SetParameter { node_id, value, .. } => {
                self.push_parameter(node_id, value);
            }
            ControlRequest::SetMute { node_id, mute } => {
                self.push_parameter(node_id, if mute { -96.0 } else { 0.0 });
            }
            ControlRequest::StopStream => {
                let from = self.shared.stream.state();
                if self.shared.stream.transition(StreamState::Draining).is_ok() {
                    let event = EventPlane::StreamStateChanged {
                        from: from as u8,
                        to: StreamState::Draining as u8,
                    };
                    self.audio.audio_event_tx.publish(event);
                    self.control_event_tx.publish(event);
                }
            }
            _ => {}
        }
    }

    /// 音频线程：查表并推参数。无锁 —— 表由 `AudioState` 独占。
    #[inline]
    fn push_parameter(&self, node_id: u32, value: f32) {
        if let Some((_, parameter)) = self
            .audio
            .parameters
            .iter()
            .find(|(id, _)| *id == node_id)
        {
            parameter.set(value);
        }
    }
}

struct NoopSink;
impl EventSink for NoopSink {
    fn on_event(&self, _event: EventPlane) {}
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::nodes::SharedGainNode;
    use audio_api::FnEventSink;
    use audio_dsp::DynamicGraphBuilder;
    use std::sync::Mutex;

    fn build_kernel() -> (AudioKernel, crate::nodes::SharedParameter) {
        let mut builder = DynamicGraphBuilder::new(512);
        let head = SharedGainNode::new(0.0);
        let parameter = head.parameter();
        let a = builder.add_node(Box::new(head));
        let b = builder.add_node(Box::new(SharedGainNode::new(0.0)));
        builder.connect(a, b).unwrap();
        let graph = builder.compile().unwrap();

        let mut kernel = AudioKernel::new(KernelConfig::default(), graph).unwrap();
        kernel.register_parameter(0, parameter.clone());
        (kernel, parameter)
    }

    #[test]
    fn kernel_rejects_invalid_configuration() {
        let mut builder = DynamicGraphBuilder::new(64);
        builder.add_node(Box::new(SharedGainNode::new(0.0)));
        let graph = builder.compile().unwrap();

        let config = KernelConfig {
            adapter_capacity: 64,
            dsp_block_size: 512,
            ..KernelConfig::default()
        };
        assert_eq!(
            AudioKernel::new(config, graph).unwrap_err(),
            KernelError::AdapterCapacityTooSmall
        );
    }

    #[test]
    fn kernel_renders_observable_state_for_debugging() {
        let (kernel, _) = build_kernel();
        let rendered = format!("{kernel:?}");
        assert!(rendered.contains("AudioKernel"), "{rendered}");
        assert!(rendered.contains("graph_version"), "{rendered}");
        assert!(rendered.contains("stats"), "{rendered}");
    }

    #[test]
    fn idle_kernel_outputs_silence() {
        let (mut kernel, _) = build_kernel();
        assert_eq!(kernel.state(), StreamState::Idle);

        let input = vec![1.0f32; 512];
        let mut output = vec![9.0f32; 512];
        let report = kernel.process(&input, &mut output);

        assert!(output.iter().all(|&s| s == 0.0));
        assert_eq!(report, AdapterProcessReport::default());
        assert_eq!(kernel.stats().callbacks, 0);
    }

    /// 锁中毒必须**可观测**，而不是被吞成默认值。
    ///
    /// 这曾是 `format()` 里 `unwrap_or_default()` 的问题：中毒后返回
    /// 96kHz/f32/stereo，调用方无从分辨真实配置与故障。
    #[test]
    fn poisoned_locks_are_counted_not_swallowed() {
        use std::sync::Arc;
        use std::thread;

        let (mut kernel, _) = build_kernel();
        // 先协商到一个可辨识的非默认采样率。
        let host_formats = [AudioFormat::new(
            48_000,
            SampleFormat::Float32,
            ChannelLayout::Stereo,
        )];
        kernel.negotiate_format(&host_formats).unwrap();
        assert_eq!(kernel.format().sample_rate, 48_000);
        assert!(kernel.stats().is_healthy());

        // 让一个线程在持锁时 panic，毒化 format 锁。
        let shared = Arc::clone(&kernel.shared);
        let poisoner = thread::spawn(move || {
            let _guard = shared.format.write().expect("not yet poisoned");
            panic!("intentional panic to poison the lock");
        });
        assert!(poisoner.join().is_err(), "线程应当 panic");

        // 中毒后仍返回**真实**值，而不是 Default。
        assert_eq!(
            kernel.format().sample_rate,
            48_000,
            "中毒不得把真实配置替换成默认值"
        );
        // 且中毒必须被计数。
        assert!(
            !kernel.stats().is_healthy(),
            "poison_events 必须非零，否则故障不可观测"
        );
        assert!(kernel.stats().poison_events >= 1);

        // 音频损伤与进程健康是两个维度，不得互相掩盖。
        assert!(
            kernel.stats().is_clean(),
            "锁中毒不属于音频损伤，is_clean 不应受影响"
        );
    }

    /// 回归测试：Idle 期间控制队列必须照常排空。
    ///
    /// 旧行为在活动检查处直接 return，队列堆积到容量上限后丢弃后续请求，
    /// 启动瞬间又把陈旧请求一次性灌进图里。
    #[test]
    fn idle_process_still_drains_the_control_queue() {
        let (mut kernel, _) = build_kernel();
        assert_eq!(kernel.state(), StreamState::Idle);

        for gain_db in [-3.0, -6.0, -12.0] {
            assert!(kernel.control().send(ControlRequest::SetGain {
                node_id: 0,
                gain_db,
            }));
        }
        assert_eq!(kernel.control().len(), 3);

        let input = vec![1.0f32; 512];
        let mut output = vec![9.0f32; 512];
        let report = kernel.process(&input, &mut output);

        // 队列已排空，统计已计入
        assert!(kernel.control().is_empty(), "Idle 期间队列必须排空");
        assert_eq!(kernel.stats().control_requests_applied, 3);

        // 但这一次不算作音频回调，输出仍是静音
        assert_eq!(kernel.stats().callbacks, 0, "非活动状态不得计入回调");
        assert_eq!(report, AdapterProcessReport::default());
        assert!(output.iter().all(|&s| s == 0.0));
    }

    /// `StopStream` 在 Idle 下是非法迁移，必须静默忽略而不是留下脏状态。
    #[test]
    fn stop_request_at_idle_is_ignored_without_side_effects() {
        let (mut kernel, _) = build_kernel();
        assert!(kernel.control().send(ControlRequest::StopStream));

        let mut output = vec![0.0f32; 512];
        let _ = kernel.process(&[], &mut output);

        assert_eq!(kernel.state(), StreamState::Idle, "非法迁移不得改变状态");
        assert_eq!(kernel.stats().control_requests_applied, 1);

        // 仍可正常启动
        kernel.start().unwrap();
        assert_eq!(kernel.state(), StreamState::Running);
    }

    #[test]
    fn running_kernel_passes_audio_through_the_graph() {
        let (mut kernel, _) = build_kernel();
        kernel.start().unwrap();
        assert_eq!(kernel.state(), StreamState::Running);

        let input = vec![1.0f32; 512];
        let mut output = vec![0.0f32; 512];
        let report = kernel.process(&input, &mut output);

        assert_eq!(report.processed_dsp_blocks, 1);
        assert!(report.is_clean(), "{report:?}");
        assert!((output[511] - 1.0).abs() < 1e-3, "got {}", output[511]);
        assert_eq!(kernel.stats().callbacks, 1);
        assert!(kernel.stats().is_clean());
    }

    #[test]
    fn control_requests_reach_the_graph_without_allocation() {
        let (mut kernel, _) = build_kernel();
        kernel.start().unwrap();

        assert!(kernel.control().send(ControlRequest::SetGain {
            node_id: 0,
            gain_db: -96.0,
        }));

        let input = vec![1.0f32; 512];
        let mut output = vec![0.0f32; 512];
        for _ in 0..2 {
            let report = kernel.process(&input, &mut output);
            assert!(report.is_clean(), "{report:?}");
        }

        assert_eq!(kernel.stats().control_requests_applied, 1);
        assert!(output[511].abs() < 0.01, "gain not applied: {}", output[511]);
    }

    #[test]
    fn mismatched_block_sizes_report_latency_once() {
        let (mut kernel, _) = build_kernel();
        kernel.start().unwrap();

        let input = vec![0.5f32; 384];
        let mut output = vec![0.0f32; 384];
        for _ in 0..8 {
            let report = kernel.process(&input, &mut output);
            assert_eq!(report.underrun_samples, 0, "{report:?}");
        }

        let latency = kernel.latency_report();
        assert!(latency.total_samples > 0);
        assert!(latency.total_us > 0.0);

        let latency_events = Mutex::new(0usize);
        let sink = FnEventSink(|event: EventPlane| {
            if matches!(event, EventPlane::LatencyChanged { .. }) {
                *latency_events.lock().unwrap() += 1;
            }
        });
        kernel.pump_events(&sink);
        assert_eq!(*latency_events.lock().unwrap(), 1);
    }

    #[test]
    fn clock_tracks_processed_frames() {
        let (mut kernel, _) = build_kernel();
        kernel.start().unwrap();

        let input = vec![0.0f32; 512];
        let mut output = vec![0.0f32; 512];
        for _ in 0..10 {
            let report = kernel.process(&input, &mut output);
            assert_eq!(report.processed_dsp_blocks, 1, "{report:?}");
        }

        let position = kernel.playback_position();
        assert_eq!(position.total_frames_processed, 512 * 10);
        assert!(position.play_frame <= position.write_frame);
    }

    #[test]
    fn graph_can_be_hot_swapped_while_running() {
        let (mut kernel, _) = build_kernel();
        kernel.start().unwrap();

        let input = vec![1.0f32; 512];
        let mut output = vec![0.0f32; 512];
        let report = kernel.process(&input, &mut output);
        assert!(report.is_clean(), "{report:?}");
        assert_eq!(kernel.graph_version(), 1);

        let mut builder = DynamicGraphBuilder::new(512);
        builder.add_node(Box::new(SharedGainNode::new(-6.0)));
        let replacement = builder.compile().unwrap();

        let retired = kernel.publish_graph(replacement);
        assert_eq!(kernel.graph_version(), 2);
        assert!(retired.try_reclaim().is_ok());

        for _ in 0..2 {
            let report = kernel.process(&input, &mut output);
            assert!(report.is_clean(), "{report:?}");
        }
        let expected = 10.0f32.powf(-6.0 / 20.0);
        assert!(
            (output[511] - expected).abs() < 1e-3,
            "gain after hot-swap: {}",
            output[511]
        );
        assert_eq!(kernel.stats().graph_versions_published, 1);
    }

    #[test]
    fn format_negotiation_is_refused_while_running() {
        let (mut kernel, _) = build_kernel();
        kernel.start().unwrap();
        let host_formats = [AudioFormat::new(
            48_000,
            SampleFormat::Float32,
            ChannelLayout::Stereo,
        )];
        assert!(kernel.negotiate_format(&host_formats).is_err());
    }

    #[test]
    fn sample_rate_change_propagates_to_clock_and_latency() {
        let (mut kernel, _) = build_kernel();
        let host_formats = [AudioFormat::new(
            48_000,
            SampleFormat::Float32,
            ChannelLayout::Stereo,
        )];
        let conversion = kernel.negotiate_format(&host_formats).unwrap();
        assert!(conversion.requires_resampling);
        assert_eq!(kernel.format().sample_rate, 48_000);
        assert_eq!(kernel.latency_report().sample_rate, 48_000);
        assert_eq!(kernel.playback_position().total_frames_processed, 0);
    }

    #[test]
    fn format_negotiation_broadcasts_the_result() {
        let (mut kernel, _) = build_kernel();
        let host_formats = [
            AudioFormat::new(44_100, SampleFormat::Int16, ChannelLayout::Stereo),
            AudioFormat::new(96_000, SampleFormat::Float32, ChannelLayout::Stereo),
        ];
        let conversion = kernel.negotiate_format(&host_formats).unwrap();
        assert!(conversion.is_passthrough());

        let seen = Mutex::new(Vec::new());
        let sink = FnEventSink(|event: EventPlane| {
            if let EventPlane::FormatNegotiated { sample_rate, .. } = event {
                seen.lock().unwrap().push(sample_rate);
            }
        });
        kernel.pump_events(&sink);
        assert!(!seen.lock().unwrap().is_empty());
    }

    #[test]
    fn stop_drains_the_adapter_tail() {
        let (mut kernel, _) = build_kernel();
        kernel.start().unwrap();

        let input = vec![1.0f32; 100];
        let mut no_output = [];
        let report = kernel.process(&input, &mut no_output);
        assert_eq!(report.accepted_input_samples, 100, "{report:?}");
        assert_eq!(report.processed_dsp_blocks, 0);

        let tail = kernel.stop().unwrap();
        assert_eq!(tail.len(), 100);
        assert_eq!(kernel.state(), StreamState::Idle);
    }

    #[test]
    fn underruns_are_reported_on_the_event_plane() {
        let (mut kernel, _) = build_kernel();
        kernel.start().unwrap();

        let mut output = vec![0.0f32; 512];
        let report = kernel.process(&[], &mut output);
        assert!(report.underrun_samples > 0);

        let underruns = Mutex::new(0u32);
        let sink = FnEventSink(|event: EventPlane| {
            if let EventPlane::Underrun { underrun_samples } = event {
                *underruns.lock().unwrap() += underrun_samples;
            }
        });
        kernel.pump_events(&sink);
        assert!(*underruns.lock().unwrap() > 0);
        assert!(!kernel.stats().is_clean());
    }

    #[test]
    fn concurrent_control_and_audio_access_is_safe() {
        use std::sync::Arc;
        use std::thread;

        let (kernel, _) = build_kernel();
        let kernel = Arc::new(Mutex::new(kernel));
        {
            let mut k = kernel.lock().unwrap();
            k.start().unwrap();
        }

        let k_clone = Arc::clone(&kernel);
        let control_thread = thread::spawn(move || {
            for i in 0..100 {
                if let Ok(k) = k_clone.try_lock() {
                    k.control().send(ControlRequest::SetGain {
                        node_id: 0,
                        gain_db: -(i as f32),
                    });
                }
                std::thread::sleep(std::time::Duration::from_micros(10));
            }
        });

        let audio_thread = thread::spawn(move || {
            let input = vec![0.5f32; 512];
            let mut output = vec![0.0f32; 512];
            for _ in 0..100 {
                if let Ok(mut k) = kernel.try_lock() {
                    let _ = k.process(&input, &mut output);
                }
                std::thread::sleep(std::time::Duration::from_micros(10));
            }
        });

        control_thread.join().unwrap();
        audio_thread.join().unwrap();
    }

    /// 回归测试：`process()` 绝不能在共享锁上阻塞。
    ///
    /// 做法是在另一个线程上**持住** `latency_mirror`，然后跑 `process()`。
    /// 若热路径改回 `lock()`（而非 `try_lock()`），这个测试会挂死；
    /// 用超时把"挂死"变成"失败"，以免 CI 卡住。
    #[test]
    fn process_never_blocks_on_a_held_shared_lock() {
        use std::sync::mpsc;
        use std::thread;
        use std::time::Duration;

        let (mut kernel, _) = build_kernel();
        kernel.start().unwrap();

        // 先跑一个不整除的块，让 last_reported_latency 与实际值产生差异，
        // 确保后面那次 process 会走到"同步镜像"这条分支。
        let warmup = vec![0.5f32; 384];
        let mut warmup_out = vec![0.0f32; 384];
        let _ = kernel.process(&warmup, &mut warmup_out);

        let shared = Arc::clone(&kernel.shared);
        let (release_tx, release_rx) = mpsc::channel::<()>();
        let (held_tx, held_rx) = mpsc::channel::<()>();

        let holder = thread::spawn(move || {
            let _guard = shared.latency_mirror.lock().expect("mirror not poisoned");
            held_tx.send(()).expect("main thread is waiting");
            // 一直持有锁，直到主线程确认 process 已经返回。
            let _ = release_rx.recv_timeout(Duration::from_secs(5));
        });

        held_rx
            .recv_timeout(Duration::from_secs(5))
            .expect("holder thread should acquire the lock");

        // 锁被别人持着 —— process 必须照常返回，而不是等锁。
        let input = vec![0.25f32; 512];
        let mut output = vec![0.0f32; 512];
        let report = kernel.process(&input, &mut output);
        assert_eq!(report.underrun_samples, 0, "{report:?}");

        release_tx.send(()).ok();
        holder.join().expect("holder thread finished");
    }

    #[test]
    fn registered_parameters_live_on_the_audio_thread() {
        // 参数表必须在 AudioState 里，否则查表要加锁。
        let (kernel, _) = build_kernel();
        assert_eq!(kernel.audio.parameters.len(), 1);
    }

    #[test]
    fn control_handle_can_be_cloned_and_used_concurrently() {
        let (kernel, _) = build_kernel();
        let control = kernel.control_handle();
        let control2 = control.clone();

        assert!(control.send(ControlRequest::SetGain {
            node_id: 0,
            gain_db: -3.0
        }));
        assert!(control2.send(ControlRequest::SetGain {
            node_id: 0,
            gain_db: -6.0
        }));
        assert_eq!(control2.state(), StreamState::Idle);
    }
}
