//! 可被控制平面寻址的 DSP 节点。
//!
//! `audio-dsp` 的 [`GainNode`](audio_dsp::GainNode) 自带参数队列，但队列随
//! 节点一起被 `Box` 进图里，控制线程拿不到引用。本模块提供
//! [`SharedParameter`]：把参数队列放进 `Arc`，节点与控制平面各持一份，
//! 于是控制线程可以在**不接触图内存**的前提下推送参数。

use std::sync::Arc;

use audio_dsp::node::{DspNode, ParameterQueue, ProcessContext};

/// 控制线程与音频线程共享的一个标量参数。
///
/// 生产者（控制线程）调用 [`SharedParameter::set`]；
/// 消费者（音频线程）在 `process` 开头调用 [`SharedParameter::poll`]。
#[derive(Clone)]
pub struct SharedParameter {
    queue: Arc<ParameterQueue<f32>>,
}

impl SharedParameter {
    pub fn new() -> Self {
        Self {
            queue: Arc::new(ParameterQueue::new()),
        }
    }

    /// 控制线程：投递新值。队列满时返回 `false`（丢弃本次更新，绝不阻塞）。
    #[inline]
    pub fn set(&self, value: f32) -> bool {
        self.queue.try_push(value)
    }

    /// 音频线程：取最新值；无更新时返回 `false` 并保持 `current` 不变。
    #[inline(always)]
    pub fn poll(&self, current: &mut f32) -> bool {
        self.queue.drain_to(current)
    }
}

impl Default for SharedParameter {
    fn default() -> Self {
        Self::new()
    }
}

impl std::fmt::Debug for SharedParameter {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("SharedParameter")
            .field("holders", &Arc::strong_count(&self.queue))
            .finish()
    }
}

#[inline(always)]
fn db_to_linear(db: f32) -> f32 {
    10.0f32.powf(db / 20.0)
}

/// 增益节点，其 dB 参数可被控制平面直接寻址。
///
/// 增益变化在块内做线性插值，避免阶跃造成的可听咔哒声。
pub struct SharedGainNode {
    target_db: f32,
    current_linear: f32,
    target_linear: f32,
    parameter: SharedParameter,
    muted: bool,
}

impl SharedGainNode {
    pub fn new(gain_db: f32) -> Self {
        let linear = db_to_linear(gain_db);
        Self {
            target_db: gain_db,
            current_linear: linear,
            target_linear: linear,
            parameter: SharedParameter::new(),
            muted: false,
        }
    }

    /// 控制平面侧的参数句柄（可跨线程持有）。
    pub fn parameter(&self) -> SharedParameter {
        self.parameter.clone()
    }

    pub fn gain_db(&self) -> f32 {
        self.target_db
    }

    pub fn set_muted(&mut self, muted: bool) {
        self.muted = muted;
        self.target_linear = if muted { 0.0 } else { db_to_linear(self.target_db) };
    }

    pub fn is_muted(&self) -> bool {
        self.muted
    }
}

impl DspNode for SharedGainNode {
    fn process(&mut self, inputs: &[f32], outputs: &mut [f32], _ctx: &ProcessContext) {
        // 热路径开头 drain 参数（§2.3.4）
        let mut db = self.target_db;
        if self.parameter.poll(&mut db) && db.is_finite() {
            self.target_db = db;
            if !self.muted {
                self.target_linear = db_to_linear(db);
            }
        }

        let frames = inputs.len().min(outputs.len());
        if frames == 0 {
            return;
        }

        let start = self.current_linear;
        let end = self.target_linear;
        if (end - start).abs() < f32::EPSILON {
            for (out, &sample) in outputs.iter_mut().zip(inputs) {
                *out = sample * end;
            }
            return;
        }

        // 块内线性斜坡，消除参数跳变产生的咔哒声。
        //
        // 插值系数用 `(index + 1) / frames`，因此块的**最后一个采样**恰好
        // 落在 `end`。若用 `index / frames`，斜坡会差一步没走完，而
        // `current_linear` 又已被置为 `end`，下一个块的首采样就会跳过这一步 ——
        // 正好制造出斜坡本该消除的那一下咔哒。
        let delta = end - start;
        let inv_frames = 1.0 / frames as f32;
        for (index, (out, &sample)) in outputs.iter_mut().zip(inputs).enumerate() {
            let t = (index + 1) as f32 * inv_frames;
            *out = sample * (start + delta * t);
        }
        self.current_linear = end;
    }

    fn reset(&mut self) {
        self.current_linear = self.target_linear;
    }

    fn cpu_budget_us(&self) -> u32 {
        60
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn context() -> ProcessContext {
        ProcessContext {
            sample_rate: 48_000,
            block_size: 8,
        }
    }

    #[test]
    fn unity_gain_is_transparent() {
        let mut node = SharedGainNode::new(0.0);
        let input = [1.0f32; 8];
        let mut output = [0.0f32; 8];
        node.process(&input, &mut output, &context());
        assert_eq!(output, [1.0; 8]);
    }

    #[test]
    fn control_thread_can_address_the_parameter() {
        let mut node = SharedGainNode::new(0.0);
        let handle = node.parameter();

        // 控制线程侧
        assert!(handle.set(-6.0));

        let input = [1.0f32; 8];
        let mut output = [0.0f32; 8];
        node.process(&input, &mut output, &context());

        // 斜坡必须在块的最后一个采样精确抵达目标增益，
        // 否则块之间会残留一步跳变。容差取浮点精度量级，而非"差不多就行"。
        let expected = 10.0f32.powf(-6.0 / 20.0);
        assert!(
            (output[7] - expected).abs() < 1e-6,
            "ramp end {} != {expected}",
            output[7]
        );
        assert_eq!(node.gain_db(), -6.0);
    }

    #[test]
    fn consecutive_blocks_have_no_step_at_the_boundary() {
        // 回归测试：斜坡差一步没走完时，块 N 末尾与块 N+1 开头之间会出现
        // 一次跳变 —— 正是斜坡本该消除的咔哒。
        let mut node = SharedGainNode::new(0.0);
        node.parameter().set(-24.0);

        let input = [1.0f32; 8];
        let mut first = [0.0f32; 8];
        let mut second = [0.0f32; 8];
        node.process(&input, &mut first, &context());
        node.process(&input, &mut second, &context());

        // 第二个块已无参数变化，应当整块保持在目标增益上。
        let expected = 10.0f32.powf(-24.0 / 20.0);
        assert!(
            second.iter().all(|s| (s - expected).abs() < 1e-6),
            "第二个块应稳定在目标增益: {second:?}"
        );
        // 跨块边界的增益差必须不大于斜坡内部的单步步长。
        let boundary_step = (second[0] - first[7]).abs();
        let internal_step = (first[7] - first[6]).abs();
        assert!(
            boundary_step <= internal_step + 1e-6,
            "块边界跳变 {boundary_step} 超过内部步长 {internal_step}"
        );
    }

    #[test]
    fn gain_changes_ramp_instead_of_jumping() {
        let mut node = SharedGainNode::new(0.0);
        node.parameter().set(-96.0);

        let input = [1.0f32; 8];
        let mut output = [0.0f32; 8];
        node.process(&input, &mut output, &context());

        // 断言的是斜坡的**形状**，而不是某个贴着实现写死的阈值。
        // 8 采样线性斜坡从 1.0 降到 ~0，首采样必然是 1 − 1/8 = 0.875，
        // 因此"首采样 > 0.9"这类阈值只会掩盖 off-by-one。

        // 1. 单调递减，无反弹
        for pair in output.windows(2) {
            assert!(pair[1] < pair[0], "斜坡必须单调递减: {output:?}");
        }
        // 2. 步长均匀（线性）
        let step = output[0] - output[1];
        for pair in output.windows(2) {
            assert!(
                ((pair[0] - pair[1]) - step).abs() < 1e-6,
                "步长应当一致: {output:?}"
            );
        }
        // 3. 首采样仍由旧增益主导，即没有瞬间跳到新值
        assert!(
            output[0] > 0.5,
            "首采样已跌向新增益，说明发生了阶跃: {}",
            output[0]
        );
        // 4. 末采样精确抵达新增益
        let expected = 10.0f32.powf(-96.0 / 20.0);
        assert!(
            (output[7] - expected).abs() < 1e-6,
            "斜坡未在块末收敛: {} != {expected}",
            output[7]
        );
    }

    #[test]
    fn mute_overrides_gain_but_preserves_it() {
        let mut node = SharedGainNode::new(-6.0);
        node.set_muted(true);
        assert!(node.is_muted());

        let input = [1.0f32; 8];
        let mut output = [1.0f32; 8];
        node.process(&input, &mut output, &context());
        node.process(&input, &mut output, &context());
        assert!(output.iter().all(|&s| s.abs() < 1e-6), "静音后必须无输出");

        node.set_muted(false);
        node.process(&input, &mut output, &context());
        node.process(&input, &mut output, &context());
        let expected = 10.0f32.powf(-6.0 / 20.0);
        assert!((output[7] - expected).abs() < 1e-3, "解除静音应恢复原增益");
    }

    #[test]
    fn non_finite_parameters_are_ignored() {
        let mut node = SharedGainNode::new(0.0);
        node.parameter().set(f32::NAN);
        let input = [1.0f32; 8];
        let mut output = [0.0f32; 8];
        node.process(&input, &mut output, &context());
        assert!(output.iter().all(|s| s.is_finite()), "NaN 不得污染音频");
        assert_eq!(node.gain_db(), 0.0);
    }

    #[test]
    fn parameter_handle_is_cloneable_across_threads() {
        let node = SharedGainNode::new(0.0);
        let handle = node.parameter();
        let worker = std::thread::spawn(move || handle.set(-3.0));
        assert!(worker.join().unwrap());
    }
}
