//! 端到端离线渲染示例：串起全部六个 crate。
//!
//! 运行：`cargo run -p audio-kernel --example offline_render`
//!
//! 演示内容：
//! 1. 用图事务声明拓扑并校验（audio-api）
//! 2. 编译真实 DSP 图并交给内核（audio-dsp）
//! 3. 用**故意不整除**的宿主块驱动回调（audio-host 的 AdapterBuffer）
//! 4. 运行中通过控制面推参数（audio-api）
//! 5. 热替换图（audio-dsp 的 RCU + hazard pointer）
//! 6. 打印分阶段延迟与播放位置（audio-clock）

use std::sync::Mutex;

use audio_api::descriptor::{GAIN_NODE_DESCRIPTOR, OUTPUT_NODE_DESCRIPTOR};
use audio_api::{
    ControlRequest, EventPlane, FnEventSink, GraphSpec, GraphTransaction, StreamConfig,
};
use audio_kernel::{AudioKernel, KernelConfig, SharedGainNode};
use audio_dsp::{DspGraphInner, DynamicGraphBuilder};

const HOST_BLOCK: usize = 384; // 故意与 DSP 的 512 不整除
const DSP_BLOCK: usize = 512;
const SAMPLE_RATE: u32 = 48_000;

fn main() {
    println!("=== Audio Runtime offline render ===\n");

    // ---- 1. 先用事务在描述层校验拓扑 -----------------------------------
    let mut spec = GraphSpec::new();
    let mut transaction = GraphTransaction::new();
    transaction
        .add_node(GAIN_NODE_DESCRIPTOR)
        .add_node(GAIN_NODE_DESCRIPTOR)
        .add_node(OUTPUT_NODE_DESCRIPTOR)
        .connect(0, 1)
        .connect(1, 2)
        .set_parameter(0, 0, -6.0);

    match transaction.commit(&mut spec) {
        Ok(log) => println!(
            "[1] graph transaction committed: {} nodes, {} edges, {} samples latency",
            log.node_count, log.edge_count, log.total_latency_samples
        ),
        Err(error) => {
            eprintln!("[1] transaction rejected: {error}");
            return;
        }
    }

    // ---- 2. 编译可执行图 ------------------------------------------------
    let (graph, gain) = build_graph(-6.0);
    println!("[2] compiled DSP graph with {} nodes", graph.node_count());

    let config = KernelConfig {
        stream: StreamConfig {
            sample_rate: SAMPLE_RATE,
            block_size: HOST_BLOCK,
            ..StreamConfig::default()
        },
        dsp_block_size: DSP_BLOCK,
        adapter_capacity: 4_096,
        hw_input_us: 700,
        hw_output_us: 900,
    };

    let mut kernel = match AudioKernel::new(config, graph) {
        Ok(kernel) => kernel,
        Err(error) => {
            eprintln!("[2] kernel construction failed: {error}");
            return;
        }
    };
    kernel.register_parameter(0, gain);

    if let Err(error) = kernel.start() {
        eprintln!("[3] start failed: {error}");
        return;
    }
    println!("[3] kernel state: {}", kernel.state());

    // ---- 4. 用 440 Hz 正弦驱动回调 --------------------------------------
    let total_frames = SAMPLE_RATE as usize; // 1 秒
    let mut phase = 0.0f32;
    let phase_step = 2.0 * std::f32::consts::PI * 440.0 / SAMPLE_RATE as f32;

    let mut input = vec![0.0f32; HOST_BLOCK];
    let mut output = vec![0.0f32; HOST_BLOCK];
    let mut peak = 0.0f32;
    let mut callbacks = 0;

    for block in 0..(total_frames / HOST_BLOCK) {
        for sample in input.iter_mut() {
            *sample = phase.sin() * 0.8;
            phase += phase_step;
        }

        // 中途把增益推到 -20 dB，验证控制面在运行中生效
        if block == 40 {
            kernel.control().send(ControlRequest::SetGain {
                node_id: 0,
                gain_db: -20.0,
            });
            println!("[4] pushed SetGain(-20 dB) at block {block}");
        }

        // 中途热替换整张图
        if block == 80 {
            let (replacement, _) = build_graph(0.0);
            let retired = kernel.publish_graph(replacement);
            let reclaimed = retired.try_reclaim().is_ok();
            println!(
                "[5] hot-swapped graph -> version {} (old graph reclaimed: {reclaimed})",
                kernel.graph_version()
            );
        }

        let report = kernel.process(&input, &mut output);
        callbacks += 1;
        if !report.is_clean() {
            eprintln!("    block {block}: {report:?}");
        }
        peak = output.iter().fold(peak, |acc, s| acc.max(s.abs()));
    }

    // ---- 6. 关闭并排空 --------------------------------------------------
    let tail = kernel.stop().unwrap_or_default();

    // ---- 7. 报告 --------------------------------------------------------
    let stats = kernel.stats();
    println!("\n[6] drained {} tail samples", tail.len());
    println!(
        "[7] {callbacks} callbacks, {} DSP blocks, peak {:.3}, clean: {}",
        stats.processed_blocks, peak, stats.is_clean()
    );

    let position = kernel.playback_position();
    println!(
        "    position: processed={} write={} play={} ({:.3}s)",
        position.total_frames_processed,
        position.write_frame,
        position.play_frame,
        position.play_time_seconds(SAMPLE_RATE)
    );

    println!("\n[8] latency breakdown");
    print!("{}", kernel.latency_report());
    println!(
        "    roundtrip estimate: {:.2} ms",
        kernel.roundtrip_latency_us() / 1_000.0
    );

    // ---- 9. 排空事件面 --------------------------------------------------
    let log = Mutex::new(Vec::new());
    let sink = FnEventSink(|event: EventPlane| {
        log.lock().expect("event log is not poisoned").push(event);
    });
    let count = kernel.pump_events(&sink);
    println!("\n[9] {count} events on the event plane:");
    for event in log.lock().expect("event log is not poisoned").iter() {
        println!("    {event:?}");
    }
}

/// 构建 `SharedGainNode -> SharedGainNode` 链，返回首节点的参数句柄。
fn build_graph(
    gain_db: f32,
) -> (Box<DspGraphInner>, audio_kernel::SharedParameter) {
    let mut builder = DynamicGraphBuilder::new(DSP_BLOCK);
    let head = SharedGainNode::new(gain_db);
    let parameter = head.parameter();
    let a = builder.add_node(Box::new(head));
    let b = builder.add_node(Box::new(SharedGainNode::new(0.0)));
    builder
        .connect(a, b)
        .expect("a two-node chain is acyclic");
    let graph = builder.compile().expect("the chain compiles");
    (graph, parameter)
}
