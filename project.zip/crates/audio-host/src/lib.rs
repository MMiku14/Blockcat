//! # audio-host — 宿主适配器矩阵（架构文档 §3.2）
//!
//! 平台矩阵（§3.2.4）：
//!
//! | 平台    | 后端        | 线程模型        | 块大小变化 |
//! |---------|-------------|-----------------|-----------|
//! | macOS   | CoreAudio   | 系统实时线程    | 不支持    |
//! | Linux   | ALSA        | 自建 Poll 线程  | 支持      |
//! | Windows | WASAPI/ASIO | COM/驱动回调    | 支持/不支持 |
//! | WASM    | AudioWorklet| 固定 128        | 不支持    |
//!
//! 依赖规则：可依赖 core/sys，禁止依赖 audio-dsp（音频核心路径可移植性）。
//!
//! `AdapterBuffer` 的定容不变式由不可扩容的存储与单次分配契约守卫，热路径决不分配内存。

#![deny(unsafe_op_in_unsafe_fn)]

pub mod adapter_buf;
#[cfg(target_os = "linux")]
pub mod alsa;
#[cfg(target_os = "macos")]
pub mod coreaudio;

pub use adapter_buf::{AdapterBuffer, AdapterProcessReport};

/// 宿主初始化配置（§3.2.2）。
#[derive(Debug, Clone)]
pub struct HostConfig {
    pub preferred_sample_rate: u32,
    pub preferred_block_size: usize,
    pub min_block_size: usize,
    pub max_block_size: usize,
    pub num_input_channels: u16,
    pub num_output_channels: u16,
}

impl HostConfig {
    pub fn validate(&self) -> Result<(), HostError> {
        if !(8_000..=384_000).contains(&self.preferred_sample_rate) {
            return Err(HostError::Unsupported);
        }
        if self.preferred_block_size == 0
            || self.preferred_block_size < self.min_block_size
            || self.preferred_block_size > self.max_block_size
        {
            return Err(HostError::Unsupported);
        }
        if self.min_block_size == 0 || self.max_block_size < self.min_block_size {
            return Err(HostError::Unsupported);
        }
        Ok(())
    }
}

impl Default for HostConfig {
    fn default() -> Self {
        Self {
            preferred_sample_rate: 96_000,
            preferred_block_size: 512,
            min_block_size: 64,
            max_block_size: 4096,
            num_input_channels: 2,
            num_output_channels: 2,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HostError {
    DeviceUnavailable,
    Unsupported,
    AlreadyRunning,
    NotRunning,
    Backend(&'static str),
    InvalidConfig,
}

impl core::fmt::Display for HostError {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            HostError::DeviceUnavailable => f.write_str("device unavailable"),
            HostError::Unsupported => f.write_str("unsupported configuration"),
            HostError::AlreadyRunning => f.write_str("already running"),
            HostError::NotRunning => f.write_str("not running"),
            HostError::Backend(msg) => write!(f, "backend error: {msg}"),
            HostError::InvalidConfig => f.write_str("invalid config"),
        }
    }
}

impl std::error::Error for HostError {}

/// 宿主句柄：实际协商到的运行参数。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct HostHandle {
    pub sample_rate: u32,
    pub block_size: usize,
}

/// 跨平台音频后端桥接 trait（§3.2.2）。
///
/// 各系统后台只需实现此 trait 负责设备通信，无需直接触碰底层的音频无锁适配与时钟逻辑。
pub trait HostAdapter: Send + 'static {
    fn initialize(&mut self, config: HostConfig) -> Result<HostHandle, HostError>;
    fn start(&mut self) -> Result<(), HostError>;
    fn stop(&mut self) -> Result<(), HostError>;
    fn current_block_size(&self) -> usize;
    fn current_sample_rate(&self) -> u32;
    fn supports_dynamic_block_size(&self) -> bool;

    /// 后端名称，用于日志与诊断。
    fn name(&self) -> &'static str {
        "unknown"
    }
}

// 已删除：`HostBackendRegistry` / `BackendDescriptor`。
//
// 零生产使用者（只有它自己的单元测试在用）。后端选择目前由 `#[cfg]` 在
// 编译期完成，运行时查找表没有承载任何决策。
//
// 重新引入的条件：需要在**同一个二进制内**于运行时在多个后端之间选择
// （例如 Linux 上 ALSA / PipeWire / JACK 共存并按可用性回退）。届时注册
// 表应携带探测函数与构造函数，而不只是名字和一个布尔标志。

/// 空适配器：离线渲染 / 测试 / CI 环境使用。
pub struct NullAdapter {
    handle: Option<HostHandle>,
    running: bool,
}

impl NullAdapter {
    pub fn new() -> Self {
        Self {
            handle: None,
            running: false,
        }
    }
}

impl Default for NullAdapter {
    fn default() -> Self {
        Self::new()
    }
}

impl HostAdapter for NullAdapter {
    fn name(&self) -> &'static str {
        "null"
    }

    fn initialize(&mut self, config: HostConfig) -> Result<HostHandle, HostError> {
        config.validate()?;
        let handle = HostHandle {
            sample_rate: config.preferred_sample_rate,
            block_size: config.preferred_block_size,
        };
        self.handle = Some(handle);
        Ok(handle)
    }

    fn start(&mut self) -> Result<(), HostError> {
        if self.handle.is_none() {
            return Err(HostError::NotRunning);
        }
        if self.running {
            return Err(HostError::AlreadyRunning);
        }
        self.running = true;
        Ok(())
    }

    fn stop(&mut self) -> Result<(), HostError> {
        if !self.running {
            return Err(HostError::NotRunning);
        }
        self.running = false;
        Ok(())
    }

    fn current_block_size(&self) -> usize {
        self.handle.map(|h| h.block_size).unwrap_or(0)
    }

    fn current_sample_rate(&self) -> u32 {
        self.handle.map(|h| h.sample_rate).unwrap_or(0)
    }

    fn supports_dynamic_block_size(&self) -> bool {
        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn null_adapter_lifecycle() {
        let mut a = NullAdapter::new();
        let h = a.initialize(HostConfig::default()).unwrap();
        assert_eq!(h.sample_rate, 96_000);
        assert_eq!(h.block_size, 512);
        a.start().unwrap();
        assert!(matches!(a.start(), Err(HostError::AlreadyRunning)));
        a.stop().unwrap();
        assert!(matches!(a.stop(), Err(HostError::NotRunning)));
    }

    #[test]
    fn config_validation() {
        let mut cfg = HostConfig::default();
        assert!(cfg.validate().is_ok());

        cfg.preferred_sample_rate = 0;
        assert!(cfg.validate().is_err());

        cfg = HostConfig::default();
        cfg.preferred_block_size = 1;
        cfg.min_block_size = 64;
        assert!(cfg.validate().is_err());
    }
}
