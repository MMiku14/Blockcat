//! Thread Provisioner：跨平台实时特权管理与优雅降级（架构文档 §3.3）。
//!
//! 降级链：
//! - Linux: `sched_setscheduler(SCHED_FIFO)` → rtkit(D-Bus) → portal → nice(-10)
//! - macOS: `thread_policy_set(TIME_CONSTRAINT)` → QoS USER_INTERACTIVE
//! - Windows: MMCSS "Pro Audio" + TIME_CRITICAL → HIGH_PRIORITY_CLASS
//!
//! 参考实现说明：为保持零外部依赖，rtkit（需 `zbus`）、MMCSS（需
//! `windows` crate）路径以文档化占位实现，直接调用降级链下一级。
//! 现场级（Live FOH）场景必须使用 [`ThreadProvisioning::Strict`]，
//! 拿不到硬实时特权即返回错误，拒绝静默降级。

/// 实际生效的特权获取策略。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProvisionStrategy {
    Unprovisioned,
    /// rlimits / root 直接授予
    Direct,
    /// Linux D-Bus rtkit（参考实现未接入，占位）
    Rtkit,
    /// xdg-desktop-portal（参考实现未接入，占位）
    Portal,
    /// macOS `thread_policy_set` / QoS
    MacOsPolicy,
    /// Windows MMCSS（参考实现未接入，占位）
    WindowsMmcss,
    /// SCHED_OTHER + nice -10 / 无任何保证
    Fallback,
}

/// 特权获取模式（§3.3.2）。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ThreadProvisioning {
    /// 允许逐级降级到 Fallback（桌面应用默认）
    BestEffort,
    /// 拿不到硬实时特权则失败（现场级混音台必须启用）
    Strict(StrictAction),
}

impl ThreadProvisioning {
    /// 是否禁止静默降级。
    #[inline(always)]
    pub fn is_strict(self) -> bool {
        matches!(self, ThreadProvisioning::Strict(_))
    }
}

/// Strict 模式下的失败动作。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StrictAction {
    /// 立即返回致命错误（由上层决定 panic/abort）
    FatalError,
    /// 有限重试后失败
    RetryWithBackoff { max_ms: u64 },
}

/// 特权申请失败原因。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProvisionError {
    /// EPERM：普通用户无 SCHED_FIFO 权限
    PermissionDenied,
    /// 当前平台无实时调度概念
    Unsupported,
    /// Strict 模式下拒绝降级
    StrictModeRefused,
}

impl core::fmt::Display for ProvisionError {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        let message = match self {
            ProvisionError::PermissionDenied => "realtime scheduling permission denied",
            ProvisionError::Unsupported => "platform has no realtime scheduling",
            ProvisionError::StrictModeRefused => "strict mode refused a silent downgrade",
        };
        f.write_str(message)
    }
}

impl std::error::Error for ProvisionError {}

/// 跨平台实时特权管理器。
///
/// 不变式 #19：所有平台资源句柄（如 MMCSS handle）必须在 `Drop` 中恢复；
/// 发生降级时必须通过 EventBus 发出 `ThreadProvisionerFallback` 事件
/// （事件发射由上层 kernel 编排，本类型仅暴露 [`Self::fallback_active`]）。
pub struct ThreadProvisioner {
    strategy: ProvisionStrategy,
    requested_prio: i32,
    granted_prio: i32,
    fallback_active: bool,
    #[cfg(target_os = "linux")]
    original_linux_schedule: Option<linux_sched::LinuxSchedule>,
    // Realtime scheduling and MMCSS handles belong to the provisioning thread.
    _not_send: core::marker::PhantomData<*const ()>,
}

impl ThreadProvisioner {
    pub fn new() -> Self {
        Self {
            strategy: ProvisionStrategy::Unprovisioned,
            requested_prio: 0,
            granted_prio: 0,
            fallback_active: false,
            #[cfg(target_os = "linux")]
            original_linux_schedule: None,
            _not_send: core::marker::PhantomData,
        }
    }

    pub fn strategy(&self) -> ProvisionStrategy {
        self.strategy
    }

    pub fn requested_prio(&self) -> i32 {
        self.requested_prio
    }

    pub fn granted_prio(&self) -> i32 {
        self.granted_prio
    }

    /// 是否发生了降级（上层据此发射 `ThreadProvisionerFallback` 事件）。
    pub fn fallback_active(&self) -> bool {
        self.fallback_active
    }

    /// 为**当前线程**申请实时调度特权。目标耗时 <500µs（§4.6）。
    ///
    /// - `BestEffort`：失败时降级为 [`ProvisionStrategy::Fallback`] 并返回 `Ok(0)`
    /// - `Strict`：失败时返回 [`ProvisionError::StrictModeRefused`]，不修改线程状态
    pub fn provision(
        &mut self,
        target_prio: i32,
        mode: ThreadProvisioning,
    ) -> Result<i32, ProvisionError> {
        self.requested_prio = target_prio;
        match self.try_direct(target_prio) {
            Ok((strategy, granted)) => {
                self.strategy = strategy;
                self.granted_prio = granted;
                self.fallback_active = granted < target_prio;
                Ok(granted)
            }
            Err(_) if mode.is_strict() => {
                // 现场级：拒绝静默降级（§3.3.2）。线程调度状态保持不变。
                Err(ProvisionError::StrictModeRefused)
            }
            Err(_) => {
                self.strategy = ProvisionStrategy::Fallback;
                self.granted_prio = 0;
                self.fallback_active = true;
                Ok(0)
            }
        }
    }

    // ---- Linux：sched_setscheduler(SCHED_FIFO) 直接申请（§3.3.3）----
    #[cfg(target_os = "linux")]
    fn try_direct(&mut self, prio: i32) -> Result<(ProvisionStrategy, i32), ProvisionError> {
        let original = linux_sched::current().ok_or(ProvisionError::Unsupported)?;
        let param = linux_sched::SchedParam {
            sched_priority: prio.clamp(1, 99),
        };
        // SAFETY: 参数为有效栈上结构体，pid=0 表示当前调度实体
        let rc = unsafe { linux_sched::sched_setscheduler(0, linux_sched::SCHED_FIFO, &param) };
        if rc == 0 {
            self.original_linux_schedule = Some(original);
            Ok((ProvisionStrategy::Direct, param.sched_priority))
        } else {
            // 生产实现：此处应继续尝试 rtkit(zbus) → portal，见 §3.3.3
            Err(ProvisionError::PermissionDenied)
        }
    }

    // ---- macOS：QoS USER_INTERACTIVE（§3.3.4 / 附录 C.2）----
    // 生产实现应优先 thread_policy_set(THREAD_TIME_CONSTRAINT_POLICY)，
    // 并防止音频线程被调度到 E-Core。
    #[cfg(target_os = "macos")]
    fn try_direct(&mut self, prio: i32) -> Result<(ProvisionStrategy, i32), ProvisionError> {
        const QOS_CLASS_USER_INTERACTIVE: u32 = 0x21;
        extern "C" {
            fn pthread_set_qos_class_self_np(qos_class: u32, relative_priority: i32) -> i32;
        }
        // SAFETY: 系统调用参数为合法 QoS 常量
        let rc = unsafe { pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0) };
        if rc == 0 {
            Ok((ProvisionStrategy::MacOsPolicy, prio))
        } else {
            Err(ProvisionError::PermissionDenied)
        }
    }

    // ---- 其余平台：参考实现不申请特权（Windows 生产实现走 MMCSS，§3.3.5）----
    #[cfg(not(any(target_os = "linux", target_os = "macos")))]
    fn try_direct(&mut self, _prio: i32) -> Result<(ProvisionStrategy, i32), ProvisionError> {
        Err(ProvisionError::Unsupported)
    }
}

impl Default for ThreadProvisioner {
    fn default() -> Self {
        Self::new()
    }
}

// 不变式 #19：Drop 中恢复平台资源。
// Windows 生产实现须在此调用 AvRevertMmThreadCharacteristics(mmcss_handle)。
impl Drop for ThreadProvisioner {
    fn drop(&mut self) {
        #[cfg(target_os = "linux")]
        if let Some(original) = self.original_linux_schedule.take() {
            // SAFETY: the provisioner is !Send and therefore drops on the same
            // thread whose policy was captured before SCHED_FIFO was applied.
            unsafe {
                linux_sched::sched_setscheduler(0, original.policy, &original.param);
            }
        }
    }
}

#[cfg(target_os = "linux")]
mod linux_sched {
    #[repr(C)]
    #[derive(Clone, Copy)]
    pub(super) struct SchedParam {
        pub(super) sched_priority: i32,
    }

    #[derive(Clone, Copy)]
    pub(super) struct LinuxSchedule {
        pub(super) policy: i32,
        pub(super) param: SchedParam,
    }

    pub(super) const SCHED_FIFO: i32 = 1;

    extern "C" {
        pub(super) fn sched_getscheduler(pid: i32) -> i32;
        pub(super) fn sched_getparam(pid: i32, param: *mut SchedParam) -> i32;
        pub(super) fn sched_setscheduler(pid: i32, policy: i32, param: *const SchedParam) -> i32;
    }

    pub(super) fn current() -> Option<LinuxSchedule> {
        // SAFETY: pid=0 selects the calling thread and `param` is a valid out-pointer.
        unsafe {
            let policy = sched_getscheduler(0);
            if policy < 0 {
                return None;
            }
            let mut param = SchedParam { sched_priority: 0 };
            if sched_getparam(0, &mut param) < 0 {
                return None;
            }
            Some(LinuxSchedule { policy, param })
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn provision_default_is_unprovisioned() {
        let p = ThreadProvisioner::new();
        assert_eq!(p.strategy(), ProvisionStrategy::Unprovisioned);
        assert_eq!(p.granted_prio(), 0);
        assert!(!p.fallback_active());
    }

    #[test]
    fn best_effort_always_resolves_to_a_known_strategy() {
        let mut p = ThreadProvisioner::new();
        let granted = p
            .provision(95, ThreadProvisioning::BestEffort)
            .expect("best-effort provisioning never fails");
        assert!(granted >= 0);
        assert_ne!(p.strategy(), ProvisionStrategy::Unprovisioned);
        assert_eq!(p.requested_prio(), 95);
        // 未拿到完整优先级时必须标记降级，供上层发射事件。
        assert_eq!(p.fallback_active(), granted < 95);
    }

    #[test]
    fn strict_mode_refuses_silent_downgrade() {
        let mut p = ThreadProvisioner::new();
        let result = p.provision(95, ThreadProvisioning::Strict(StrictAction::FatalError));
        match result {
            // CI 普通用户环境：必须拒绝降级
            Err(e) => assert_eq!(e, ProvisionError::StrictModeRefused),
            // 恰好具备实时特权的主机：成功亦合法
            Ok(granted) => assert!(granted > 0),
        }
    }

    #[test]
    fn strict_mode_does_not_mutate_state_on_refusal() {
        let mut p = ThreadProvisioner::new();
        if p.provision(99, ThreadProvisioning::Strict(StrictAction::FatalError))
            .is_err()
        {
            assert_eq!(
                p.strategy(),
                ProvisionStrategy::Unprovisioned,
                "Strict 拒绝后不得留下 Fallback 状态"
            );
            assert!(!p.fallback_active());
        }
    }

    #[test]
    fn provisioning_mode_reports_strictness() {
        assert!(!ThreadProvisioning::BestEffort.is_strict());
        assert!(ThreadProvisioning::Strict(StrictAction::FatalError).is_strict());
        assert!(ThreadProvisioning::Strict(StrictAction::RetryWithBackoff { max_ms: 50 }).is_strict());
    }
}
