//! # Stream 生命周期管理（§5.1）
//!
//! ```text
//!                    ┌──────────────────────────────┐
//!                    ▼                              │ reset
//!   ┌────────┐ start ┌───────────┐ ready ┌─────────┐│
//!   │  Idle  │──────►│ Preparing │──────►│ Running ││
//!   └────────┘       └───────────┘       └─────────┘│
//!        ▲  ▲   abort     │                    │    │
//!        │  └─────────────┘                    │stop│
//!        │                                     ▼    │
//!        │  drained                      ┌──────────┴┐
//!        └───────────────────────────────│  Draining │
//!        ▲                               └───────────┘
//!        │ reset                               │
//!   ┌────┴────┐◄────────── fail ────────────────┘
//!   │  Error  │
//!   └─────────┘
//! ```
//!
//! [`StreamHandle`] 使用 `compare_exchange` 完成状态迁移，因此在
//! 控制线程与音频线程并发调用时也不会出现丢失更新（load-then-store 竞态）。
//!
//! ## 关于类型态（typestate）
//!
//! 这里曾有一套 `TypedStream<S>` + `typestate::{Idle, Preparing, ...}`，
//! 已删除：零使用者，且 doctest 从未被验证过。
//!
//! 重新引入的条件：**出现真实调用点**——即有一段业务代码，其正确性依赖
//! "非法迁移无法编译"而非"非法迁移返回 Err"。仅仅"看起来更类型安全"
//! 不构成理由：运行时 CAS 已经覆盖了并发正确性，类型态只能覆盖单线程
//! 顺序，而流的状态本来就是跨线程共享的。

use core::fmt;
use core::sync::atomic::{AtomicU32, AtomicU8, Ordering};

/// Stream 状态。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[repr(u8)]
pub enum StreamState {
    /// 流未初始化或已完全停止
    Idle = 0,
    /// 正在协商格式、申请特权、分配资源
    Preparing = 1,
    /// 音频回调正常运行
    Running = 2,
    /// 正在排空缓冲（优雅关闭）
    Draining = 3,
    /// 发生不可恢复错误，需显式 reset
    Error = 4,
}

impl StreamState {
    /// 从原始值还原（用于原子加载）。未知值一律视为 [`StreamState::Error`]。
    #[inline(always)]
    pub const fn from_raw(raw: u8) -> Self {
        match raw {
            0 => StreamState::Idle,
            1 => StreamState::Preparing,
            2 => StreamState::Running,
            3 => StreamState::Draining,
            _ => StreamState::Error,
        }
    }

    /// 当前状态是否允许迁移到 `target`。
    #[inline(always)]
    pub const fn can_transition_to(self, target: StreamState) -> bool {
        matches!(
            (self, target),
            // 正常路径
            (StreamState::Idle, StreamState::Preparing)
                | (StreamState::Preparing, StreamState::Running)
                | (StreamState::Running, StreamState::Draining)
                | (StreamState::Draining, StreamState::Idle)
                // 准备阶段可中止
                | (StreamState::Preparing, StreamState::Idle)
                // 任意活动状态都可能失败
                | (StreamState::Preparing, StreamState::Error)
                | (StreamState::Running, StreamState::Error)
                | (StreamState::Draining, StreamState::Error)
                // 错误恢复
                | (StreamState::Error, StreamState::Idle)
        )
    }

    /// 音频回调此刻是否应当产生音频。
    #[inline(always)]
    pub const fn is_active(self) -> bool {
        matches!(self, StreamState::Running | StreamState::Draining)
    }
}

impl fmt::Display for StreamState {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let name = match self {
            StreamState::Idle => "idle",
            StreamState::Preparing => "preparing",
            StreamState::Running => "running",
            StreamState::Draining => "draining",
            StreamState::Error => "error",
        };
        f.write_str(name)
    }
}

/// Stream 配置参数。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct StreamConfig {
    pub sample_rate: u32,
    pub block_size: usize,
    pub input_channels: u16,
    pub output_channels: u16,
    pub bit_depth: u8,
    pub buffer_count: u8,
}

impl StreamConfig {
    /// 校验配置是否落在可支持范围内。
    pub fn validate(&self) -> Result<(), StreamError> {
        if !(8_000..=384_000).contains(&self.sample_rate) {
            return Err(StreamError::UnsupportedFormat);
        }
        if self.block_size == 0 || self.block_size > 8_192 {
            return Err(StreamError::UnsupportedFormat);
        }
        if self.output_channels == 0 || self.output_channels > 8 || self.input_channels > 8 {
            return Err(StreamError::UnsupportedFormat);
        }
        if !matches!(self.bit_depth, 16 | 24 | 32 | 64) {
            return Err(StreamError::UnsupportedFormat);
        }
        if self.buffer_count < 2 {
            return Err(StreamError::UnsupportedFormat);
        }
        Ok(())
    }

    /// 单个块的时长（微秒）。
    pub fn block_duration_us(&self) -> f64 {
        if self.sample_rate == 0 {
            return 0.0;
        }
        self.block_size as f64 / self.sample_rate as f64 * 1_000_000.0
    }
}

impl Default for StreamConfig {
    fn default() -> Self {
        Self {
            sample_rate: 96_000,
            block_size: 512,
            input_channels: 2,
            output_channels: 2,
            bit_depth: 32,
            buffer_count: 2,
        }
    }
}

/// Stream 错误。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StreamError {
    /// 非法状态迁移（附起止状态便于诊断）
    InvalidTransition {
        from: StreamState,
        to: StreamState,
    },
    /// 设备不可用
    DeviceUnavailable,
    /// 格式或配置不支持
    UnsupportedFormat,
    /// 资源不足
    ResourceExhaustion,
    /// 宿主后端错误
    HostBackendError,
    /// 流已关闭
    StreamClosed,
}

impl fmt::Display for StreamError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            StreamError::InvalidTransition { from, to } => {
                write!(f, "illegal stream transition {from} -> {to}")
            }
            StreamError::DeviceUnavailable => f.write_str("audio device unavailable"),
            StreamError::UnsupportedFormat => f.write_str("unsupported stream configuration"),
            StreamError::ResourceExhaustion => f.write_str("insufficient resources"),
            StreamError::HostBackendError => f.write_str("host backend error"),
            StreamError::StreamClosed => f.write_str("stream is closed"),
        }
    }
}

impl std::error::Error for StreamError {}

/// 无锁 Stream 状态句柄，可被控制线程与音频线程共享。
pub struct StreamHandle {
    state: AtomicU8,
    transitions: AtomicU32,
    config: StreamConfig,
}

impl StreamHandle {
    pub fn new(config: StreamConfig) -> Self {
        Self {
            state: AtomicU8::new(StreamState::Idle as u8),
            transitions: AtomicU32::new(0),
            config,
        }
    }

    /// 当前状态（无锁读取，音频回调可安全调用）。
    #[inline(always)]
    pub fn state(&self) -> StreamState {
        StreamState::from_raw(self.state.load(Ordering::Acquire))
    }

    /// 已完成的迁移次数（诊断用）。
    #[inline(always)]
    pub fn transition_count(&self) -> u32 {
        self.transitions.load(Ordering::Relaxed)
    }

    pub fn config(&self) -> &StreamConfig {
        &self.config
    }

    /// 原子状态迁移。
    ///
    /// 使用 CAS 循环，因此并发调用时只有一个会成功，另一个得到
    /// [`StreamError::InvalidTransition`]，不会出现丢失更新。
    pub fn transition(&self, target: StreamState) -> Result<StreamState, StreamError> {
        let mut current_raw = self.state.load(Ordering::Acquire);
        loop {
            let current = StreamState::from_raw(current_raw);
            if !current.can_transition_to(target) {
                return Err(StreamError::InvalidTransition {
                    from: current,
                    to: target,
                });
            }
            match self.state.compare_exchange_weak(
                current_raw,
                target as u8,
                Ordering::AcqRel,
                Ordering::Acquire,
            ) {
                Ok(_) => {
                    self.transitions.fetch_add(1, Ordering::Relaxed);
                    return Ok(current);
                }
                Err(observed) => current_raw = observed,
            }
        }
    }

    /// 从任意状态强制进入 [`StreamState::Error`]（宿主回调内的失败路径）。
    ///
    /// 该操作永不失败：错误状态必须总是可达，否则故障无法上报。
    pub fn fail(&self) -> StreamState {
        let previous = self.state.swap(StreamState::Error as u8, Ordering::AcqRel);
        self.transitions.fetch_add(1, Ordering::Relaxed);
        StreamState::from_raw(previous)
    }
}

impl fmt::Debug for StreamHandle {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("StreamHandle")
            .field("state", &self.state())
            .field("transitions", &self.transition_count())
            .finish()
    }
}

/// 状态机 trait，便于对不同实现做泛型编程与测试替身。
pub trait StreamStateMachine {
    fn current_state(&self) -> StreamState;
    fn try_transition(&self, target: StreamState) -> Result<StreamState, StreamError>;
}

impl StreamStateMachine for StreamHandle {
    fn current_state(&self) -> StreamState {
        self.state()
    }

    fn try_transition(&self, target: StreamState) -> Result<StreamState, StreamError> {
        self.transition(target)
    }
}

/// 音频流：把状态机包装成高层生命周期动作。
#[derive(Debug)]
pub struct AudioStream {
    handle: StreamHandle,
}

impl AudioStream {
    /// 创建流。配置非法时立即返回错误，不进入状态机。
    pub fn new(config: StreamConfig) -> Result<Self, StreamError> {
        config.validate()?;
        Ok(Self {
            handle: StreamHandle::new(config),
        })
    }

    pub fn handle(&self) -> &StreamHandle {
        &self.handle
    }

    pub fn state(&self) -> StreamState {
        self.handle.state()
    }

    /// 启动流：`Idle → Preparing → Running`。
    ///
    /// 若 `prepare` 返回错误，流会回到 `Idle`（可重试）而不是卡在 `Preparing`。
    pub fn start_with<F>(&mut self, prepare: F) -> Result<(), StreamError>
    where
        F: FnOnce(&StreamConfig) -> Result<(), StreamError>,
    {
        self.handle.transition(StreamState::Preparing)?;
        match prepare(self.handle.config()) {
            Ok(()) => {
                self.handle.transition(StreamState::Running)?;
                Ok(())
            }
            Err(error) => {
                // 中止准备，回到可重试的 Idle。
                let _ = self.handle.transition(StreamState::Idle);
                Err(error)
            }
        }
    }

    /// 启动流（无额外准备工作）。
    pub fn start(&mut self) -> Result<(), StreamError> {
        self.start_with(|_| Ok(()))
    }

    /// 停止流：`Running → Draining → Idle`。
    pub fn stop_with<F>(&mut self, drain: F) -> Result<(), StreamError>
    where
        F: FnOnce() -> Result<(), StreamError>,
    {
        self.handle.transition(StreamState::Draining)?;
        match drain() {
            Ok(()) => {
                self.handle.transition(StreamState::Idle)?;
                Ok(())
            }
            Err(error) => {
                self.handle.fail();
                Err(error)
            }
        }
    }

    /// 停止流（无额外排空工作）。
    pub fn stop(&mut self) -> Result<(), StreamError> {
        self.stop_with(|| Ok(()))
    }

    /// 标记流失败（可从任意状态调用）。
    pub fn fail(&mut self) -> StreamState {
        self.handle.fail()
    }

    /// 从 [`StreamState::Error`] 恢复到 [`StreamState::Idle`]。
    pub fn reset(&mut self) -> Result<(), StreamError> {
        self.handle.transition(StreamState::Idle).map(|_| ())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn happy_path_lifecycle() {
        let mut stream = AudioStream::new(StreamConfig::default()).unwrap();
        assert_eq!(stream.state(), StreamState::Idle);
        assert!(!stream.state().is_active());

        stream.start().unwrap();
        assert_eq!(stream.state(), StreamState::Running);
        assert!(stream.state().is_active());

        stream.stop().unwrap();
        assert_eq!(stream.state(), StreamState::Idle);
        // Idle→Preparing→Running→Draining→Idle
        assert_eq!(stream.handle().transition_count(), 4);
    }

    #[test]
    fn invalid_transitions_report_both_endpoints() {
        let handle = StreamHandle::new(StreamConfig::default());
        assert_eq!(
            handle.transition(StreamState::Draining),
            Err(StreamError::InvalidTransition {
                from: StreamState::Idle,
                to: StreamState::Draining,
            })
        );
        assert_eq!(handle.transition_count(), 0, "失败迁移不得计数");
    }

    #[test]
    fn failed_preparation_returns_to_idle() {
        let mut stream = AudioStream::new(StreamConfig::default()).unwrap();
        let error = stream
            .start_with(|_| Err(StreamError::DeviceUnavailable))
            .unwrap_err();
        assert_eq!(error, StreamError::DeviceUnavailable);
        assert_eq!(
            stream.state(),
            StreamState::Idle,
            "准备失败必须回到可重试的 Idle，而不是卡在 Preparing"
        );
        // 可以重试
        stream.start().unwrap();
        assert_eq!(stream.state(), StreamState::Running);
    }

    #[test]
    fn failure_is_always_reachable_and_recoverable() {
        let mut stream = AudioStream::new(StreamConfig::default()).unwrap();
        stream.start().unwrap();

        let previous = stream.fail();
        assert_eq!(previous, StreamState::Running);
        assert_eq!(stream.state(), StreamState::Error);
        assert!(!stream.state().is_active());

        // Error 状态下不能直接启动
        assert!(matches!(
            stream.start(),
            Err(StreamError::InvalidTransition { .. })
        ));

        stream.reset().unwrap();
        assert_eq!(stream.state(), StreamState::Idle);
        stream.start().unwrap();
        assert_eq!(stream.state(), StreamState::Running);
    }

    #[test]
    fn drain_failure_moves_to_error() {
        let mut stream = AudioStream::new(StreamConfig::default()).unwrap();
        stream.start().unwrap();
        let error = stream
            .stop_with(|| Err(StreamError::HostBackendError))
            .unwrap_err();
        assert_eq!(error, StreamError::HostBackendError);
        assert_eq!(stream.state(), StreamState::Error);
    }

    #[test]
    fn concurrent_transitions_have_exactly_one_winner() {
        use std::sync::Arc;
        use std::thread;

        let handle = Arc::new(StreamHandle::new(StreamConfig::default()));
        let mut workers = Vec::new();
        for _ in 0..8 {
            let handle = Arc::clone(&handle);
            workers.push(thread::spawn(move || {
                handle.transition(StreamState::Preparing).is_ok()
            }));
        }
        let winners = workers
            .into_iter()
            .map(|worker| worker.join().unwrap_or(false))
            .filter(|won| *won)
            .count();

        assert_eq!(winners, 1, "CAS 必须保证只有一个迁移成功");
        assert_eq!(handle.state(), StreamState::Preparing);
        assert_eq!(handle.transition_count(), 1);
    }

    #[test]
    fn configuration_is_validated_up_front() {
        let mut config = StreamConfig::default();
        assert!(config.validate().is_ok());

        config.sample_rate = 3;
        assert_eq!(config.validate(), Err(StreamError::UnsupportedFormat));
        assert!(matches!(
            AudioStream::new(config),
            Err(StreamError::UnsupportedFormat)
        ));

        let zero_block = StreamConfig {
            block_size: 0,
            ..StreamConfig::default()
        };
        assert_eq!(zero_block.validate(), Err(StreamError::UnsupportedFormat));

        let single_buffer = StreamConfig {
            buffer_count: 1,
            ..StreamConfig::default()
        };
        assert_eq!(
            single_buffer.validate(),
            Err(StreamError::UnsupportedFormat)
        );

        let odd_depth = StreamConfig {
            bit_depth: 20,
            ..StreamConfig::default()
        };
        assert_eq!(odd_depth.validate(), Err(StreamError::UnsupportedFormat));
    }

    #[test]
    fn block_duration_matches_the_sample_rate() {
        let config = StreamConfig {
            sample_rate: 48_000,
            block_size: 480,
            ..StreamConfig::default()
        };
        assert!((config.block_duration_us() - 10_000.0).abs() < 1e-9);
    }

    #[test]
    fn unknown_raw_states_degrade_to_error() {
        assert_eq!(StreamState::from_raw(0), StreamState::Idle);
        assert_eq!(StreamState::from_raw(200), StreamState::Error);
    }
}
