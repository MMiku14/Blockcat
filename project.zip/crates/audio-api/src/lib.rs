//! # audio-api — 通用 API 层
//!
//! Audio Runtime 实时音频微内核的稳定编程接口。
//!
//! | 模块 | 职责 |
//! |------|------|
//! | [`stream`]     | Stream 生命周期状态机（§5.1） |
//! | [`format`]     | 统一的格式协商与转换策略（§5.2） |
//! | [`control`]    | 稳定的控制面与事件面（§5.3） |
//! | [`descriptor`] | DSP 通用节点描述与图事务（§5.4） |
//!
//! ## 实时安全约定
//!
//! 跨越音频线程边界的所有类型（[`control::ControlRequest`]、
//! [`control::EventPlane`]）都是 `Copy` 且只含标量与 `&'static str`，
//! 因此可以直接放进 `audio-core` 的无锁 SPSC 环，音频线程不分配也不释放内存。
//!
//! ## 依赖规则
//!
//! 可依赖 `audio-core`；**不可**依赖 `audio-host` / `audio-dsp`，
//! 以保证 API 层可被任意后端与任意图实现复用。

#![deny(unsafe_op_in_unsafe_fn)]

pub mod control;
pub mod descriptor;
pub mod format;
pub mod stream;

pub use control::{
    ControlChannel, ControlReceiver, ControlRequest, ControlResponse, ControlSender, DeviceInfo,
    EventChannel, EventHub, EventHubReceiver, EventHubSender, EventPlane, EventReceiver,
    EventSender, EventSink, FnEventSink,
};
pub use descriptor::{
    AudioPortDescriptor, DspNodeDescriptor, EdgeDescriptor, GraphOp, GraphSpec, GraphTransaction,
    NodeClass, ParameterDescriptor, PortDirection, PortType, TransactionError, TransactionLog,
};
pub use format::{
    convert, AudioFormat, BitDepth, ChannelLayout, DefaultFormatNegotiator, FormatConversion,
    FormatError, FormatNegotiator, SampleFormat,
};
pub use stream::{
    AudioStream, StreamConfig, StreamError, StreamHandle, StreamState, StreamStateMachine,
};
