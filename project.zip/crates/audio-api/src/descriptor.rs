//! # DSP 通用节点描述与图事务（§5.4）
//!
//! 两部分能力：
//!
//! 1. **自描述**：[`DspNodeDescriptor`] 让宿主/UI 在不实例化节点的前提下
//!    了解端口拓扑、参数集合、延迟与 CPU 预算。
//! 2. **图事务**：[`GraphTransaction`] 把一批增删改操作累积起来，
//!    在 [`GraphTransaction::commit`] 时**整体校验**（越界、重复边、自环、
//!    环路）。任何一步失败都会整体回滚，[`GraphSpec`] 保持提交前的状态。
//!
//! 事务在控制线程执行，可自由分配；音频线程只会看到校验通过的最终结果。

use core::fmt;
use std::collections::VecDeque;

/// 节点类别。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum NodeClass {
    /// 信号源（输入、振荡器、文件播放）
    Source,
    /// 信号处理器（滤波器、增益、混响）
    Processor,
    /// 信号汇聚器（混音、求和）
    Mixer,
    /// 信号宿（输出、录音）
    Sink,
    /// 分析节点（电平表、频谱）
    Analyzer,
}

/// 端口方向。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PortDirection {
    Input,
    Output,
}

/// 端口类型。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PortType {
    Audio,
    Control,
    Event,
    Sidechain,
}

/// 音频端口描述。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct AudioPortDescriptor {
    pub name: &'static str,
    pub direction: PortDirection,
    pub port_type: PortType,
    pub channels: u16,
}

/// 参数描述（供 UI 自动生成控件）。
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ParameterDescriptor {
    pub id: u32,
    pub name: &'static str,
    pub unit: &'static str,
    pub min: f32,
    pub max: f32,
    pub default: f32,
}

impl ParameterDescriptor {
    /// 将任意输入夹紧到合法区间。
    #[inline(always)]
    pub fn clamp(&self, value: f32) -> f32 {
        value.clamp(self.min, self.max)
    }

    /// 值是否落在合法区间内。
    #[inline(always)]
    pub fn accepts(&self, value: f32) -> bool {
        value.is_finite() && value >= self.min && value <= self.max
    }
}

/// DSP 节点通用描述。全部字段为 `'static`，可作为常量声明。
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DspNodeDescriptor {
    pub name: &'static str,
    pub class: NodeClass,
    pub input_ports: &'static [AudioPortDescriptor],
    pub output_ports: &'static [AudioPortDescriptor],
    pub parameters: &'static [ParameterDescriptor],
    /// 节点引入的固定算法延迟（采样数）
    pub latency_samples: usize,
    /// 典型 CPU 预算（微秒）
    pub cpu_budget_us: u32,
}

impl DspNodeDescriptor {
    /// 按 id 查找参数描述。
    pub fn parameter(&self, id: u32) -> Option<&'static ParameterDescriptor> {
        self.parameters.iter().find(|param| param.id == id)
    }

    /// 是否可以作为图的输入端（无音频输入口）。
    pub fn is_source(&self) -> bool {
        self.input_ports
            .iter()
            .all(|port| port.port_type != PortType::Audio)
    }

    /// 是否可以作为图的输出端（无音频输出口）。
    pub fn is_sink(&self) -> bool {
        self.output_ports
            .iter()
            .all(|port| port.port_type != PortType::Audio)
    }
}

/// 拓扑边描述。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct EdgeDescriptor {
    pub from_node: usize,
    pub from_port: usize,
    pub to_node: usize,
    pub to_port: usize,
}

impl EdgeDescriptor {
    pub const fn simple(from_node: usize, to_node: usize) -> Self {
        Self {
            from_node,
            from_port: 0,
            to_node,
            to_port: 0,
        }
    }
}

/// 事务中的单步操作。
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum GraphOp {
    AddNode(DspNodeDescriptor),
    RemoveNode(usize),
    Connect(EdgeDescriptor),
    Disconnect(EdgeDescriptor),
    SetParameter {
        node_index: usize,
        param_id: u32,
        value: f32,
    },
}

/// 事务失败原因。失败时 [`GraphSpec`] **保持不变**。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TransactionError {
    /// 节点索引越界（携带出错的步骤序号与索引）
    NodeOutOfBounds { step: usize, node_index: usize },
    /// 端口索引越界
    PortOutOfBounds { step: usize, port_index: usize },
    /// 边已存在
    DuplicateEdge { step: usize },
    /// 边不存在
    UnknownEdge { step: usize },
    /// 自环
    SelfLoop { step: usize },
    /// 参数不存在
    UnknownParameter { step: usize, param_id: u32 },
    /// 参数值越界或非有限数
    ParameterOutOfRange { step: usize, param_id: u32 },
    /// 提交后拓扑出现环路
    CycleDetected,
    /// 提交后图为空
    EmptyGraph,
}

impl fmt::Display for TransactionError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            TransactionError::NodeOutOfBounds { step, node_index } => {
                write!(f, "step {step}: node index {node_index} out of bounds")
            }
            TransactionError::PortOutOfBounds { step, port_index } => {
                write!(f, "step {step}: port index {port_index} out of bounds")
            }
            TransactionError::DuplicateEdge { step } => write!(f, "step {step}: duplicate edge"),
            TransactionError::UnknownEdge { step } => write!(f, "step {step}: unknown edge"),
            TransactionError::SelfLoop { step } => write!(f, "step {step}: self loop"),
            TransactionError::UnknownParameter { step, param_id } => {
                write!(f, "step {step}: unknown parameter {param_id}")
            }
            TransactionError::ParameterOutOfRange { step, param_id } => {
                write!(f, "step {step}: parameter {param_id} out of range")
            }
            TransactionError::CycleDetected => f.write_str("resulting topology contains a cycle"),
            TransactionError::EmptyGraph => f.write_str("resulting graph has no nodes"),
        }
    }
}

impl std::error::Error for TransactionError {}

/// 提交成功后的摘要。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TransactionLog {
    pub applied_ops: usize,
    pub node_count: usize,
    pub edge_count: usize,
    /// 图级总延迟（所有路径的最大累计延迟）
    pub total_latency_samples: usize,
}

/// 图的声明式快照（控制线程持有，音频线程永不触碰）。
#[derive(Debug, Clone, Default, PartialEq)]
pub struct GraphSpec {
    nodes: Vec<DspNodeDescriptor>,
    edges: Vec<EdgeDescriptor>,
    parameter_values: Vec<(usize, u32, f32)>,
}

impl GraphSpec {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn nodes(&self) -> &[DspNodeDescriptor] {
        &self.nodes
    }

    pub fn edges(&self) -> &[EdgeDescriptor] {
        &self.edges
    }

    pub fn node_count(&self) -> usize {
        self.nodes.len()
    }

    pub fn edge_count(&self) -> usize {
        self.edges.len()
    }

    pub fn is_empty(&self) -> bool {
        self.nodes.is_empty()
    }

    /// 已显式设置的参数值。
    pub fn parameter_value(&self, node_index: usize, param_id: u32) -> Option<f32> {
        self.parameter_values
            .iter()
            .find(|(node, id, _)| *node == node_index && *id == param_id)
            .map(|(_, _, value)| *value)
    }

    /// 图级总延迟：所有输入→输出路径中的最大累计延迟。
    pub fn total_latency_samples(&self) -> usize {
        let n = self.nodes.len();
        if n == 0 {
            return 0;
        }
        let Some(order) = self.topological_order() else {
            return 0;
        };

        let mut predecessors: Vec<Vec<usize>> = vec![Vec::new(); n];
        let mut has_successor = vec![false; n];
        for edge in &self.edges {
            predecessors[edge.to_node].push(edge.from_node);
            has_successor[edge.from_node] = true;
        }

        let mut path_latency = vec![0usize; n];
        for &index in &order {
            let inbound = predecessors[index]
                .iter()
                .map(|&p| path_latency[p])
                .max()
                .unwrap_or(0);
            path_latency[index] = inbound.saturating_add(self.nodes[index].latency_samples);
        }

        (0..n)
            .filter(|&index| !has_successor[index])
            .map(|index| path_latency[index])
            .max()
            .unwrap_or(0)
    }

    /// Kahn 拓扑排序；含环时返回 `None`。
    fn topological_order(&self) -> Option<Vec<usize>> {
        let n = self.nodes.len();
        let mut indegree = vec![0usize; n];
        let mut adjacency: Vec<Vec<usize>> = vec![Vec::new(); n];
        for edge in &self.edges {
            adjacency[edge.from_node].push(edge.to_node);
            indegree[edge.to_node] += 1;
        }

        let mut queue: VecDeque<usize> = (0..n).filter(|&i| indegree[i] == 0).collect();
        let mut order = Vec::with_capacity(n);
        while let Some(u) = queue.pop_front() {
            order.push(u);
            for &v in &adjacency[u] {
                indegree[v] -= 1;
                if indegree[v] == 0 {
                    queue.push_back(v);
                }
            }
        }

        (order.len() == n).then_some(order)
    }
}

/// 原子化的图修改事务。
///
/// 操作先累积、后统一校验；`commit` 返回 `Err` 时目标 [`GraphSpec`] 未被修改。
#[derive(Debug, Clone, Default)]
pub struct GraphTransaction {
    ops: Vec<GraphOp>,
}

impl GraphTransaction {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn len(&self) -> usize {
        self.ops.len()
    }

    pub fn is_empty(&self) -> bool {
        self.ops.is_empty()
    }

    pub fn ops(&self) -> &[GraphOp] {
        &self.ops
    }

    pub fn push(&mut self, op: GraphOp) -> &mut Self {
        self.ops.push(op);
        self
    }

    pub fn add_node(&mut self, descriptor: DspNodeDescriptor) -> &mut Self {
        self.push(GraphOp::AddNode(descriptor))
    }

    pub fn remove_node(&mut self, node_index: usize) -> &mut Self {
        self.push(GraphOp::RemoveNode(node_index))
    }

    pub fn connect(&mut self, from_node: usize, to_node: usize) -> &mut Self {
        self.push(GraphOp::Connect(EdgeDescriptor::simple(from_node, to_node)))
    }

    pub fn connect_ports(&mut self, edge: EdgeDescriptor) -> &mut Self {
        self.push(GraphOp::Connect(edge))
    }

    pub fn disconnect(&mut self, from_node: usize, to_node: usize) -> &mut Self {
        self.push(GraphOp::Disconnect(EdgeDescriptor::simple(
            from_node, to_node,
        )))
    }

    pub fn set_parameter(&mut self, node_index: usize, param_id: u32, value: f32) -> &mut Self {
        self.push(GraphOp::SetParameter {
            node_index,
            param_id,
            value,
        })
    }

    /// 在 `spec` 的**副本**上顺序应用全部操作并整体校验。
    ///
    /// - 成功：`spec` 被原子替换为新状态，返回 [`TransactionLog`]
    /// - 失败：`spec` 保持不变，返回首个 [`TransactionError`]
    pub fn commit(&self, spec: &mut GraphSpec) -> Result<TransactionLog, TransactionError> {
        let mut staged = spec.clone();

        for (step, op) in self.ops.iter().enumerate() {
            apply_op(&mut staged, step, op)?;
        }

        if staged.nodes.is_empty() {
            return Err(TransactionError::EmptyGraph);
        }
        if staged.topological_order().is_none() {
            return Err(TransactionError::CycleDetected);
        }

        let log = TransactionLog {
            applied_ops: self.ops.len(),
            node_count: staged.node_count(),
            edge_count: staged.edge_count(),
            total_latency_samples: staged.total_latency_samples(),
        };
        // 全部校验通过后才原子替换。
        *spec = staged;
        Ok(log)
    }

    /// 只校验不提交（UI 可用于实时置灰非法操作）。
    pub fn dry_run(&self, spec: &GraphSpec) -> Result<TransactionLog, TransactionError> {
        self.commit(&mut spec.clone())
    }
}

fn apply_op(spec: &mut GraphSpec, step: usize, op: &GraphOp) -> Result<(), TransactionError> {
    match *op {
        GraphOp::AddNode(descriptor) => {
            spec.nodes.push(descriptor);
        }
        GraphOp::RemoveNode(node_index) => {
            if node_index >= spec.nodes.len() {
                return Err(TransactionError::NodeOutOfBounds { step, node_index });
            }
            spec.nodes.remove(node_index);
            // 移除相关边并重编号后继索引，保持引用完整性。
            spec.edges
                .retain(|edge| edge.from_node != node_index && edge.to_node != node_index);
            for edge in &mut spec.edges {
                if edge.from_node > node_index {
                    edge.from_node -= 1;
                }
                if edge.to_node > node_index {
                    edge.to_node -= 1;
                }
            }
            spec.parameter_values.retain(|(node, _, _)| *node != node_index);
            for (node, _, _) in &mut spec.parameter_values {
                if *node > node_index {
                    *node -= 1;
                }
            }
        }
        GraphOp::Connect(edge) => {
            validate_endpoint(spec, step, edge.from_node, edge.from_port, false)?;
            validate_endpoint(spec, step, edge.to_node, edge.to_port, true)?;
            if edge.from_node == edge.to_node {
                return Err(TransactionError::SelfLoop { step });
            }
            if spec.edges.contains(&edge) {
                return Err(TransactionError::DuplicateEdge { step });
            }
            spec.edges.push(edge);
        }
        GraphOp::Disconnect(edge) => {
            let before = spec.edges.len();
            spec.edges.retain(|existing| *existing != edge);
            if spec.edges.len() == before {
                return Err(TransactionError::UnknownEdge { step });
            }
        }
        GraphOp::SetParameter {
            node_index,
            param_id,
            value,
        } => {
            let node = spec
                .nodes
                .get(node_index)
                .ok_or(TransactionError::NodeOutOfBounds { step, node_index })?;
            let param = node
                .parameter(param_id)
                .ok_or(TransactionError::UnknownParameter { step, param_id })?;
            if !param.accepts(value) {
                return Err(TransactionError::ParameterOutOfRange { step, param_id });
            }
            match spec
                .parameter_values
                .iter_mut()
                .find(|(node, id, _)| *node == node_index && *id == param_id)
            {
                Some(slot) => slot.2 = value,
                None => spec.parameter_values.push((node_index, param_id, value)),
            }
        }
    }
    Ok(())
}

fn validate_endpoint(
    spec: &GraphSpec,
    step: usize,
    node_index: usize,
    port_index: usize,
    is_input: bool,
) -> Result<(), TransactionError> {
    let node = spec
        .nodes
        .get(node_index)
        .ok_or(TransactionError::NodeOutOfBounds { step, node_index })?;
    let ports = if is_input {
        node.input_ports
    } else {
        node.output_ports
    };
    if port_index >= ports.len() {
        return Err(TransactionError::PortOutOfBounds {
            step,
            port_index,
        });
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// 预设节点描述
// ---------------------------------------------------------------------------

const STEREO_IN: AudioPortDescriptor = AudioPortDescriptor {
    name: "audio_in",
    direction: PortDirection::Input,
    port_type: PortType::Audio,
    channels: 2,
};

const STEREO_OUT: AudioPortDescriptor = AudioPortDescriptor {
    name: "audio_out",
    direction: PortDirection::Output,
    port_type: PortType::Audio,
    channels: 2,
};

/// 增益节点。
pub const GAIN_NODE_DESCRIPTOR: DspNodeDescriptor = DspNodeDescriptor {
    name: "Gain",
    class: NodeClass::Processor,
    input_ports: &[STEREO_IN],
    output_ports: &[STEREO_OUT],
    parameters: &[ParameterDescriptor {
        id: 0,
        name: "gain",
        unit: "dB",
        min: -96.0,
        max: 24.0,
        default: 0.0,
    }],
    latency_samples: 0,
    cpu_budget_us: 50,
};

/// 双入单出混音器。
pub const MIXER_NODE_DESCRIPTOR: DspNodeDescriptor = DspNodeDescriptor {
    name: "Mixer",
    class: NodeClass::Mixer,
    input_ports: &[
        AudioPortDescriptor {
            name: "ch0",
            direction: PortDirection::Input,
            port_type: PortType::Audio,
            channels: 2,
        },
        AudioPortDescriptor {
            name: "ch1",
            direction: PortDirection::Input,
            port_type: PortType::Audio,
            channels: 2,
        },
    ],
    output_ports: &[STEREO_OUT],
    parameters: &[
        ParameterDescriptor {
            id: 0,
            name: "ch0_gain",
            unit: "dB",
            min: -96.0,
            max: 12.0,
            default: 0.0,
        },
        ParameterDescriptor {
            id: 1,
            name: "ch1_gain",
            unit: "dB",
            min: -96.0,
            max: 12.0,
            default: 0.0,
        },
    ],
    latency_samples: 0,
    cpu_budget_us: 100,
};

/// 线性相位 FIR（示例：带固定延迟的处理器）。
pub const FIR_NODE_DESCRIPTOR: DspNodeDescriptor = DspNodeDescriptor {
    name: "LinearPhaseFIR",
    class: NodeClass::Processor,
    input_ports: &[STEREO_IN],
    output_ports: &[STEREO_OUT],
    parameters: &[ParameterDescriptor {
        id: 0,
        name: "cutoff",
        unit: "Hz",
        min: 20.0,
        max: 20_000.0,
        default: 1_000.0,
    }],
    latency_samples: 128,
    cpu_budget_us: 400,
};

/// 输出节点。
pub const OUTPUT_NODE_DESCRIPTOR: DspNodeDescriptor = DspNodeDescriptor {
    name: "Output",
    class: NodeClass::Sink,
    input_ports: &[STEREO_IN],
    output_ports: &[],
    parameters: &[],
    latency_samples: 0,
    cpu_budget_us: 10,
};

// 已删除：`NodeRegistry`（name → DspNodeDescriptor 的运行时查找表）。
//
// 零使用者。内建节点是 `pub const`，调用方直接引用即可；需要枚举时写一个
// `const ALL: &[DspNodeDescriptor]` 数组就够，不需要带 `Vec` 的注册表。
//
// 重新引入的条件：出现**运行时才知道名字**的节点来源（如动态加载的插件
// 目录扫描）。届时注册表应同时携带工厂函数
// （`fn() -> Box<dyn DspNode>`），否则只有描述符而造不出节点，等于没用。

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn descriptors_expose_their_role() {
        assert_eq!(GAIN_NODE_DESCRIPTOR.class, NodeClass::Processor);
        assert!(OUTPUT_NODE_DESCRIPTOR.is_sink());
        assert!(!GAIN_NODE_DESCRIPTOR.is_sink());
        let gain = GAIN_NODE_DESCRIPTOR.parameter(0).expect("gain parameter");
        assert_eq!(gain.name, "gain");
        assert_eq!(gain.clamp(999.0), 24.0);
        assert!(!gain.accepts(f32::NAN));
    }

    #[test]
    fn transaction_commits_atomically() {
        let mut spec = GraphSpec::new();
        let mut transaction = GraphTransaction::new();
        transaction
            .add_node(GAIN_NODE_DESCRIPTOR)
            .add_node(FIR_NODE_DESCRIPTOR)
            .add_node(OUTPUT_NODE_DESCRIPTOR)
            .connect(0, 1)
            .connect(1, 2)
            .set_parameter(0, 0, -6.0);

        let log = transaction.commit(&mut spec).expect("valid transaction");
        assert_eq!(log.applied_ops, 6);
        assert_eq!(log.node_count, 3);
        assert_eq!(log.edge_count, 2);
        assert_eq!(log.total_latency_samples, 128);
        assert_eq!(spec.parameter_value(0, 0), Some(-6.0));
    }

    #[test]
    fn failed_transaction_leaves_the_spec_untouched() {
        let mut spec = GraphSpec::new();
        GraphTransaction::new()
            .add_node(GAIN_NODE_DESCRIPTOR)
            .add_node(OUTPUT_NODE_DESCRIPTOR)
            .connect(0, 1)
            .commit(&mut spec)
            .unwrap();
        let baseline = spec.clone();

        // 第 2 步引用了不存在的节点 —— 整个事务必须回滚。
        let mut bad = GraphTransaction::new();
        bad.add_node(GAIN_NODE_DESCRIPTOR).connect(2, 99);
        let error = bad.commit(&mut spec).unwrap_err();
        assert_eq!(
            error,
            TransactionError::NodeOutOfBounds {
                step: 1,
                node_index: 99
            }
        );
        assert_eq!(spec, baseline, "失败事务不得留下部分修改");
    }

    #[test]
    fn cycles_are_rejected_at_commit_time() {
        let mut spec = GraphSpec::new();
        let mut transaction = GraphTransaction::new();
        transaction
            .add_node(GAIN_NODE_DESCRIPTOR)
            .add_node(GAIN_NODE_DESCRIPTOR)
            .connect(0, 1)
            .connect(1, 0);
        assert_eq!(
            transaction.commit(&mut spec).unwrap_err(),
            TransactionError::CycleDetected
        );
        assert!(spec.is_empty());
    }

    #[test]
    fn self_loops_and_duplicate_edges_are_rejected() {
        let mut spec = GraphSpec::new();
        let mut base = GraphTransaction::new();
        base.add_node(GAIN_NODE_DESCRIPTOR)
            .add_node(OUTPUT_NODE_DESCRIPTOR)
            .connect(0, 1);
        base.commit(&mut spec).unwrap();

        let mut loopy = GraphTransaction::new();
        loopy.connect(0, 0);
        assert_eq!(
            loopy.commit(&mut spec).unwrap_err(),
            TransactionError::SelfLoop { step: 0 }
        );

        let mut duplicate = GraphTransaction::new();
        duplicate.connect(0, 1);
        assert_eq!(
            duplicate.commit(&mut spec).unwrap_err(),
            TransactionError::DuplicateEdge { step: 0 }
        );
    }

    #[test]
    fn parameter_range_is_enforced() {
        let mut spec = GraphSpec::new();
        GraphTransaction::new()
            .add_node(GAIN_NODE_DESCRIPTOR)
            .commit(&mut spec)
            .unwrap();

        let mut too_loud = GraphTransaction::new();
        too_loud.set_parameter(0, 0, 100.0);
        assert_eq!(
            too_loud.commit(&mut spec).unwrap_err(),
            TransactionError::ParameterOutOfRange {
                step: 0,
                param_id: 0
            }
        );

        let mut unknown = GraphTransaction::new();
        unknown.set_parameter(0, 42, 0.0);
        assert_eq!(
            unknown.commit(&mut spec).unwrap_err(),
            TransactionError::UnknownParameter {
                step: 0,
                param_id: 42
            }
        );
    }

    #[test]
    fn removing_a_node_reindexes_surviving_edges() {
        let mut spec = GraphSpec::new();
        GraphTransaction::new()
            .add_node(GAIN_NODE_DESCRIPTOR) // 0
            .add_node(FIR_NODE_DESCRIPTOR) // 1
            .add_node(OUTPUT_NODE_DESCRIPTOR) // 2
            .connect(0, 1)
            .connect(1, 2)
            .commit(&mut spec)
            .unwrap();

        // 删除中间的 FIR，边 0→1 和 1→2 都会消失，节点 2 重编号为 1。
        let mut remove = GraphTransaction::new();
        remove.remove_node(1).connect(0, 1);
        let log = remove.commit(&mut spec).unwrap();

        assert_eq!(log.node_count, 2);
        assert_eq!(log.edge_count, 1);
        assert_eq!(spec.edges()[0], EdgeDescriptor::simple(0, 1));
        assert_eq!(spec.nodes()[1].name, "Output");
        // FIR 的 128 采样延迟随之消失
        assert_eq!(log.total_latency_samples, 0);
    }

    #[test]
    fn dry_run_never_mutates() {
        let mut spec = GraphSpec::new();
        GraphTransaction::new()
            .add_node(GAIN_NODE_DESCRIPTOR)
            .commit(&mut spec)
            .unwrap();
        let baseline = spec.clone();

        let mut probe = GraphTransaction::new();
        probe.add_node(OUTPUT_NODE_DESCRIPTOR).connect(0, 1);
        let log = probe.dry_run(&spec).expect("dry run succeeds");
        assert_eq!(log.node_count, 2);
        assert_eq!(spec, baseline, "dry_run 必须无副作用");
    }

    #[test]
    fn empty_result_is_rejected() {
        let mut spec = GraphSpec::new();
        let transaction = GraphTransaction::new();
        assert_eq!(
            transaction.commit(&mut spec).unwrap_err(),
            TransactionError::EmptyGraph
        );
    }
}
