//! # 统一的格式协商与转换策略（§5.2）
//!
//! 三个层次：
//! 1. **描述**：[`AudioFormat`] = 采样率 + 采样格式 + 通道布局
//! 2. **协商**：[`FormatNegotiator`] 在宿主能力集中挑选代价最小的格式
//! 3. **转换**：[`convert`] 中的零分配转换原语（位深 / 通道 / 交织）
//!
//! 所有转换函数都写入调用方提供的切片，音频线程内可安全使用。

use core::fmt;

/// 采样格式与位深。
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum SampleFormat {
    /// 16-bit 有符号整数（CD 品质）
    Int16,
    /// 24-bit 有符号整数（packed，3 字节）
    Int24,
    /// 32-bit 有符号整数
    Int32,
    /// 32-bit 浮点（DSP 内部典型格式）
    Float32,
    /// 64-bit 浮点（高精度离线处理）
    Float64,
}

impl SampleFormat {
    /// 每采样字节数。
    #[inline(always)]
    pub const fn bytes_per_sample(self) -> usize {
        match self {
            SampleFormat::Int16 => 2,
            SampleFormat::Int24 => 3,
            SampleFormat::Int32 => 4,
            SampleFormat::Float32 => 4,
            SampleFormat::Float64 => 8,
        }
    }

    /// 有效位深。
    #[inline(always)]
    pub const fn bit_depth(self) -> BitDepth {
        match self {
            SampleFormat::Int16 => BitDepth::Bit16,
            SampleFormat::Int24 => BitDepth::Bit24,
            SampleFormat::Int32 | SampleFormat::Float32 => BitDepth::Bit32,
            SampleFormat::Float64 => BitDepth::Bit64,
        }
    }

    /// 是否为浮点格式。
    #[inline(always)]
    pub const fn is_float(self) -> bool {
        matches!(self, SampleFormat::Float32 | SampleFormat::Float64)
    }

    /// 相对于 DSP 内部 `Float32` 的转换代价（越小越好）。
    #[inline(always)]
    const fn conversion_cost(self) -> u64 {
        match self {
            SampleFormat::Float32 => 0,
            SampleFormat::Float64 => 1,
            SampleFormat::Int32 => 2,
            SampleFormat::Int24 => 3,
            SampleFormat::Int16 => 4,
        }
    }
}

impl fmt::Display for SampleFormat {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let name = match self {
            SampleFormat::Int16 => "s16",
            SampleFormat::Int24 => "s24",
            SampleFormat::Int32 => "s32",
            SampleFormat::Float32 => "f32",
            SampleFormat::Float64 => "f64",
        };
        f.write_str(name)
    }
}

/// 位深表示。
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(u8)]
pub enum BitDepth {
    Bit16 = 16,
    Bit24 = 24,
    Bit32 = 32,
    Bit64 = 64,
}

impl BitDepth {
    #[inline(always)]
    pub const fn bits(self) -> u8 {
        self as u8
    }
}

/// 通道布局。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ChannelLayout {
    Mono,
    Stereo,
    StereoWithSub,
    Surround51,
    Surround71,
    Custom(u16),
}

impl ChannelLayout {
    #[inline(always)]
    pub const fn channel_count(self) -> u16 {
        match self {
            ChannelLayout::Mono => 1,
            ChannelLayout::Stereo => 2,
            ChannelLayout::StereoWithSub => 3,
            ChannelLayout::Surround51 => 6,
            ChannelLayout::Surround71 => 8,
            ChannelLayout::Custom(n) => n,
        }
    }
}

/// 完整音频格式描述。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct AudioFormat {
    pub sample_rate: u32,
    pub sample_format: SampleFormat,
    pub channel_layout: ChannelLayout,
}

impl AudioFormat {
    pub const fn new(
        sample_rate: u32,
        sample_format: SampleFormat,
        channel_layout: ChannelLayout,
    ) -> Self {
        Self {
            sample_rate,
            sample_format,
            channel_layout,
        }
    }

    /// DSP 内部规范格式：96 kHz / f32 / stereo。
    pub const fn dsp_canonical() -> Self {
        Self::new(96_000, SampleFormat::Float32, ChannelLayout::Stereo)
    }

    #[inline(always)]
    pub const fn channels(&self) -> u16 {
        self.channel_layout.channel_count()
    }

    /// 每帧字节数（单采样字节 × 通道数）。
    #[inline(always)]
    pub const fn frame_size(&self) -> usize {
        self.sample_format.bytes_per_sample() * self.channels() as usize
    }

    /// 比特率（kbps）。
    #[inline(always)]
    pub const fn bitrate_kbps(&self) -> u64 {
        self.sample_rate as u64 * self.frame_size() as u64 * 8 / 1_000
    }
}

impl Default for AudioFormat {
    fn default() -> Self {
        Self::dsp_canonical()
    }
}

impl fmt::Display for AudioFormat {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "{}Hz/{}/{}ch",
            self.sample_rate,
            self.sample_format,
            self.channels()
        )
    }
}

/// 格式协商失败原因。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FormatError {
    /// 宿主未上报任何可用格式
    NoHostFormats,
    /// 偏好格式本身非法（采样率/通道数越界）
    InvalidRequest,
    /// 没有任何宿主格式可被接受
    NoAcceptableFormat,
    /// 转换所需的目标缓冲区太小
    BufferTooSmall,
    /// 该转换路径未实现
    UnsupportedConversion,
}

impl fmt::Display for FormatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let message = match self {
            FormatError::NoHostFormats => "the host reported no formats",
            FormatError::InvalidRequest => "the requested format is out of range",
            FormatError::NoAcceptableFormat => "no host format is acceptable",
            FormatError::BufferTooSmall => "the destination buffer is too small",
            FormatError::UnsupportedConversion => "this conversion path is not implemented",
        };
        f.write_str(message)
    }
}

impl std::error::Error for FormatError {}

/// 协商结果：源格式 → 目标格式所需的转换计划。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FormatConversion {
    pub source_format: AudioFormat,
    pub target_format: AudioFormat,
    pub requires_resampling: bool,
    pub requires_channel_remap: bool,
    pub requires_bit_depth_conversion: bool,
}

impl FormatConversion {
    /// 构造一份转换计划并自动推导各项标志。
    pub fn plan(source_format: AudioFormat, target_format: AudioFormat) -> Self {
        Self {
            source_format,
            target_format,
            requires_resampling: source_format.sample_rate != target_format.sample_rate,
            requires_channel_remap: source_format.channel_layout != target_format.channel_layout,
            requires_bit_depth_conversion: source_format.sample_format
                != target_format.sample_format,
        }
    }

    /// 是否为零成本直通。
    #[inline(always)]
    pub const fn is_passthrough(&self) -> bool {
        !self.requires_resampling
            && !self.requires_channel_remap
            && !self.requires_bit_depth_conversion
    }

    /// 重采样比（target / source）。
    pub fn resample_ratio(&self) -> f64 {
        self.target_format.sample_rate as f64 / self.source_format.sample_rate as f64
    }
}

/// 格式协商器。
pub trait FormatNegotiator: Send + Sync + 'static {
    /// 在宿主能力集中挑选代价最小的格式。
    fn negotiate(
        &self,
        host_formats: &[AudioFormat],
        preferred: &AudioFormat,
    ) -> Result<FormatConversion, FormatError>;

    /// 该格式是否落在可接受范围内。
    fn supports_format(&self, format: &AudioFormat) -> bool;
}

/// 默认协商器：按「重采样 ≫ 通道重映射 ≫ 位深转换」的代价顺序挑选。
#[derive(Debug, Clone, Copy, Default)]
pub struct DefaultFormatNegotiator;

impl DefaultFormatNegotiator {
    const RESAMPLE_WEIGHT: u64 = 1_000_000;
    const CHANNEL_WEIGHT: u64 = 10_000;
    const FORMAT_WEIGHT: u64 = 100;

    /// 单个候选格式相对于偏好格式的转换代价。
    fn cost(candidate: &AudioFormat, preferred: &AudioFormat) -> u64 {
        let rate_penalty = if candidate.sample_rate == preferred.sample_rate {
            0
        } else {
            // 采样率差异用绝对值，避免有符号→无符号回绕。
            let diff = candidate.sample_rate.abs_diff(preferred.sample_rate) as u64;
            Self::RESAMPLE_WEIGHT + diff
        };

        let channel_penalty = if candidate.channel_layout == preferred.channel_layout {
            0
        } else {
            let diff = candidate.channels().abs_diff(preferred.channels()) as u64;
            Self::CHANNEL_WEIGHT + diff
        };

        let format_penalty = if candidate.sample_format == preferred.sample_format {
            0
        } else {
            Self::FORMAT_WEIGHT + candidate.sample_format.conversion_cost()
        };

        rate_penalty + channel_penalty + format_penalty
    }
}

impl FormatNegotiator for DefaultFormatNegotiator {
    fn negotiate(
        &self,
        host_formats: &[AudioFormat],
        preferred: &AudioFormat,
    ) -> Result<FormatConversion, FormatError> {
        if host_formats.is_empty() {
            return Err(FormatError::NoHostFormats);
        }
        if !self.supports_format(preferred) {
            return Err(FormatError::InvalidRequest);
        }

        let best = host_formats
            .iter()
            .filter(|candidate| self.supports_format(candidate))
            .min_by_key(|candidate| Self::cost(candidate, preferred))
            .ok_or(FormatError::NoAcceptableFormat)?;

        Ok(FormatConversion::plan(*preferred, *best))
    }

    fn supports_format(&self, format: &AudioFormat) -> bool {
        (8_000..=384_000).contains(&format.sample_rate) && (1..=8).contains(&format.channels())
    }
}

/// 零分配的采样格式 / 通道布局转换原语。
///
/// 所有函数写入调用方提供的切片，不分配、不阻塞，可在音频线程内使用。
pub mod convert {
    use super::FormatError;

    const I16_SCALE: f32 = 32_768.0;
    const I24_SCALE: f32 = 8_388_608.0;
    const I32_SCALE: f64 = 2_147_483_648.0;

    /// i16 → f32，归一化到 [-1.0, 1.0)。
    pub fn i16_to_f32(source: &[i16], destination: &mut [f32]) -> Result<(), FormatError> {
        if destination.len() < source.len() {
            return Err(FormatError::BufferTooSmall);
        }
        for (out, &sample) in destination.iter_mut().zip(source) {
            *out = sample as f32 / I16_SCALE;
        }
        Ok(())
    }

    /// f32 → i16，带饱和裁剪（绝不回绕）。
    pub fn f32_to_i16(source: &[f32], destination: &mut [i16]) -> Result<(), FormatError> {
        if destination.len() < source.len() {
            return Err(FormatError::BufferTooSmall);
        }
        for (out, &sample) in destination.iter_mut().zip(source) {
            let scaled = (sample.clamp(-1.0, 1.0) * I16_SCALE).round();
            *out = scaled.clamp(i16::MIN as f32, i16::MAX as f32) as i16;
        }
        Ok(())
    }

    /// 24-bit packed（小端 3 字节）→ f32。
    pub fn i24_to_f32(source: &[u8], destination: &mut [f32]) -> Result<(), FormatError> {
        let frames = source.len() / 3;
        if destination.len() < frames {
            return Err(FormatError::BufferTooSmall);
        }
        for (index, out) in destination.iter_mut().take(frames).enumerate() {
            let base = index * 3;
            // 小端 24-bit 符号扩展到 i32
            let raw = (source[base] as i32)
                | ((source[base + 1] as i32) << 8)
                | ((source[base + 2] as i8 as i32) << 16);
            *out = raw as f32 / I24_SCALE;
        }
        Ok(())
    }

    /// i32 → f32。
    pub fn i32_to_f32(source: &[i32], destination: &mut [f32]) -> Result<(), FormatError> {
        if destination.len() < source.len() {
            return Err(FormatError::BufferTooSmall);
        }
        for (out, &sample) in destination.iter_mut().zip(source) {
            *out = (sample as f64 / I32_SCALE) as f32;
        }
        Ok(())
    }

    /// 立体声下混为单声道（等功率求和后 -3dB）。
    pub fn stereo_to_mono(interleaved: &[f32], destination: &mut [f32]) -> Result<(), FormatError> {
        let frames = interleaved.len() / 2;
        if destination.len() < frames {
            return Err(FormatError::BufferTooSmall);
        }
        for (index, out) in destination.iter_mut().take(frames).enumerate() {
            *out = (interleaved[index * 2] + interleaved[index * 2 + 1]) * 0.5;
        }
        Ok(())
    }

    /// 单声道上混为立体声（双份复制）。
    pub fn mono_to_stereo(source: &[f32], destination: &mut [f32]) -> Result<(), FormatError> {
        if destination.len() < source.len() * 2 {
            return Err(FormatError::BufferTooSmall);
        }
        for (index, &sample) in source.iter().enumerate() {
            destination[index * 2] = sample;
            destination[index * 2 + 1] = sample;
        }
        Ok(())
    }

    /// 交织 → 平面（`destination[ch]` 为第 ch 个通道）。
    pub fn deinterleave(
        interleaved: &[f32],
        channels: usize,
        destination: &mut [&mut [f32]],
    ) -> Result<(), FormatError> {
        if channels == 0 || destination.len() < channels {
            return Err(FormatError::BufferTooSmall);
        }
        let frames = interleaved.len() / channels;
        if destination.iter().any(|plane| plane.len() < frames) {
            return Err(FormatError::BufferTooSmall);
        }
        for (channel, plane) in destination.iter_mut().take(channels).enumerate() {
            for (frame, slot) in plane.iter_mut().take(frames).enumerate() {
                *slot = interleaved[frame * channels + channel];
            }
        }
        Ok(())
    }

    /// 平面 → 交织。
    pub fn interleave(planes: &[&[f32]], destination: &mut [f32]) -> Result<(), FormatError> {
        let channels = planes.len();
        if channels == 0 {
            return Err(FormatError::BufferTooSmall);
        }
        let frames = planes.iter().map(|plane| plane.len()).min().unwrap_or(0);
        if destination.len() < frames * channels {
            return Err(FormatError::BufferTooSmall);
        }
        for (frame, chunk) in destination
            .chunks_exact_mut(channels)
            .take(frames)
            .enumerate()
        {
            for (slot, plane) in chunk.iter_mut().zip(planes) {
                *slot = plane[frame];
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn frame_size_and_bitrate() {
        let fmt = AudioFormat::new(96_000, SampleFormat::Float32, ChannelLayout::Stereo);
        assert_eq!(fmt.frame_size(), 8);
        assert_eq!(fmt.bitrate_kbps(), 96_000 * 8 * 8 / 1_000);
        assert_eq!(fmt.sample_format.bit_depth().bits(), 32);
    }

    #[test]
    fn exact_match_wins_negotiation() {
        let negotiator = DefaultFormatNegotiator;
        let preferred = AudioFormat::dsp_canonical();
        let host_formats = [
            AudioFormat::new(48_000, SampleFormat::Int16, ChannelLayout::Mono),
            preferred,
            AudioFormat::new(192_000, SampleFormat::Float32, ChannelLayout::Surround71),
        ];

        let conversion = negotiator.negotiate(&host_formats, &preferred).unwrap();
        assert_eq!(conversion.target_format, preferred);
        assert!(conversion.is_passthrough());
        assert!((conversion.resample_ratio() - 1.0).abs() < f64::EPSILON);
    }

    #[test]
    fn same_rate_beats_a_closer_channel_count() {
        let negotiator = DefaultFormatNegotiator;
        let preferred = AudioFormat::new(48_000, SampleFormat::Float32, ChannelLayout::Stereo);
        let host_formats = [
            // 通道匹配但要重采样 —— 代价最高
            AudioFormat::new(44_100, SampleFormat::Float32, ChannelLayout::Stereo),
            // 采样率匹配，仅需位深转换 —— 应当胜出
            AudioFormat::new(48_000, SampleFormat::Int32, ChannelLayout::Stereo),
        ];

        let conversion = negotiator.negotiate(&host_formats, &preferred).unwrap();
        assert_eq!(conversion.target_format.sample_rate, 48_000);
        assert!(!conversion.requires_resampling);
        assert!(conversion.requires_bit_depth_conversion);
        assert!(!conversion.requires_channel_remap);
    }

    #[test]
    fn negative_channel_delta_does_not_wrap() {
        let negotiator = DefaultFormatNegotiator;
        // 偏好 7.1，宿主只有 mono：通道差为负方向，代价必须仍然有限。
        let preferred = AudioFormat::new(48_000, SampleFormat::Float32, ChannelLayout::Surround71);
        let host_formats = [
            AudioFormat::new(48_000, SampleFormat::Float32, ChannelLayout::Mono),
            AudioFormat::new(48_000, SampleFormat::Float32, ChannelLayout::Surround51),
        ];
        let conversion = negotiator.negotiate(&host_formats, &preferred).unwrap();
        // 5.1 比 mono 更接近 7.1，必须选中 5.1。
        assert_eq!(conversion.target_format.channel_layout, ChannelLayout::Surround51);
    }

    #[test]
    fn negotiation_errors_are_specific() {
        let negotiator = DefaultFormatNegotiator;
        let preferred = AudioFormat::dsp_canonical();
        assert_eq!(
            negotiator.negotiate(&[], &preferred),
            Err(FormatError::NoHostFormats)
        );

        let bogus = AudioFormat::new(1, SampleFormat::Float32, ChannelLayout::Stereo);
        assert_eq!(
            negotiator.negotiate(&[preferred], &bogus),
            Err(FormatError::InvalidRequest)
        );

        let unusable = AudioFormat::new(48_000, SampleFormat::Float32, ChannelLayout::Custom(64));
        assert_eq!(
            negotiator.negotiate(&[unusable], &preferred),
            Err(FormatError::NoAcceptableFormat)
        );
    }

    #[test]
    fn integer_float_roundtrip_is_lossless_enough() {
        let original: Vec<i16> = vec![0, 1_000, -1_000, i16::MAX, i16::MIN];
        let mut floats = vec![0.0f32; original.len()];
        convert::i16_to_f32(&original, &mut floats).unwrap();
        assert!(floats.iter().all(|s| (-1.0..=1.0).contains(s)));

        let mut restored = vec![0i16; original.len()];
        convert::f32_to_i16(&floats, &mut restored).unwrap();
        for (a, b) in original.iter().zip(&restored) {
            assert!((a - b).abs() <= 1, "{a} != {b}");
        }
    }

    #[test]
    fn float_to_int_saturates_instead_of_wrapping() {
        let hot = [4.0f32, -4.0, f32::INFINITY, f32::NEG_INFINITY];
        let mut out = [0i16; 4];
        convert::f32_to_i16(&hot, &mut out).unwrap();
        assert_eq!(out, [i16::MAX, i16::MIN, i16::MAX, i16::MIN]);
    }

    #[test]
    fn i24_sign_extension_is_correct() {
        // -1 in 24-bit little endian packed = FF FF FF
        let source = [0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00];
        let mut out = [0.0f32; 2];
        convert::i24_to_f32(&source, &mut out).unwrap();
        assert!(out[0] < 0.0, "0xFFFFFF must decode as negative");
        assert_eq!(out[1], 0.0);
    }

    #[test]
    fn channel_remapping_roundtrip() {
        let mono = [0.25f32, 0.5, -0.5];
        let mut stereo = [0.0f32; 6];
        convert::mono_to_stereo(&mono, &mut stereo).unwrap();
        assert_eq!(stereo, [0.25, 0.25, 0.5, 0.5, -0.5, -0.5]);

        let mut back = [0.0f32; 3];
        convert::stereo_to_mono(&stereo, &mut back).unwrap();
        assert_eq!(back, mono);
    }

    #[test]
    fn interleave_deinterleave_roundtrip() {
        let interleaved = [1.0f32, 10.0, 2.0, 20.0, 3.0, 30.0];
        let mut left = [0.0f32; 3];
        let mut right = [0.0f32; 3];
        {
            let mut planes: [&mut [f32]; 2] = [&mut left, &mut right];
            convert::deinterleave(&interleaved, 2, &mut planes).unwrap();
        }
        assert_eq!(left, [1.0, 2.0, 3.0]);
        assert_eq!(right, [10.0, 20.0, 30.0]);

        let mut restored = [0.0f32; 6];
        let planes: [&[f32]; 2] = [&left, &right];
        convert::interleave(&planes, &mut restored).unwrap();
        assert_eq!(restored, interleaved);
    }

    #[test]
    fn undersized_destination_is_rejected() {
        let source = [0.0f32; 8];
        let mut tiny = [0i16; 2];
        assert_eq!(
            convert::f32_to_i16(&source, &mut tiny),
            Err(FormatError::BufferTooSmall)
        );
    }
}
