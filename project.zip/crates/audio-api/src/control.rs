//! # 稳定的控制面与事件面（§5.3）
//!
//! 长期演进的设计目标：
//!
//! * **零分配**—— `ControlRequest` / `EventPlane` 为 `Copy`，只含标量与
//!   `&'static str`，可直接进 `audio-core` 的无锁 SPSC 环，音频线程不分配。
//! * **契约由类型保证**—— 生产者侧只有 `send` / `publish`，消费者侧只有
//!   `poll` / `drain`。以前是“靠文档约定”，现在是**编译器拦住**。
//! * **多生产者不靠单 SPSC**—— 控制面与音频面各用一条 SPSC，
//!   应用线程通过 [`EventHub`] 聚合排空。避免一个生产者跨界消费破坏 SPSC 不变式。
//! * **内核可并发**—— 控制句柄与音频句柄共享 `Arc`，不再要求 `&mut kernel`
//!   才能跑 `process`。音频回调持独占的适配器与图句柄，控制面只能通过通道通信。
//!
//! ```text
//!                    ControlSender               EventHub
//!  控制线程 ──►┌─────────────────┐              ┌────────────────────┐
//!             │ ControlChannel  │──► 音频线程   │ audio  │ control   │──► 应用线程
//!             └─────────────────┘              └────────────────────┘
//!                 SPSC (control→audio)         SPSC x2  → 聚合排空
//! ```
//!
//! ## 已删除：`ControlPlane` trait 与 `QueuedControlPlane`
//!
//! 它是**坏的**，不是多余：`pump_events` 摸不到真实接收端只能恒返回 0；
//! `events_sender()` 每次 `split()` 出新 hub，发出的事件无人可收。
//! 职责已由 `audio-kernel` 的 `AudioKernel` + `ControlHandle` 完整覆盖。
//!
//! 重新引入的条件：**出现第二个控制面实现**（例如进程外 IPC 控制面），
//! 且两者需要被同一段代码泛型地使用。届时 trait 必须持有真实的
//! [`EventHubReceiver`]，而不是像旧实现那样假装能排空。
//!
//! ## 已删除：`ControlRequest::Extension { id, payload }`
//!
//! 无类型的 `u64` 载荷把编译期问题推迟成运行时约定，接收端只能靠魔数
//! 猜语义。`#[non_exhaustive]` 已经提供了向前兼容：旧代码见到新变体时
//! 编译器会强制它处理 `_ =>` 分支。
//!
//! 重新引入的条件：需要跨进程/跨版本传输**内核自身无法解释**的载荷
//! （如插件私有参数）。届时应带上明确的 schema 版本号与长度，而不是
//! 裸 `u64`。

use core::fmt;
use core::sync::atomic::{AtomicU32, Ordering};
use std::sync::Arc;

use audio_core::spsc::SpscRing;

// ---------------------------------------------------------------------------
// 控制请求
// ---------------------------------------------------------------------------

/// 控制请求 —— 应用 → 内核。全部为 `Copy`，可无锁入队。
///
/// 采用 `#[non_exhaustive]` 保证向前兼容，在向后的固件演进与新增能力中保持稳定的 ABI 和安全编译边界。
#[derive(Debug, Clone, Copy, PartialEq)]
#[non_exhaustive]
pub enum ControlRequest {
    StartStream { sample_rate: u32, block_size: u32 },
    StopStream,
    SetGain { node_id: u32, gain_db: f32 },
    SetMute { node_id: u32, mute: bool },
    SetParameter {
        node_id: u32,
        param_id: u32,
        value: f32,
    },
    RenegotiateFormat { sample_rate: u32, channels: u16 },
    QueryDeviceInfo,
    PublishGraph { graph_id: u64 },
    UnloadGraph,
    SetProbeEnabled { enabled: bool },
}

/// 设备信息快照。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DeviceInfo {
    pub name: &'static str,
    pub sample_rate: u32,
    pub block_size: u32,
    pub input_channels: u16,
    pub output_channels: u16,
    pub latency_us: u32,
}

/// 控制响应 —— 内核 → 应用（同步应答）。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ControlResponse {
    Ack,
    Queued,
    Rejected(&'static str),
    Device(DeviceInfo),
    Failed(&'static str),
}

impl ControlResponse {
    #[inline(always)]
    pub const fn is_success(&self) -> bool {
        matches!(
            self,
            ControlResponse::Ack | ControlResponse::Queued | ControlResponse::Device(_)
        )
    }
}

impl fmt::Display for ControlResponse {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ControlResponse::Ack => f.write_str("ack"),
            ControlResponse::Queued => f.write_str("queued"),
            ControlResponse::Rejected(reason) => write!(f, "rejected: {reason}"),
            ControlResponse::Device(info) => write!(f, "device: {}", info.name),
            ControlResponse::Failed(reason) => write!(f, "failed: {reason}"),
        }
    }
}

// ---------------------------------------------------------------------------
// 事件面
// ---------------------------------------------------------------------------

/// 事件面事件 —— 内核 → 应用。全部为 `Copy`。
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum EventPlane {
    StreamStateChanged { from: u8, to: u8 },
    Underrun { underrun_samples: u32 },
    Overload {
        node_id: u32,
        elapsed_us: u32,
        budget_us: u32,
    },
    FormatNegotiated {
        sample_rate: u32,
        channels: u16,
        bit_depth: u8,
    },
    LatencyChanged {
        added_latency_samples: u32,
        total_latency_us: u32,
    },
    HardwareError { reason: &'static str },
    ThreadPriorityDowngraded { desired: i32, actual: i32 },
    GraphPublished { version: u64, node_count: u32 },
    ChannelOverflow { dropped: u32 },
}

impl EventPlane {
    #[inline(always)]
    pub const fn is_critical(&self) -> bool {
        matches!(
            self,
            EventPlane::HardwareError { .. }
                | EventPlane::ChannelOverflow { .. }
                | EventPlane::ThreadPriorityDowngraded { .. }
        )
    }

    /// 是否由音频线程产生。用于在 [`EventHub`] 中路由到正确的 SPSC。
    #[inline(always)]
    pub const fn produced_by_audio_thread(&self) -> bool {
        matches!(
            self,
            EventPlane::Underrun { .. }
                | EventPlane::Overload { .. }
                | EventPlane::LatencyChanged { .. }
                | EventPlane::HardwareError { .. }
                | EventPlane::ChannelOverflow { .. }
        )
    }
}

// ---------------------------------------------------------------------------
// 内部：可 Arc 的 SPSC 通道（pub(crate) 以支持跨 crate 的内核拆分）
// ---------------------------------------------------------------------------

pub(crate) struct ChannelInner<T, const N: usize> {
    pub(crate) ring: SpscRing<T, N>,
    pub(crate) dropped: AtomicU32,
}

impl<T, const N: usize> ChannelInner<T, N> {
    pub(crate) fn new() -> Self {
        Self {
            ring: SpscRing::new(),
            dropped: AtomicU32::new(0),
        }
    }
}

// SAFETY: SpscRing 在单生产者/单消费者契约下是 Sync 的；
// 至于契约是否被遵守，由更上层的 Sender/Receiver 类型保证。
unsafe impl<T: Send, const N: usize> Send for ChannelInner<T, N> {}
unsafe impl<T: Send, const N: usize> Sync for ChannelInner<T, N> {}

/// 控制通道的**发送端**—— 只有它能 `send`，类型上禁止音频线程误用。
#[derive(Clone)]
pub struct ControlSender<const N: usize = 64> {
    pub(crate) inner: Arc<ChannelInner<ControlRequest, N>>,
}

impl<const N: usize> ControlSender<N> {
    pub(crate) fn new(inner: Arc<ChannelInner<ControlRequest, N>>) -> Self {
        Self { inner }
    }

    /// 控制线程侧：投递请求。队列满返回 `false`（永不阻塞）。
    #[inline]
    pub fn send(&self, request: ControlRequest) -> bool {
        // SAFETY: 只有此 Sender 会写该 ring，单生产者契约由类型守卫。
        let mut producer = unsafe { self.inner.ring.producer() };
        if producer.push(request).is_err() {
            self.inner.dropped.fetch_add(1, Ordering::Relaxed);
            return false;
        }
        true
    }

    pub fn dropped_count(&self) -> u32 {
        self.inner.dropped.load(Ordering::Relaxed)
    }

    pub fn len(&self) -> usize {
        self.inner.ring.len()
    }

    pub fn is_empty(&self) -> bool {
        self.inner.ring.is_empty()
    }
}

impl<const N: usize> fmt::Debug for ControlSender<N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("ControlSender")
            .field("len", &self.len())
            .field("dropped", &self.dropped_count())
            .finish()
    }
}

/// 控制通道的**接收端**—— 只有音频线程持有它。
pub struct ControlReceiver<const N: usize = 64> {
    pub(crate) inner: Arc<ChannelInner<ControlRequest, N>>,
}

impl<const N: usize> ControlReceiver<N> {
    pub(crate) fn new(inner: Arc<ChannelInner<ControlRequest, N>>) -> Self {
        Self { inner }
    }

    #[inline(always)]
    pub fn poll(&self) -> Option<ControlRequest> {
        // SAFETY: 只有此 Receiver 会读该 ring。
        let mut consumer = unsafe { self.inner.ring.consumer() };
        consumer.pop()
    }

    #[inline]
    pub fn drain(&self, mut handler: impl FnMut(ControlRequest)) -> usize {
        // SAFETY: 同上
        let mut consumer = unsafe { self.inner.ring.consumer() };
        let mut count = 0;
        while let Some(request) = consumer.pop() {
            handler(request);
            count += 1;
        }
        count
    }

    pub fn len(&self) -> usize {
        self.inner.ring.len()
    }

    pub fn is_empty(&self) -> bool {
        self.inner.ring.is_empty()
    }
}

impl<const N: usize> fmt::Debug for ControlReceiver<N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("ControlReceiver")
            .field("len", &self.len())
            .finish()
    }
}

/// 一对发送/接收端。由内核构造时一次性拆分。
pub struct ControlChannel<const N: usize = 64> {
    inner: Arc<ChannelInner<ControlRequest, N>>,
}

impl<const N: usize> ControlChannel<N> {
    pub fn new() -> Self {
        Self {
            inner: Arc::new(ChannelInner::new()),
        }
    }

    /// 拆分为类型隔离的 Sender / Receiver。
    pub fn split(self) -> (ControlSender<N>, ControlReceiver<N>) {
        let inner = self.inner;
        (
            ControlSender::new(Arc::clone(&inner)),
            ControlReceiver::new(inner),
        )
    }

}

// 曾有一组直通 `ControlChannel` 的 `send` / `poll` / `drain` / `len` /
// `dropped_count`，已删除：它们是绕过类型拆分的后门。
//
// 拆分的全部意义是「生产端只有 send，消费端只有 poll」；再在工厂上开一套
// 两端都能调的同名方法，就把这个保证还回去了 —— 而且它们复制了
// `Sender`/`Receiver` 的实现，两份代码会各自漂移。
//
// `ControlChannel` 现在只是工厂：`new()` 之后立刻 `split()`。
// 计数与长度分别经由 `ControlSender` / `ControlReceiver` 查询。

impl<const N: usize> Default for ControlChannel<N> {
    fn default() -> Self {
        Self::new()
    }
}

impl<const N: usize> fmt::Debug for ControlChannel<N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("ControlChannel")
            .field("capacity", &N)
            .finish()
    }
}

// ---------------------------------------------------------------------------
// 事件通道：每个生产者一条 SPSC
// ---------------------------------------------------------------------------

/// 事件通道发送端（音频线程或控制线程各自一条）。
#[derive(Clone)]
pub struct EventSender<const N: usize = 256> {
    pub(crate) inner: Arc<ChannelInner<EventPlane, N>>,
}

impl<const N: usize> EventSender<N> {
    pub(crate) fn new(inner: Arc<ChannelInner<EventPlane, N>>) -> Self {
        Self { inner }
    }

    #[inline]
    pub fn publish(&self, event: EventPlane) -> bool {
        let mut producer = unsafe { self.inner.ring.producer() };
        if producer.push(event).is_err() {
            self.inner.dropped.fetch_add(1, Ordering::Relaxed);
            false
        } else {
            true
        }
    }

    pub fn dropped_count(&self) -> u32 {
        self.inner.dropped.load(Ordering::Relaxed)
    }

    pub fn len(&self) -> usize {
        self.inner.ring.len()
    }

    pub fn is_empty(&self) -> bool {
        self.inner.ring.is_empty()
    }
}

impl<const N: usize> fmt::Debug for EventSender<N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("EventSender")
            .field("len", &self.len())
            .field("dropped", &self.dropped_count())
            .finish()
    }
}

/// 事件通道接收端。
pub struct EventReceiver<const N: usize = 256> {
    pub(crate) inner: Arc<ChannelInner<EventPlane, N>>,
}

impl<const N: usize> EventReceiver<N> {
    pub(crate) fn new(inner: Arc<ChannelInner<EventPlane, N>>) -> Self {
        Self { inner }
    }

    #[inline]
    pub fn drain_to(&self, sink: &dyn EventSink) -> usize {
        let mut consumer = unsafe { self.inner.ring.consumer() };
        let mut count = 0;
        while let Some(event) = consumer.pop() {
            sink.on_event(event);
            count += 1;
        }
        count
    }

    pub fn len(&self) -> usize {
        self.inner.ring.len()
    }

    pub fn is_empty(&self) -> bool {
        self.inner.ring.is_empty()
    }
}

impl<const N: usize> fmt::Debug for EventReceiver<N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("EventReceiver")
            .field("len", &self.len())
            .finish()
    }
}

/// 单条 SPSC 事件通道：一个生产者、一个消费者。
///
/// 内核用的是 [`EventHub`]（双通道分片）。当只有一个生产者时 —— 例如
/// 一个独立的诊断子系统 —— 用这个即可，不必付双环的开销。
///
/// 与 [`ControlChannel`] 一样，它只是工厂：`new()` 之后 `split()`，
/// 收发能力分别由 [`EventSender`] / [`EventReceiver`] 提供。
pub struct EventChannel<const N: usize = 256> {
    inner: Arc<ChannelInner<EventPlane, N>>,
}

impl<const N: usize> EventChannel<N> {
    pub fn new() -> Self {
        Self {
            inner: Arc::new(ChannelInner::new()),
        }
    }

    pub fn split(self) -> (EventSender<N>, EventReceiver<N>) {
        let inner = self.inner;
        (
            EventSender::new(Arc::clone(&inner)),
            EventReceiver::new(inner),
        )
    }
}

impl<const N: usize> Default for EventChannel<N> {
    fn default() -> Self {
        Self::new()
    }
}

impl<const N: usize> fmt::Debug for EventChannel<N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("EventChannel").field("capacity", &N).finish()
    }
}

/// 双 SPSC 的聚合器：控制面与音频面各一条，应用线程轮询两条。
///
/// 这是 `EventBus` 文档中提到的 "Sharded SPSC" 模式的最小落地。
#[derive(Clone)]
pub struct EventHub<const N: usize = 256> {
    pub(crate) audio: Arc<ChannelInner<EventPlane, N>>,
    pub(crate) control: Arc<ChannelInner<EventPlane, N>>,
}

impl<const N: usize> EventHub<N> {
    pub fn new() -> Self {
        Self {
            audio: Arc::new(ChannelInner::new()),
            control: Arc::new(ChannelInner::new()),
        }
    }

    /// 拆出音频侧与控制侧的发送端与统一的聚合接收逻辑。
    pub fn split(self) -> (EventHubSender<N>, EventHubReceiver<N>) {
        let sender = EventHubSender {
            audio: EventSender::new(Arc::clone(&self.audio)),
            control: EventSender::new(Arc::clone(&self.control)),
        };
        let receiver = EventHubReceiver {
            audio: EventReceiver::new(Arc::clone(&self.audio)),
            control: EventReceiver::new(self.control),
        };
        (sender, receiver)
    }

    pub fn audio_len(&self) -> usize {
        self.audio.ring.len()
    }

    pub fn control_len(&self) -> usize {
        self.control.ring.len()
    }

    pub fn total_dropped(&self) -> u32 {
        self.audio.dropped.load(Ordering::Relaxed)
            + self.control.dropped.load(Ordering::Relaxed)
    }
}

impl<const N: usize> Default for EventHub<N> {
    fn default() -> Self {
        Self::new()
    }
}

impl<const N: usize> fmt::Debug for EventHub<N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("EventHub")
            .field("audio_len", &self.audio_len())
            .field("control_len", &self.control_len())
            .field("total_dropped", &self.total_dropped())
            .finish()
    }
}

/// `EventHub` 的发送侧：按来源路由到正确的 SPSC。
#[derive(Clone)]
pub struct EventHubSender<const N: usize = 256> {
    pub audio: EventSender<N>,
    pub control: EventSender<N>,
}

impl<const N: usize> EventHubSender<N> {
    /// 显式指定来源，零分支成本。
    #[inline]
    pub fn publish_audio(&self, event: EventPlane) -> bool {
        self.audio.publish(event)
    }

    #[inline]
    pub fn publish_control(&self, event: EventPlane) -> bool {
        self.control.publish(event)
    }

    /// 按事件自身标记的来源自动路由。
    #[inline]
    pub fn publish(&self, event: EventPlane) -> bool {
        if event.produced_by_audio_thread() {
            self.audio.publish(event)
        } else {
            self.control.publish(event)
        }
    }
}

/// `EventHub` 的接收侧：轮询两条 SPSC，保持各自内部顺序。
pub struct EventHubReceiver<const N: usize = 256> {
    audio: EventReceiver<N>,
    control: EventReceiver<N>,
}

impl<const N: usize> EventHubReceiver<N> {
    pub fn drain_to(&self, sink: &dyn EventSink) -> usize {
        // 控制面事件通常更关键，优先排空；也可按时间戳合并，当前保持简单。
        let control_count = self.control.drain_to(sink);
        let audio_count = self.audio.drain_to(sink);
        control_count + audio_count
    }

    pub fn len(&self) -> usize {
        self.audio.len() + self.control.len()
    }

    pub fn is_empty(&self) -> bool {
        self.audio.is_empty() && self.control.is_empty()
    }
}

// ---------------------------------------------------------------------------
// EventSink 抽象与适配层
// ---------------------------------------------------------------------------

/// 事件接收器（**非实时**侧）。
pub trait EventSink: Send + Sync {
    fn on_event(&self, event: EventPlane);
}

/// 将闭包适配为 [`EventSink`]。
pub struct FnEventSink<F>(pub F);

impl<F> EventSink for FnEventSink<F>
where
    F: Fn(EventPlane) + Send + Sync,
{
    fn on_event(&self, event: EventPlane) {
        (self.0)(event)
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU32, Ordering};
    use std::sync::Mutex;

    const TEST_DEVICE: DeviceInfo = DeviceInfo {
        name: "Mock Device",
        sample_rate: 96_000,
        block_size: 512,
        input_channels: 2,
        output_channels: 2,
        latency_us: 5_000,
    };

    #[test]
    fn control_channel_type_split_enforces_single_producer() {
        let channel = ControlChannel::<8>::new();
        let (sender, receiver) = channel.split();

        for node_id in 0..8 {
            assert!(sender.send(ControlRequest::SetGain {
                node_id,
                gain_db: -6.0
            }));
        }
        assert_eq!(sender.len(), 8);
        assert!(!sender.send(ControlRequest::StopStream));
        assert_eq!(sender.dropped_count(), 1);

        let mut seen = 0;
        let drained = receiver.drain(|request| {
            assert!(matches!(request, ControlRequest::SetGain { .. }));
            seen += 1;
        });
        assert_eq!(drained, 8);
        assert_eq!(seen, 8);
        assert!(receiver.is_empty());
    }

    #[test]
    fn event_hub_keeps_audio_and_control_streams_separate() {
        let hub = EventHub::<16>::new();
        let (sender, receiver) = hub.split();

        // 控制面事件走 control 通道
        assert!(sender.publish_control(EventPlane::FormatNegotiated {
            sample_rate: 48_000,
            channels: 2,
            bit_depth: 32,
        }));
        // 音频面事件走 audio 通道
        assert!(sender.publish_audio(EventPlane::Underrun {
            underrun_samples: 64,
        }));

        assert_eq!(sender.audio.len(), 1);
        assert_eq!(sender.control.len(), 1);

        let collected = Mutex::new(Vec::new());
        let sink = FnEventSink(|event: EventPlane| {
            collected.lock().unwrap().push(event);
        });

        assert_eq!(receiver.drain_to(&sink), 2);
        let events = collected.lock().unwrap();
        // 控制面优先排空，所以第一个是 FormatNegotiated
        assert!(matches!(
            events[0],
            EventPlane::FormatNegotiated { .. }
        ));
        assert!(matches!(events[1], EventPlane::Underrun { .. }));
    }

    #[test]
    fn event_hub_auto_routing_uses_event_marker() {
        let hub = EventHub::<16>::new();
        let (sender, receiver) = hub.split();

        // Underrun 标记为音频线程产生
        assert!(sender.publish(EventPlane::Underrun {
            underrun_samples: 1
        }));
        // FormatNegotiated 标记为控制线程产生
        assert!(sender.publish(EventPlane::FormatNegotiated {
            sample_rate: 48_000,
            channels: 2,
            bit_depth: 16,
        }));

        assert_eq!(sender.audio.len(), 1);
        assert_eq!(sender.control.len(), 1);

        let count = Mutex::new(0usize);
        let sink = FnEventSink(|_: EventPlane| {
            *count.lock().unwrap() += 1;
        });
        assert_eq!(receiver.drain_to(&sink), 2);
    }

    #[test]
    fn event_channel_delivers_in_order() {
        let (sender, receiver) = EventChannel::<16>::new().split();
        for samples in 1..=4 {
            assert!(sender.publish(EventPlane::Underrun {
                underrun_samples: samples
            }));
        }

        let collected = Mutex::new(Vec::new());
        let sink = FnEventSink(|event: EventPlane| {
            if let EventPlane::Underrun { underrun_samples } = event {
                collected.lock().unwrap().push(underrun_samples);
            }
        });

        assert_eq!(receiver.drain_to(&sink), 4);
        assert_eq!(*collected.lock().unwrap(), vec![1, 2, 3, 4]);
    }

    #[test]
    fn event_overflow_is_counted_not_blocking() {
        let (sender, receiver) = EventChannel::<4>::new().split();
        for _ in 0..10 {
            sender.publish(EventPlane::Underrun {
                underrun_samples: 1,
            });
        }
        assert_eq!(receiver.len(), 4);
        assert_eq!(sender.dropped_count(), 6);
    }

    #[test]
    fn device_info_and_control_responses_behave_correctly() {
        let response = ControlResponse::Device(TEST_DEVICE);
        assert!(response.is_success());
        assert_eq!(response.to_string(), "device: Mock Device");

        let queued = ControlResponse::Queued;
        assert!(queued.is_success());
        assert_eq!(queued.to_string(), "queued");
    }

    #[test]
    fn pump_events_forwards_to_the_sink() {
        // 验证通过 EventHub 的双 SPSC 分流以及应用线程层面的事件聚合。
        let hub = EventHub::<16>::new();
        let (sender, receiver) = hub.split();
        sender.publish_control(EventPlane::HardwareError {
            reason: "device unplugged",
        });

        let critical = AtomicU32::new(0);
        let sink = FnEventSink(|event: EventPlane| {
            if event.is_critical() {
                critical.fetch_add(1, Ordering::SeqCst);
            }
        });

        assert_eq!(receiver.drain_to(&sink), 1);
        assert_eq!(critical.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn rejected_responses_render_a_reason() {
        let response = ControlResponse::Rejected("control queue is full");
        assert!(!response.is_success());
        assert_eq!(response.to_string(), "rejected: control queue is full");
    }
}
