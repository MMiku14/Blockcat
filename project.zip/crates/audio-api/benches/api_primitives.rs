//! Benchmarks for the audio API layer.
//!
//! Run with: `cargo bench -p audio-api`

#[path = "../../audio-core/benches/support/mod.rs"]
mod support;

use std::time::Instant;

use audio_api::descriptor::{GAIN_NODE_DESCRIPTOR, OUTPUT_NODE_DESCRIPTOR};
use audio_api::{
    AudioFormat, ChannelLayout, ControlChannel, ControlRequest, DefaultFormatNegotiator,
    EventChannel, EventPlane, FnEventSink, FormatNegotiator, GraphSpec, GraphTransaction,
    SampleFormat, StreamConfig, StreamHandle, StreamState,
};
use support::{benchmark, benchmark_samples, print_header, report};

const SAMPLES: usize = 100;

fn main() {
    print_header("audio-api control, format, and transaction paths");
    bench_control_channel();
    bench_event_channel();
    bench_stream_transition();
    bench_format_negotiation();
    bench_format_conversion();
    bench_graph_transaction();
}

fn bench_control_channel() {
    const OPS: u64 = 512;
    let (sender, receiver) = ControlChannel::<1024>::new().split();
    let request = ControlRequest::SetGain {
        node_id: 7,
        gain_db: -6.0,
    };

    let result = benchmark_samples("control_channel_send", SAMPLES, OPS, || {
        let started = Instant::now();
        for _ in 0..OPS {
            sender.send(request);
        }
        let elapsed = started.elapsed();
        let drained = receiver.drain(|value| {
            std::hint::black_box(value);
        });
        assert_eq!(drained as u64, OPS);
        elapsed
    });
    report(&result, Some(25.0));
}

fn bench_event_channel() {
    const OPS: u64 = 512;
    let (sender, receiver) = EventChannel::<1024>::new().split();
    let event = EventPlane::Underrun {
        underrun_samples: 64,
    };

    let result = benchmark_samples("event_channel_publish", SAMPLES, OPS, || {
        let started = Instant::now();
        for _ in 0..OPS {
            sender.publish(event);
        }
        let elapsed = started.elapsed();
        // Drain outside the timed region.
        let sink = FnEventSink(|event: EventPlane| {
            std::hint::black_box(event);
        });
        let drained = receiver.drain_to(&sink);
        assert_eq!(drained as u64, OPS);
        elapsed
    });
    report(&result, Some(25.0));
}

fn bench_stream_transition() {
    let handle = StreamHandle::new(StreamConfig::default());
    let result = benchmark("stream_transition_cas", SAMPLES, 4_096, || {
        // Idle -> Preparing -> Idle keeps the state machine legal forever.
        let _ = handle.transition(StreamState::Preparing);
        let _ = handle.transition(StreamState::Idle);
    });
    report(&result, Some(60.0));
}

fn bench_format_negotiation() {
    let negotiator = DefaultFormatNegotiator;
    let preferred = AudioFormat::dsp_canonical();
    let host_formats = [
        AudioFormat::new(44_100, SampleFormat::Int16, ChannelLayout::Stereo),
        AudioFormat::new(48_000, SampleFormat::Int24, ChannelLayout::Stereo),
        AudioFormat::new(96_000, SampleFormat::Int32, ChannelLayout::Surround51),
        AudioFormat::new(192_000, SampleFormat::Float32, ChannelLayout::Stereo),
    ];

    let result = benchmark("format_negotiate_4_candidates", SAMPLES, 2_048, || {
        let conversion = negotiator
            .negotiate(&host_formats, &preferred)
            .expect("a candidate is always acceptable");
        std::hint::black_box(conversion);
    });
    report(&result, None);
}

fn bench_format_conversion() {
    const FRAMES: usize = 512;
    let source = vec![0.25_f32; FRAMES];
    let mut destination = vec![0_i16; FRAMES];

    let result = benchmark("convert_f32_to_i16_512", SAMPLES, 512, || {
        audio_api::convert::f32_to_i16(&source, &mut destination)
            .expect("destination is large enough");
        std::hint::black_box(&destination);
    });
    report(&result, None);
}

fn bench_graph_transaction() {
    let result = benchmark("graph_transaction_commit_3_nodes", SAMPLES, 512, || {
        let mut spec = GraphSpec::new();
        let mut transaction = GraphTransaction::new();
        transaction
            .add_node(GAIN_NODE_DESCRIPTOR)
            .add_node(GAIN_NODE_DESCRIPTOR)
            .add_node(OUTPUT_NODE_DESCRIPTOR)
            .connect(0, 1)
            .connect(1, 2);
        let log = transaction.commit(&mut spec).expect("valid transaction");
        std::hint::black_box(log);
    });
    // Transactions run on the control thread and may allocate; descriptive only.
    report(&result, None);
}
