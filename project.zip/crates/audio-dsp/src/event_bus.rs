//! 跨模块事件总线（架构文档 §4.1）。
//!
//! 拓扑：SPSC。多生产者场景使用 Sharded SPSC（每个生产者一个独立
//! 通道，消费者轮询）—— 本类型即单个分片。
//!
//! 背压原则：事件总线是监控/诊断通道，不是音频数据通道。队列满时
//! **直接丢弃新事件并计数**；生产者绝不调用 `consumer().pop()` 跨界
//! 消费（会破坏 SPSC 单写者不变式，导致数据竞争/UB）。
//!
//! 保留槽位机制：最后 [`RESERVED_SLOTS`] 个槽位仅供致命事件使用，
//! 防止海量 `PerformanceProbeOverload` 挤占关键通知通道。
//!
//! 目标时延：emit <30ns（§4.6）。

use core::sync::atomic::{AtomicU32, Ordering};

use audio_core::spsc::SpscRing;

/// 内核事件类型。全部为 `Copy`，热路径零分配。
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum KernelEvent {
    /// 音频线程因宿主错误或其他原因停止
    AudioThreadStopped { reason: StopReason },
    /// 宿主块大小变化
    HostAdapterBlockSizeChanged { prev: usize, current: usize },
    /// 采样率变化
    SampleRateChanged { prev: u32, current: u32 },
    /// SPSC 队列溢出（某处生产者滞后）
    SpscOverflow { queue_id: u32, dropped: u32 },
    /// 性能探针检测到超预算
    PerformanceProbeOverload {
        node_id: u32,
        elapsed_us: u32,
        budget_us: u32,
    },
    /// GC 线程过晚回收（Watchdog 触发 Emergency Slot）
    GcOrphanReclaimed { count: u32 },
    /// 线程特权降级
    ThreadProvisionerFallback { desired_prio: i32, granted_prio: i32 },
    /// 格式协商完成
    FormatNegotiated {
        sample_rate: u32,
        channels: u16,
        bit_depth: u8,
    },
    /// 时钟同步 / 延迟模型更新
    ClockSyncUpdated {
        sample_rate: u32,
        hw_latency_us: u32,
        buffer_latency_samples: u32,
    },
    /// 缓冲欠载
    BufferUnderrun { underrun_samples: u32 },
    /// 图热替换完成
    GraphPublished { version: u64, node_count: u32 },
}

/// 线程停止原因。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StopReason {
    HostError,
    UserRequest,
    WatchdogTimeout { elapsed_ms: u64 },
    /// Strict 模式下拒绝降级后主动退出
    ProvisioningFailed,
}

/// 保留槽位数 —— 仅供致命/关键事件使用。
pub const RESERVED_SLOTS: usize = 8;

impl KernelEvent {
    /// 是否为致命/关键事件（可占用保留槽位）。
    ///
    /// 判据：丢失该事件会让控制平面对内核状态产生**错误认知**。
    /// 纯统计类事件（探针过载、GC 计数）不属于此列。
    #[inline(always)]
    pub const fn is_fatal(&self) -> bool {
        matches!(
            self,
            KernelEvent::AudioThreadStopped { .. }
                | KernelEvent::HostAdapterBlockSizeChanged { .. }
                | KernelEvent::SampleRateChanged { .. }
                | KernelEvent::SpscOverflow { .. }
                | KernelEvent::FormatNegotiated { .. }
                | KernelEvent::ClockSyncUpdated { .. }
                | KernelEvent::BufferUnderrun { .. }
                | KernelEvent::GraphPublished { .. }
        )
    }
}

/// 单分片事件总线。
///
/// 并发契约：`emit` 仅由一个生产者线程调用；`drain` 仅由消费者
/// 线程（非实时监控平面）调用。
pub struct EventBus<const N: usize = 64> {
    ring: SpscRing<KernelEvent, N>,
    overflow_counter: AtomicU32,
    fatal_overflow_counter: AtomicU32,
}

impl<const N: usize> EventBus<N> {
    pub fn new() -> Self {
        assert!(
            N > RESERVED_SLOTS,
            "event bus capacity must exceed the reserved slot count"
        );
        Self {
            ring: SpscRing::new(),
            overflow_counter: AtomicU32::new(0),
            fatal_overflow_counter: AtomicU32::new(0),
        }
    }

    /// 生产者线程调用 —— 永不阻塞，永不跨界消费（§4.1）。
    ///
    /// 返回事件是否被接受，便于调用方做本地统计。
    #[inline(always)]
    pub fn emit(&self, event: KernelEvent) -> bool {
        let is_fatal = event.is_fatal();
        let capacity_left = self.ring.capacity_left();

        // 非致命事件不得侵占保留区。
        if !is_fatal && capacity_left <= RESERVED_SLOTS {
            self.overflow_counter.fetch_add(1, Ordering::Relaxed);
            return false;
        }

        // SAFETY: emit 仅由单一生产者线程调用（类型契约）。
        let mut producer = unsafe { self.ring.producer() };
        if producer.push(event).is_err() {
            self.overflow_counter.fetch_add(1, Ordering::Relaxed);
            if is_fatal {
                self.fatal_overflow_counter.fetch_add(1, Ordering::Relaxed);
            }
            return false;
        }
        true
    }

    /// 消费者线程调用 —— 非实时监控平面。
    pub fn drain(&self, mut sink: impl FnMut(KernelEvent)) -> usize {
        // SAFETY: drain 仅由唯一消费者线程调用（类型契约）。
        let mut consumer = unsafe { self.ring.consumer() };
        let mut count = 0;
        while let Some(event) = consumer.pop() {
            sink(event);
            count += 1;
        }
        count
    }

    /// 被丢弃的事件总数。
    pub fn overflow_count(&self) -> u32 {
        self.overflow_counter.load(Ordering::Relaxed)
    }

    /// 被丢弃的**致命**事件数。非零意味着控制平面消费过慢，属于严重故障。
    pub fn fatal_overflow_count(&self) -> u32 {
        self.fatal_overflow_counter.load(Ordering::Relaxed)
    }

    pub fn len(&self) -> usize {
        self.ring.len()
    }

    pub fn is_empty(&self) -> bool {
        self.ring.is_empty()
    }

    pub const fn capacity(&self) -> usize {
        N
    }
}

impl<const N: usize> Default for EventBus<N> {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn probe_event(node_id: u32) -> KernelEvent {
        KernelEvent::PerformanceProbeOverload {
            node_id,
            elapsed_us: 2_000,
            budget_us: 1_000,
        }
    }

    #[test]
    fn reserved_slots_protect_fatal_events() {
        // N=16, RESERVED=8 ⟹ 非致命事件最多占用 16-8 = 8 个槽位。
        let bus = EventBus::<16>::new();

        for i in 0..8 {
            assert!(bus.emit(probe_event(i)), "第 {i} 个非致命事件应被接受");
        }
        assert_eq!(bus.len(), 8);
        assert_eq!(bus.overflow_count(), 0);

        // 第 9 个非致命事件触发保留区保护，必须被丢弃。
        assert!(!bus.emit(KernelEvent::GcOrphanReclaimed { count: 1 }));
        assert_eq!(bus.len(), 8);
        assert_eq!(bus.overflow_count(), 1);

        // 致命事件仍可进入保留区。
        assert!(bus.emit(KernelEvent::AudioThreadStopped {
            reason: StopReason::HostError,
        }));
        assert_eq!(bus.len(), 9);
        assert_eq!(bus.fatal_overflow_count(), 0);

        let mut fatal_seen = false;
        let drained = bus.drain(|e| {
            if matches!(e, KernelEvent::AudioThreadStopped { .. }) {
                fatal_seen = true;
            }
        });
        assert_eq!(drained, 9);
        assert!(fatal_seen, "致命事件不得丢失");
        assert!(bus.is_empty());
    }

    #[test]
    fn fatal_events_can_fill_the_entire_ring() {
        let bus = EventBus::<16>::new();
        for _ in 0..16 {
            assert!(bus.emit(KernelEvent::BufferUnderrun {
                underrun_samples: 8
            }));
        }
        assert_eq!(bus.len(), 16);
        // 第 17 个致命事件溢出，必须单独计数报警。
        assert!(!bus.emit(KernelEvent::BufferUnderrun {
            underrun_samples: 8
        }));
        assert_eq!(bus.fatal_overflow_count(), 1);
        assert_eq!(bus.overflow_count(), 1);
    }

    #[test]
    fn non_fatal_flood_never_starves_the_reserve() {
        let bus = EventBus::<32>::new();
        for i in 0..1_000 {
            bus.emit(probe_event(i));
        }
        // 非致命事件最多 32-8 = 24 个
        assert_eq!(bus.len(), 24);
        assert_eq!(bus.overflow_count(), 1_000 - 24);
        assert_eq!(bus.fatal_overflow_count(), 0);
        // 保留区依然可以接纳 8 个致命事件
        for _ in 0..8 {
            assert!(bus.emit(KernelEvent::AudioThreadStopped {
                reason: StopReason::UserRequest,
            }));
        }
        assert_eq!(bus.len(), 32);
    }

    #[test]
    fn drain_preserves_emission_order() {
        let bus = EventBus::<32>::new();
        for i in 0..5 {
            bus.emit(probe_event(i));
        }
        let mut ids = Vec::new();
        bus.drain(|event| {
            if let KernelEvent::PerformanceProbeOverload { node_id, .. } = event {
                ids.push(node_id);
            }
        });
        assert_eq!(ids, vec![0, 1, 2, 3, 4]);
    }

    #[test]
    #[should_panic(expected = "event bus capacity must exceed the reserved slot count")]
    fn capacity_must_exceed_reserved_slots() {
        let _bus = EventBus::<8>::new();
    }
}
