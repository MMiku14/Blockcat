//! DSP Graph 构建、拓扑验证与 RCU 热替换（架构文档 §2.3）。
//!
//! 关键不变式（§2.3.2）：
//! - 音频线程永不参与图的分配/释放
//! - 图内部缓冲使用 `Box<[f32]>`，`compile()` 一次性分配，无后续扩容
//! - 图以唯一 `Box` 所有权发布；旧图由 hazard token 延迟回收
//! - 音频线程与 UI 线程严禁共享同一个 Deferred Drop 入口

use std::collections::VecDeque;
use std::marker::PhantomData;
use std::sync::atomic::{AtomicBool, AtomicPtr, AtomicU64, Ordering};
use std::sync::Arc;

use crate::node::{DspNode, ProcessContext};

/// 图内节点索引。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct NodeId(pub usize);

/// 图构建 / 编译错误。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GraphError {
    /// 拓扑含环，无法调度
    CycleDetected,
    /// 节点索引越界
    InvalidNode(usize),
    /// 重复连接
    DuplicateEdge,
    /// 自环（节点连接到自身）
    SelfLoop(usize),
    /// 空图
    Empty,
    /// 节点缓冲区大小计算溢出
    BufferSizeOverflow,
}

impl std::fmt::Display for GraphError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            GraphError::CycleDetected => f.write_str("graph topology contains a cycle"),
            GraphError::InvalidNode(index) => write!(f, "node index {index} is out of bounds"),
            GraphError::DuplicateEdge => f.write_str("edge already exists"),
            GraphError::SelfLoop(index) => write!(f, "node {index} cannot connect to itself"),
            GraphError::Empty => f.write_str("graph has no nodes"),
            GraphError::BufferSizeOverflow => f.write_str("graph buffer size overflowed"),
        }
    }
}

impl std::error::Error for GraphError {}

/// 动态图构建器（UI 线程使用，可自由分配，§2.3.3）。
pub struct DynamicGraphBuilder {
    nodes: Vec<Box<dyn DspNode>>,
    connections: Vec<(usize, usize)>,
    max_block: usize,
}

impl DynamicGraphBuilder {
    pub fn new(max_block: usize) -> Self {
        assert!(max_block > 0, "max block size must be non-zero");
        Self {
            nodes: Vec::new(),
            connections: Vec::new(),
            max_block,
        }
    }

    pub fn node_count(&self) -> usize {
        self.nodes.len()
    }

    pub fn edge_count(&self) -> usize {
        self.connections.len()
    }

    pub fn add_node(&mut self, node: Box<dyn DspNode>) -> NodeId {
        self.nodes.push(node);
        NodeId(self.nodes.len() - 1)
    }

    pub fn connect(&mut self, from: NodeId, to: NodeId) -> Result<(), GraphError> {
        if from.0 >= self.nodes.len() {
            return Err(GraphError::InvalidNode(from.0));
        }
        if to.0 >= self.nodes.len() {
            return Err(GraphError::InvalidNode(to.0));
        }
        if from.0 == to.0 {
            return Err(GraphError::SelfLoop(from.0));
        }
        if self.connections.contains(&(from.0, to.0)) {
            return Err(GraphError::DuplicateEdge);
        }
        self.connections.push((from.0, to.0));
        Ok(())
    }

    pub fn disconnect(&mut self, from: NodeId, to: NodeId) {
        self.connections
            .retain(|&(f, t)| !(f == from.0 && t == to.0));
    }

    /// 编译：拓扑排序验证（Kahn 算法）+ 一次性内存分配。
    /// 失败返回 [`GraphError`]（不变式 #16：动态图运行时验证）。
    pub fn compile(self) -> Result<Box<DspGraphInner>, GraphError> {
        let n = self.nodes.len();
        if n == 0 {
            return Err(GraphError::Empty);
        }

        // Kahn 拓扑排序
        let mut indegree = vec![0usize; n];
        let mut adjacency: Vec<Vec<usize>> = vec![Vec::new(); n];
        let mut predecessors: Vec<Vec<usize>> = vec![Vec::new(); n];
        for &(from, to) in &self.connections {
            adjacency[from].push(to);
            predecessors[to].push(from);
            indegree[to] += 1;
        }

        let mut queue: VecDeque<usize> = (0..n).filter(|&i| indegree[i] == 0).collect();
        let mut order = Vec::with_capacity(n);
        while let Some(u) = queue.pop_front() {
            order.push(u);
            for &v in &adjacency[u] {
                indegree[v] -= 1;
                if indegree[v] == 0 {
                    queue.push_back(v);
                }
            }
        }

        if order.len() != n {
            return Err(GraphError::CycleDetected);
        }

        // Sink = 无后继节点，图输出为所有 sink 的混合。
        let sinks: Vec<usize> = adjacency
            .iter()
            .enumerate()
            .filter_map(|(index, successors)| successors.is_empty().then_some(index))
            .collect();

        // 图级延迟 = 所有输入→输出路径中的最大累计延迟。
        let mut path_latency = vec![0usize; n];
        for &index in &order {
            let input_latency = predecessors[index]
                .iter()
                .map(|&predecessor| path_latency[predecessor])
                .max()
                .unwrap_or(0);
            path_latency[index] = input_latency.saturating_add(self.nodes[index].latency_samples());
        }
        let total_latency = sinks
            .iter()
            .map(|&sink| path_latency[sink])
            .max()
            .unwrap_or(0);

        let buffer_samples = n
            .checked_mul(self.max_block)
            .ok_or(GraphError::BufferSizeOverflow)?;

        Ok(Box::new(DspGraphInner {
            nodes: self.nodes.into_boxed_slice(),
            order: order.into_boxed_slice(),
            predecessors: predecessors
                .into_iter()
                .map(Vec::into_boxed_slice)
                .collect::<Vec<Box<[usize]>>>()
                .into_boxed_slice(),
            sinks: sinks.into_boxed_slice(),
            node_outputs: vec![0.0; buffer_samples].into_boxed_slice(),
            mix_buffer: vec![0.0; self.max_block].into_boxed_slice(),
            max_block: self.max_block,
            total_latency,
        }))
    }
}

/// 编译后的定容图，通过 [`DspGraphHandle::try_pin`] 访问。
pub struct DspGraphInner {
    nodes: Box<[Box<dyn DspNode>]>,
    order: Box<[usize]>,
    predecessors: Box<[Box<[usize]>]>,
    sinks: Box<[usize]>,
    node_outputs: Box<[f32]>,
    mix_buffer: Box<[f32]>,
    max_block: usize,
    total_latency: usize,
}

impl DspGraphInner {
    pub fn node_count(&self) -> usize {
        self.nodes.len()
    }

    pub fn sink_count(&self) -> usize {
        self.sinks.len()
    }

    pub fn max_block(&self) -> usize {
        self.max_block
    }

    /// 图级总延迟，即所有输入到输出路径中的最大累计延迟。
    pub fn total_latency_samples(&self) -> usize {
        self.total_latency
    }

    /// 音频线程热路径：按拓扑序处理；多前驱节点按样本求和，多个
    /// sink 同样混合到图输出。全部工作缓冲在 `compile()` 中预分配。
    pub fn process(&mut self, input: &[f32], output: &mut [f32], ctx: &ProcessContext) {
        let sample_count = input.len().min(output.len()).min(self.max_block);
        if sample_count == 0 {
            output.fill(0.0);
            return;
        }

        for &index in &self.order {
            if self.predecessors[index].is_empty() {
                // 源节点：直接取图输入。
                self.mix_buffer[..sample_count].copy_from_slice(&input[..sample_count]);
            } else {
                self.mix_buffer[..sample_count].fill(0.0);
                for &predecessor in &self.predecessors[index] {
                    let start = predecessor * self.max_block;
                    let predecessor_output = &self.node_outputs[start..start + sample_count];
                    for (mixed, &sample) in self.mix_buffer[..sample_count]
                        .iter_mut()
                        .zip(predecessor_output)
                    {
                        *mixed += sample;
                    }
                }
            }

            let output_start = index * self.max_block;
            let node_output = &mut self.node_outputs[output_start..output_start + sample_count];
            self.nodes[index].process(&self.mix_buffer[..sample_count], node_output, ctx);
        }

        output.fill(0.0);
        for &sink in &self.sinks {
            let start = sink * self.max_block;
            let sink_output = &self.node_outputs[start..start + sample_count];
            for (mixed, &sample) in output[..sample_count].iter_mut().zip(sink_output) {
                *mixed += sample;
            }
        }
    }

    /// 清空所有节点内部状态与中间缓冲。
    pub fn reset(&mut self) {
        for node in &mut self.nodes {
            node.reset();
        }
        self.node_outputs.fill(0.0);
        self.mix_buffer.fill(0.0);
    }
}

// `dyn DspNode` is not `Debug`, so render the graph shape instead of contents.
impl std::fmt::Debug for DspGraphInner {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("DspGraphInner")
            .field("node_count", &self.nodes.len())
            .field("sink_count", &self.sinks.len())
            .field("max_block", &self.max_block)
            .field("total_latency_samples", &self.total_latency)
            .finish()
    }
}

/// RCU 热替换句柄（§2.3.2）。目标时延：swap ~5ns（§4.6）。
pub struct DspGraphHandle {
    state: Arc<PublicationState>,
}

struct PublicationState {
    current: AtomicPtr<DspGraphInner>,
    version: AtomicU64,
    hazard: AtomicPtr<DspGraphInner>,
    pin_active: AtomicBool,
}

impl DspGraphHandle {
    pub fn new(initial: Box<DspGraphInner>) -> Self {
        Self {
            state: Arc::new(PublicationState {
                current: AtomicPtr::new(Box::into_raw(initial)),
                version: AtomicU64::new(1),
                hazard: AtomicPtr::new(std::ptr::null_mut()),
                pin_active: AtomicBool::new(false),
            }),
        }
    }

    /// Pin 当前对音频线程可见的图。
    ///
    /// 同一时刻只允许存在一个 guard；重入尝试返回 `None` 而非阻塞。
    /// hazard 指针校验循环保证：已退休的图在 guard 发布 pin 之前不会被回收。
    pub fn try_pin(&self) -> Option<DspGraphReadGuard<'_>> {
        self.state
            .pin_active
            .compare_exchange(false, true, Ordering::Acquire, Ordering::Relaxed)
            .ok()?;

        loop {
            let pointer = self.state.current.load(Ordering::SeqCst);
            self.state.hazard.store(pointer, Ordering::SeqCst);
            if self.state.current.load(Ordering::SeqCst) == pointer {
                return Some(DspGraphReadGuard {
                    state: Arc::clone(&self.state),
                    pointer,
                    _not_send: PhantomData,
                });
            }
        }
    }

    #[inline(always)]
    pub fn version(&self) -> u64 {
        self.state.version.load(Ordering::Acquire)
    }

    /// 当前是否有音频回调持有 pin。
    #[inline(always)]
    pub fn is_pinned(&self) -> bool {
        self.state.pin_active.load(Ordering::Acquire)
    }

    /// 原子发布新图并返回退休的旧图。
    ///
    /// 仅可在**非音频**控制平面调用。返回的 [`RetiredDspGraph`] 必须进入
    /// UI 专属延迟回收路径，并且只能通过 [`RetiredDspGraph::try_reclaim`] 回收。
    #[must_use = "the retired graph must be deferred and reclaimed"]
    pub fn swap(&self, new_graph: Box<DspGraphInner>) -> RetiredDspGraph {
        let new_graph = Box::into_raw(new_graph);
        let old = self.state.current.swap(new_graph, Ordering::AcqRel);
        let version = self.state.version.fetch_add(1, Ordering::Release) + 1;
        RetiredDspGraph {
            pointer: old,
            retired_at_version: version,
            state: Arc::clone(&self.state),
        }
    }
}

impl std::fmt::Debug for DspGraphHandle {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("DspGraphHandle")
            .field("version", &self.version())
            .field("pinned", &self.is_pinned())
            .finish()
    }
}

/// 单次音频回调期间保护图的 hazard-pointer guard。
pub struct DspGraphReadGuard<'a> {
    state: Arc<PublicationState>,
    pointer: *mut DspGraphInner,
    // 音频图修改是单线程的；禁止移动存活的 guard 到别的线程。
    _not_send: PhantomData<&'a *const ()>,
}

impl DspGraphReadGuard<'_> {
    pub fn graph(&self) -> &DspGraphInner {
        // SAFETY: 已发布的 hazard 指针保护该地址直到 Drop。
        unsafe { &*self.pointer }
    }

    /// 通过 pin 住的图处理一个块。
    pub fn process(&mut self, input: &[f32], output: &mut [f32], context: &ProcessContext) {
        // SAFETY: `pin_active` 只允许一个存活 guard，因此对图的可变访问
        // 由本次音频回调独占。
        unsafe { &mut *self.pointer }.process(input, output, context);
    }

    /// 图级延迟（用于宿主延迟上报）。
    pub fn total_latency_samples(&self) -> usize {
        self.graph().total_latency_samples()
    }
}

impl Drop for DspGraphReadGuard<'_> {
    fn drop(&mut self) {
        self.state.hazard.store(std::ptr::null_mut(), Ordering::SeqCst);
        self.state.pin_active.store(false, Ordering::Release);
    }
}

/// 已从发布位摘除、但可能仍被音频回调使用的图。
///
/// 未经回收就丢弃该 token 会**故意泄漏**图内存，而不是冒实时 use-after-free 的风险。
#[must_use = "retired graphs must be deferred and reclaimed"]
pub struct RetiredDspGraph {
    pointer: *mut DspGraphInner,
    retired_at_version: u64,
    state: Arc<PublicationState>,
}

// SAFETY: token 独占持有一个退休的 Box 裸指针。回收前会校验音频 hazard，
// 之后才重建并释放该 Box。
unsafe impl Send for RetiredDspGraph {}

impl std::fmt::Debug for RetiredDspGraph {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("RetiredDspGraph")
            .field("retired_at_version", &self.retired_at_version)
            .field("hazardous", &self.is_hazardous())
            .finish()
    }
}

impl RetiredDspGraph {
    pub fn retired_at_version(&self) -> u64 {
        self.retired_at_version
    }

    /// 音频线程是否仍在使用这张图。
    pub fn is_hazardous(&self) -> bool {
        self.state.hazard.load(Ordering::SeqCst) == self.pointer
    }

    /// 校验音频线程 hazard 后尝试回收。
    pub fn try_reclaim(self) -> Result<(), Self> {
        match self.try_into_box() {
            Ok(graph) => {
                drop(graph);
                Ok(())
            }
            Err(retired) => Err(retired),
        }
    }

    /// 校验音频线程不再 pin 本图后取回所有权。
    ///
    /// 适用于零分配的交替式基准测试；生产 GC 通常调用 [`Self::try_reclaim`]。
    pub fn try_into_box(self) -> Result<Box<DspGraphInner>, Self> {
        if self.is_hazardous() {
            return Err(self);
        }
        let pointer = self.pointer;
        // `RetiredDspGraph` 没有 Drop 实现，字段可安全按值取出；
        // `state` 随 self 一并释放（仅递减 Arc 计数）。
        drop(self.state);
        // SAFETY: swap 产生了唯一的 Box 裸指针；hazard 校验说明没有音频
        // 回调还能获取或解引用旧指针。
        Ok(unsafe { Box::from_raw(pointer) })
    }
}

impl Drop for PublicationState {
    fn drop(&mut self) {
        debug_assert!(!self.pin_active.load(Ordering::Relaxed));
        let ptr = self.current.load(Ordering::Acquire);
        if !ptr.is_null() {
            // SAFETY: 发布状态拥有当前 Box 裸指针的所有权。
            unsafe { drop(Box::from_raw(ptr)) };
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::node::GainNode;

    /// 固定延迟的直通节点，用于验证图级延迟累计。
    struct LatencyNode(usize);

    impl DspNode for LatencyNode {
        fn process(&mut self, input: &[f32], output: &mut [f32], _ctx: &ProcessContext) {
            output.copy_from_slice(input);
        }
        fn latency_samples(&self) -> usize {
            self.0
        }
    }

    fn context() -> ProcessContext {
        ProcessContext {
            sample_rate: 96_000,
            block_size: 512,
        }
    }

    fn build_chain(gain_db: f32, length: usize) -> Box<DspGraphInner> {
        let mut builder = DynamicGraphBuilder::new(512);
        let mut previous: Option<NodeId> = None;
        for _ in 0..length {
            let current = builder.add_node(Box::new(GainNode::new(gain_db)));
            if let Some(previous) = previous {
                builder.connect(previous, current).expect("chain is acyclic");
            }
            previous = Some(current);
        }
        builder.compile().expect("chain compiles")
    }

    #[test]
    fn chain_compiles_and_processes() {
        let mut graph = build_chain(-6.0, 2);
        assert_eq!(graph.node_count(), 2);
        assert_eq!(graph.sink_count(), 1);

        let ctx = context();
        let input = vec![1.0f32; 512];
        let mut output = vec![0.0f32; 512];
        graph.process(&input, &mut output, &ctx);

        // -6dB 两级串联 ≈ -12dB ≈ 0.2512
        let expected = 10.0f32.powf(-12.0 / 20.0);
        assert!((output[0] - expected).abs() < 1e-4, "got {}", output[0]);
    }

    #[test]
    fn parallel_branches_are_summed_at_the_sinks() {
        let mut builder = DynamicGraphBuilder::new(64);
        let source = builder.add_node(Box::new(GainNode::new(0.0)));
        let left = builder.add_node(Box::new(GainNode::new(0.0)));
        let right = builder.add_node(Box::new(GainNode::new(0.0)));
        builder.connect(source, left).unwrap();
        builder.connect(source, right).unwrap();
        let mut graph = builder.compile().unwrap();

        assert_eq!(graph.sink_count(), 2);

        let ctx = context();
        let input = vec![1.0f32; 64];
        let mut output = vec![0.0f32; 64];
        graph.process(&input, &mut output, &ctx);
        // 两个 unity-gain sink 求和 = 2.0
        assert!((output[0] - 2.0).abs() < 1e-6, "got {}", output[0]);
    }

    #[test]
    fn empty_graph_is_rejected() {
        let builder = DynamicGraphBuilder::new(512);
        assert!(matches!(builder.compile(), Err(GraphError::Empty)));
    }

    #[test]
    fn cycle_is_detected() {
        let mut builder = DynamicGraphBuilder::new(512);
        let a = builder.add_node(Box::new(GainNode::new(0.0)));
        let b = builder.add_node(Box::new(GainNode::new(0.0)));
        builder.connect(a, b).unwrap();
        builder.connect(b, a).unwrap();
        assert!(matches!(builder.compile(), Err(GraphError::CycleDetected)));
    }

    #[test]
    fn invalid_edges_are_rejected() {
        let mut builder = DynamicGraphBuilder::new(64);
        let a = builder.add_node(Box::new(GainNode::new(0.0)));
        let b = builder.add_node(Box::new(GainNode::new(0.0)));

        assert_eq!(builder.connect(a, NodeId(99)), Err(GraphError::InvalidNode(99)));
        assert_eq!(builder.connect(a, a), Err(GraphError::SelfLoop(0)));
        builder.connect(a, b).unwrap();
        assert_eq!(builder.connect(a, b), Err(GraphError::DuplicateEdge));

        builder.disconnect(a, b);
        assert_eq!(builder.edge_count(), 0);
    }

    #[test]
    fn total_latency_is_the_maximum_over_all_paths() {
        let mut builder = DynamicGraphBuilder::new(64);
        let source = builder.add_node(Box::new(LatencyNode(10)));
        let slow = builder.add_node(Box::new(LatencyNode(20)));
        let fast = builder.add_node(Box::new(LatencyNode(5)));
        builder.connect(source, slow).unwrap();
        builder.connect(source, fast).unwrap();

        let graph = builder.compile().unwrap();
        // path(source→slow) = 30, path(source→fast) = 15 ⟹ max = 30
        assert_eq!(graph.total_latency_samples(), 30);
    }

    #[test]
    fn rcu_hot_swap_respects_the_audio_hazard() {
        let handle = DspGraphHandle::new(build_chain(0.0, 2));
        assert_eq!(handle.version(), 1);

        let guard = handle.try_pin().expect("the initial graph can be pinned");
        assert_eq!(guard.graph().node_count(), 2);
        assert!(handle.is_pinned());

        // 重入 pin 必须失败而非阻塞
        assert!(handle.try_pin().is_none());

        let retired = handle.swap(build_chain(0.0, 3));
        assert_eq!(retired.retired_at_version(), 2);
        assert!(retired.is_hazardous());

        // 受 guard 保护期间不可回收
        let retired = match retired.try_reclaim() {
            Ok(()) => panic!("a pinned graph must never be reclaimed"),
            Err(retired) => retired,
        };

        drop(guard);
        assert!(!handle.is_pinned());
        assert!(retired.try_reclaim().is_ok());

        // 新图已生效
        let guard = handle.try_pin().expect("the new graph can be pinned");
        assert_eq!(guard.graph().node_count(), 3);
    }

    #[test]
    fn reset_clears_intermediate_buffers() {
        let mut graph = build_chain(0.0, 2);
        let ctx = context();
        let input = vec![1.0f32; 512];
        let mut output = vec![0.0f32; 512];
        graph.process(&input, &mut output, &ctx);
        graph.reset();

        let silence = vec![0.0f32; 512];
        graph.process(&silence, &mut output, &ctx);
        assert!(output.iter().all(|&s| s == 0.0));
    }

    #[test]
    fn zero_length_block_is_safe() {
        let mut graph = build_chain(0.0, 2);
        let ctx = context();
        let mut output: [f32; 0] = [];
        graph.process(&[], &mut output, &ctx);
    }
}
